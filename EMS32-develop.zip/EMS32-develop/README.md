[![Build Status](https://travis-ci.com/NEWLMS/EMS32.svg?token=i4RveWPpCyHtAx7Qu1xS&branch=master)](https://travis-ci.com/NEWLMS/EMS32)
[![Code Climate](https://codeclimate.com/repos/52819b1c7e00a45cde0062d8/badges/74c485a0b703bdf6fbab/gpa.png)](https://codeclimate.com/repos/52819b1c7e00a45cde0062d8/feed)

# Introduction

This is EMS running on Rails 5.1.3.

# Conventions

Unless otherwise specified, the EMS team has agreed to follow the Ruby Style guide found here:

  https://github.com/bbatsov/ruby-style-guide

Additionally, whitespace conventions are maintained using [EditorConfig](http://editorconfig.org/).
Be sure you have it installed in your editor of choice before you get to modifying code within this project.

Also please check this wiki pages: [Testing conventions](https://github.com/NEWLMS/EMS32/wiki/Testing-conventions) and
[AngularJS conventions](https://github.com/NEWLMS/EMS32/wiki/AngularJS-conventions).

### Linting
Using rubocop, haml-lint and coffeelint is highly recommended



# Installation

## Prerequisites

This guide assumes you're on a Mac, Debian/Ubuntu, or Arch Linux machine.

### Mac OS

You'll be expected to have [Homebrew](http://brew.sh/) installed and functional on your machine.

OSX 10.11 El Capitan no longer includes OpenSSL, to solve problems on building eventmachine gem,
install and link the library from Homebrew:
``` brew install openssl; brew link openssl --force ```

## Setup Script

All you have to do is:

```
$ ./script/setup
```

This setup script will install:


* Redis
* MySQL
* ElasticSearch@2.4
* FreeTDS

Also, will create:

* .env file
* Procfile file

And will:

* Create development databases

### After setup

You may need to edit `.env` file adding your machine settings.

As of this writing we're using Redis `3.0.x`. If you're using Homebrew, you can install redis
with the following command: `brew install redis`

### MySQL

At this point, you should edit `.env` file with your MySQL settings.
Once that's done, you can intitialize your DB with the following steps:

0. `bundle exec rake db:create`
0. `bundle exec rake db:schema:load`

### FreeTDS

The EMS application pulls a fair amount of data from an enterprise system
called [Janzebar/Ex](http://www.jenzabar.com/higher-ed-solutions/enterprise-resource-planning-erp/jenzabar-ex).

Ex uses a MSSQL database and in order to access it, we use the
[activerecord-sqlserver-adapter](https://github.com/rails-sqlserver/activerecord-sqlserver-adapter)
gem, which has a hard dependency on [tiny_tds](https://github.com/rails-sqlserver/tiny_tds)
which in turn requires FreeTDS to be installed in order for tiny_tds to be
correctly compiled.

#### Installation

* FreeTDS can be installed via Homebrew by running `brew install freetds`
* Ubuntu installations my alternatively run `apt-get install freetds-dev`

#### Troubleshooting FreeTDS Installation

If you're running Mac OS X and having issues installing FreeTDS in conjunction
with iconv, be sure to specify the freetds and iconv lib and include
directories when installing the tiny_tds gem.

First, make sure you install the latest available version of libiconv via Homebrew. Mac OSX comes with it's own (older) version of libiconv, so we'll have to pull it from the homebrew/dupes repository:

    brew install homebrew/dupes/libiconv

Also ensure that you alrady have FreeTDS installed:

    brew install freetds

Assuming you were successful installing both FreeTDS and libiconv, now install the `tiny_tds` gem.
Here we tell the `gem` command to install `tiny_tds` using the libraries we've already installed via Homebrew:

    gem install tiny_tds -- \
    --with-freetds-include="$(brew --prefix freetds)/include" \
    --with-freetds-lib="$(brew --prefix freetds)/lib" \
    --with-iconv-include="$(brew --prefix libiconv)/include" \
    --with-iconv-lib="$(brew --prefix libiconv)/lib"

At this point, if you successfully installed `tiny_tds`, you should be able to install the remainder of your gems using Bundler. As long as `tiny_tds` is installed as a system gem, Bundler will reference the version already installed instead of trying to install it on it's own (less succeffully, as Bundler won't know to link to the correct versions of libiconv or freetds).

### Elasticsearch

We are using [chewy gem](https://github.com/toptal/chewy) as interface to elastic.

To full reindex run `rake chewy:reset:all`
No additional configuration required.

- `app/chewy` chewy indices path
- `app/modules/search` models search wrappers

Two different approaches:

* `Model.search()` You can find it in `app/modules/search/search.rb`.

  A simple pagination friendly method you can use it with only one params - search phase. Model.search('phrase').

* `Model.custom_search()` You can find it in `app/modules/search/*model_name*.rb`.

  Allows to chain a lot of powerful Chewy methods. For a custom cases.

# Caching

By default, when the application is run under a production environment (`Rails.env.production? == true`), HTTP and application caching via redis will be enabled.

You may also enable caching in non-production environments by setting the `CACHE` environment variable.
Example, enabling caching during tests: `CACHE=true rails server -e test`

# Running

You can initialize the application server by doing:

```
$ foreman start
```
