class ChatBlackList < ApplicationRecord
  belongs_to :section
  belongs_to :user
  belongs_to :user_faculty, class_name: 'User'

  validates :section,      presence: true
  validates :user,         presence: true
  validates :user_faculty, presence: true
  validates :user_id,      uniqueness: { scope: :section_id }
end
