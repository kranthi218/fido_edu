# A Course Learning Outcome (CLO) represents a skill or knowledge that the EMS
# assesses whenever a student submits assignments associated with that CLO
class CourseLearningOutcome < ApplicationRecord
  default_scope -> { order('course_learning_outcomes.position') }

  belongs_to :section

  belongs_to :course,
             inverse_of: :course_learning_outcomes,
             counter_cache: :clos_count,
             touch: true

  has_many :rubric_dimensions
  has_many :clo_plos, dependent: :destroy, inverse_of: :course_learning_outcome
  has_many :plos,
           through: :clo_plos,
           validate: false,
           inverse_of: :course_learning_outcomes
  has_many :assessment_learning_outcomes, inverse_of: :course_learning_outcome
  has_many :assignments,
           through: :assessment_learning_outcomes,
           source: :assessment,
           source_type: 'Assignment'
  has_many :student_assignments,
           through: :assessment_learning_outcomes,
           source: :assessment,
           source_type: 'StudentAssignment'
  has_many :discussions,
           through: :assessment_learning_outcomes,
           source: :assessment,
           source_type: 'Discussions'
  has_many :quiz_scores,
           source: :assessment,
           through: :assessment_learning_outcomes,
           source_type: 'QuizScore'
  has_many :rubrics, as: :rubricable, dependent: :destroy

  has_many :clo_course_terms

  accepts_nested_attributes_for :plos,
                                reject_if: ->(plo) { plo['plo_id'].blank? }
  accepts_nested_attributes_for :rubric_dimensions
  accepts_nested_attributes_for :rubrics

  validates :description, presence: true

  validate :ensure_presence_of_section_or_course

  alias_attribute(:display_name, :description)

  acts_as_list scope: %i[section_id course_id]

  scope :current,           -> { where(active: true) }

  # @todo This method generates HTML; it should be moved into a helper or
  #   a decorator
  def clo_as_popover(length = 60)
    length = description.size > length ? length : (description.size - 2)
    tooltip = <<-HTML
      <div class='user-content'>
        <span
            class=''
            href='#'
            title=''
            data-toggle='popover'
            data-content=\"#{description}\"
            data-html=\"true\">
          #{description.slice(0..length)}...
        </span>
      </div>
    HTML
    tooltip.strip.html_safe
  end

  def acts_as_list_scope
    "section_id = #{section_id}"
  end

  def editable
    assessment_learning_outcomes.empty?
  end

  private

  def ensure_presence_of_section_or_course
    return if section.present? ^ course.present?
    errors.add :base,
               :x_or_y_must_be_present,
               x: self.class.human_attribute_name(:section_id),
               y: self.class.human_attribute_name(:course_id)
  end
end
