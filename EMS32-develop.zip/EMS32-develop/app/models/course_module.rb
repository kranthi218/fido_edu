# The CourseModule model acts as a container
# for collections of assignments, discussions,
# quizzes, and a variety of other course work.
class CourseModule < ApplicationRecord
  include SectionExtension

  after_commit ->(obj) { obj.update_visibility }, on: :create
  after_commit ->(obj) { obj.update_visibility }, on: :update

  belongs_to :section, touch: true

  has_many :assignments
  has_many :lessons
  has_many :quizzes
  has_many :discussions
  has_many :student_assignments, through: :assignments

  validates :name, presence: true, uniqueness: { scope: :section_id }
  validates :position,
            presence: true,
            numericality: { greater_than: 0 },
            uniqueness: { scope: :section_id }

  scope :visible_to_students, -> { where(visible: true).order(:position) }

  after_destroy :clean_coursework_associations

  def eligible_for_delete
    (assignments.count + discussions.count + quizzes.count + lessons.count) <= 0
  end

  def self.tab_title
    'Course Modules'
  end

  protected

  def update_visibility
    CourseModuleVisibilityJob.perform_later id
  end

  private

  def clean_coursework_associations
    assignments.update_all(course_module_id: nil)
    discussions.update_all(course_module_id: nil)
    lessons.update_all(course_module_id: nil)
    quizzes.update_all(course_module_id: nil)
  end
end
