class AdmissionStatus < ApplicationRecord

  has_many :students

  validates :name,
    presence: true,
    uniqueness: true

  def active?
    name == "Active"
  end

  def graduated?
    name == "Graduated"
  end

end
