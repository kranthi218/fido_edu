class CloIlo < ApplicationRecord
  # @TODO this table is depracated, CLO should never tie directly to a ILO,
  # clo -> plo -> ile
  belongs_to :course_learning_outcome
  belongs_to :ilo
end
