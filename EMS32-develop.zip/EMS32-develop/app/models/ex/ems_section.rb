# The Ex::EmsSection class represents the Janzebar/Ex equivilant of what
# we otherwise consider a section: a representation of a
# an instance of a course course during a specific term.
class Ex::EmsSection < Ex::Base
  self.table_name = 'EMS_SECTION_MASTER'
  self.primary_key = nil

  # The course title for this section.
  # Ex seems to truncate this string to a maximum of 70 characters.
  #
  # @note Ex stores the course title in two fixed-length, whitespace padded
  #   fields. We trim the fields and concatenate them to get the 'real'
  #   human readable course title.
  # @see Ex::Section#short_course_title
  def course_title
    @course_title ||= format(
      '%s%s',
      crs_title.to_s.strip,
      crs_title_2.to_s.strip
    )
  end

  # The short course title for this section.
  # Ex seems to truncate this string to a maximum of 30 characters.
  #
  # @note Ex stores the short course title in two fixed-length,
  #   whitespace padded fields. We trim the fields and
  #   concatenate them to get the 'real' human readable course title.
  # @see Ex::Section#course_title
  def short_course_title
    @short_course_title = format(
      '%s%s',
      short_crs_title_1.to_s.strip,
      short_crs_title_2.to_s.strip
    )
  end

  # Given a term code and a year known to Janzebar/Ex,
  # return a list of courses in the order they were added
  # to Ex.
  #
  # @param [String] A term code, as seen in
  def self.courses_for(ex_term, ex_year)
    find_by_sql <<-sql.strip_heredoc
      SELECT em.crs_cde AS ex_course_no,
             em.trm_cde AS term,
             em.yr_cde  AS year,
      RTRIM(LTRIM(LEFT(em.crs_cde, charindex(' ', em.crs_cde) + 5))) AS course_no,
      LTRIM(RTRIM(em.crs_title)) AS course_name,
      COALESCE (em.CRS_TITLE + em.CRS_TITLE_2, em.CRS_TITLE) AS new_course_name,
      em.credit_hrs AS credit_units,
      ep.id_num AS id_num,
      RTRIM(LTRIM(REPLACE(substring(em.crs_cde, charindex(' ',em.crs_cde)+6, len(em.crs_cde)), ' ', ' '))) AS section,

      category = CASE
        WHEN em.crs_cde LIKE '% [0-9]' THEN 'Regular'
        WHEN em.crs_cde LIKE '%[0-9][L-R]' THEN 'Weekend'
        WHEN em.crs_cde LIKE '%E[0-9]' THEN 'Online'
        WHEN em.crs_cde LIKE  '% [A-B]' THEN 'Regular'
      END,

      program_code = CASE
        WHEN SM.INSTITUT_DIV_CDE = 'BA' THEN 'MBA'
        WHEN SM.INSTITUT_DIV_CDE = 'EC' THEN 'MSEE'
        WHEN SM.INSTITUT_DIV_CDE = 'CS' THEN 'MSSE'
        WHEN SM.INSTITUT_DIV_CDE = 'EM' THEN 'MSEM'
        WHEN SM.INSTITUT_DIV_CDE = 'DA' THEN 'MSDA'
      END,

      cpt_course = CASE
        WHEN em.crs_cde LIKE 'CPT%' THEN 1
        ELSE 0
      END,

      sm.course_text AS course_description

      FROM EMS_SECTION_MASTER em
      JOIN EMS_SECTION_PERSON ep ON ep.crs_cde = em.crs_cde
      JOIN SECTION_MASTER sm ON sm.crs_cde = em.crs_cde
      WHERE em.trm_cde = '#{ex_term}'
            AND em.yr_cde = '#{ex_year}'
            AND ep.ems_role = 'INS'
      ORDER BY em.batch_number
    sql
  end
end
