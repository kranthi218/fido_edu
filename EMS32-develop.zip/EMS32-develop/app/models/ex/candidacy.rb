module Ex
  # An Ex::Candidacy record reflects the application status of a student.
  #
  # The `stage` column with the value `MSACD` (case-insensitive) indicates a
  # prospective student's application has been accepted by ITU.
  # `OCACD` is a stage code for open campus
  class Candidacy < Base
    self.table_name = 'candidacy'
    self.primary_key = 'id_num'

    belongs_to :ex_name, class_name: "Ex::Name", foreign_key: "id_num"

    scope :accepted, -> { where(stage: %w(msacd ocacd msenr mscop dracc 4RGTR)) }
  end
end
