# frozen_string_literal: true
# A Ex::Name record represents a single person or user within Janzebar/Ex.
class Ex::Name < Ex::Base
  self.table_name = 'name_master'
  self.primary_key = 'id_num'

  # By default, exclude Janzebar/Ex system accounts.
  # These accounts are used by Janzebar's internal processes and are NOT
  # real users. Convineintly, they also all have negative id_num values.
  default_scope -> { where(arel_table[:id_num].gt(0)) }

  has_one :ex_faculty, class_name: 'Ex::Faculty', foreign_key: 'id_num'
  has_one :ex_student, class_name: 'Ex::Student', foreign_key: 'id_num'
  has_one :ex_candidacy, class_name: 'Ex::Candidacy', foreign_key: 'id_num'

  has_many :ex_student_course_histories,
           class_name: 'Ex::StudentCourseHistory', foreign_key: 'id_num'
end
