class Ex::Faculty < Ex::Base
  self.table_name = 'FACULTY_MASTER'
  self.primary_key = 'id_num'

  belongs_to :ex_name, class_name: 'Ex::Name', foreign_key: 'id_num'
  has_many :ex_faculty_load,
           inverse_of: :ex_faculty,
           class_name: 'Ex::FacultyLoad',
           primary_key: 'id_num',
           foreign_key: 'instrctr_id_num'
  has_many :ex_sections, through: :ex_faculty_load
end
