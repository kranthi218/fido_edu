# frozen_string_literal: true

# Ex representation of what we refer to as a Section in the EMS
class Ex::Rw::Section < Ex::Rw
  self.table_name = 'SECTION_MASTER'
  self.primary_keys = %w[yr_cde trm_cde crs_cde]

  RUBRIC_NOT_REQUIRED_COURSE_CODES = %(GRN INT)

  has_one :ex_catalog,
          class_name: 'Ex::Catalog',
          primary_key: 'institut_div_cde',
          foreign_key: 'instit_div_cde'
  has_many :ex_faculty_load,
           class_name: 'Ex::FacultyLoad',
           foreign_key: %w[yr_cde trm_cde crs_cde]
  has_many :ex_faculty, through: :ex_faculty_load
  has_many :ex_student_course_histories,
           class_name: 'Ex::StudentCourseHistory',
           foreign_key: %w[yr_cde trm_cde crs_cde],
           primary_key: %w[yr_cde trm_cde crs_cde]
  has_many :ex_rw_student_course_histories,
           class_name: 'Ex::Rw::StudentCourseHistory',
           foreign_key: %w[yr_cde trm_cde crs_cde],
           primary_key: %w[yr_cde trm_cde crs_cde]

  has_many :ex_section_schedules,
           class_name: 'Ex::SectionSchedule',
           foreign_key: %w[yr_cde trm_cde crs_cde],
           primary_key: %w[yr_cde trm_cde crs_cde]
  # changing to crs_cancel_flg: Y from section_sts: C see ETPO-1059
  scope(:active, lambda do
    where.not(crs_cancel_flg: 'Y',
              last_end_dte: [nil, ''],
              first_begin_dte: [nil, ''])
  end)
  scope :cancelled, -> { where(crs_cancel_flg: 'Y') }
  scope(:for_term, lambda do |term|
    where(trm_cde: term.janzebar_term, yr_cde: term.janzebar_year)
  end)

  def available_enrollments
    max_enrollment - crs_enrollment
  end

  def ex_department
    ex_catalog.try(:ex_department)
  end

  def ems_term
    name = Term::JANZEBAR_TERM.key(trm_cde.to_s.upcase)
    year = (trm_cde == 'FA' ? yr_cde.to_i : yr_cde.to_i + 1)
    Term.for_year(year).where(name: name).first
  end

  def self.by_ems_section(ems_section)
    active.for_term(ems_section.term)
          .where(crs_cde: ems_section.ex_course_code).last
  end
end
