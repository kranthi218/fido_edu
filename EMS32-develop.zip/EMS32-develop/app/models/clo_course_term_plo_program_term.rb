class CloCourseTermPloProgramTerm < ApplicationRecord
  belongs_to :clo_course_term
  belongs_to :plo_program_term
end
