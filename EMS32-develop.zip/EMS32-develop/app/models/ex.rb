# The Ex namespace encapsulates all relevant models
# and connection information for data that lives within
# Janzebar/Ex.
module Ex
  # This class is responsible for managing connection
  # infomation for models that correspond to tables
  # within Janzebar/Ex.
  class Rw < ::ApplicationRecord
    self.abstract_class = true
    establish_connection(:janzebar)
  end

  # Base class provides readonly access
  class Base < Rw
    self.abstract_class = true
    after_initialize :readonly!
  end
end
