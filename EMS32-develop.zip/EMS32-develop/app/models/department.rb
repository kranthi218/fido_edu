class Department < ApplicationRecord
  has_many :programs
  has_many :majors, through: :programs
  has_many :sections
  has_many :courses
  has_many :plos, dependent: :destroy
  has_many :projects, dependent: :destroy
  has_many :faculty
  has_many :broadcasts

  validates :name, presence: true
  validates :number, presence: true

  scope :visible, -> { where(active: true) }

  def display_name
    name
  end

  def faculty_mailing_list(term = Term.current)
    User.includes(faculty:  { section_faculty: :section })
        .where(sections: { term_id: term.id, department_id: id })
        .distinct
  end
end
