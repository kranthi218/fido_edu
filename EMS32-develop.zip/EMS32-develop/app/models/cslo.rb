class Cslo < ApplicationRecord
  self.table_name = "course_learning_outcomes"
  attr_accessor :department_id, :program_id
  default_scope -> { order('course_learning_outcomes.created_at ASC') }


  belongs_to :course
  belongs_to :section

  has_many :clo_plos, dependent: :destroy, foreign_key: "course_learning_outcome_id"
  has_many :plos, through: :clo_plos, validate: false
  has_many :clo_ilos, dependent: :destroy, foreign_key: "course_learning_outcome_id"
  has_many :ilos, through: :clo_ilos, validate: false


  validates :description, :presence => {:message => "Course Learning Outcome cannot be blank."}
  validates :section_id, :presence => true
  validates :ilos, :length => {:minimum => 1, :message => "must have at least 1 ILO: Please select at lease 1 ILO."}

end
