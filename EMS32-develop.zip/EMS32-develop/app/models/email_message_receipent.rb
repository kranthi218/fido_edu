class EmailMessageReceipent < ApplicationRecord
end
