# A `CalendarItem` is a representation of an arbitrary
# event that has an associated due date.
#
# Calendar items may also have an optional href attribute
# which is intended to contain a URL linking to a resource
# with additional information about the event.
class CalendarItem < ApplicationRecord

  belongs_to :calendar, inverse_of: :items, touch: true
  validates :calendar_id, presence: true
  validates :title, presence: true
  validates :due_at, presence: true, timeliness: {
      on_or_after: :today,
      on_or_after_message: 'must be on or after today'
    }
end
