class Assignment < ApplicationRecord
  include AssignmentExtension
  include AssetsExtension
  include LinksExtension
  include CourseworkExtension
  include PublicActivity::Common

  belongs_to :course_module

  # belongs_to :section, touch: true
  # belongs_to :course,  touch: true

  has_many :activities, as: :trackable, dependent: :destroy
  has_many :student_assignments
  has_many :students, through: :student_assignments

  has_many :assessment_learning_outcomes, as: :assessment, dependent: :destroy
  has_many :course_learning_outcomes, through: :assessment_learning_outcomes
  has_many :course_terms

  validates :points,
            presence: true,
            numericality: { greater_than_or_equal_to: 0 }

  validates_presence_of :title

  validates :description, presence: true

  accepts_nested_attributes_for :student_assignments
  accepts_nested_attributes_for(
    :assets,
    allow_destroy: true,
    reject_if: proc { |attrs| attrs['attachment'].blank? }
  )

  alias_attribute :submissions, :student_assignments

  def self.for_term(term)
    joins(:section).where(sections: { term_id: term })
  end

  def self.with_assignment_id(assignment_id)
    where(assignment_id: assignment_id)
  end

  def self.without_a_group
    where(course_module_id: nil)
  end

  delegate :graded, :ungraded, to: :student_assignments

  scope :eligible_for_speed_grading, -> do
    where(in_class: true)
  end

  def self.section_assignments_visible_to_students(section_id)
    ag_arel = CourseModule.arel_table

    includes(:course_module)
      .where(
        section_id: section_id,
        visible: true
      ).where(
        ag_arel[:id].eq(nil).or(
          ag_arel[:visible].eq(true)
        )
      ).references(:course_module)
  end

  # Exclude SignatureAssignments
  # @TODO rewrite with .or() after migration to Rails 5
  def self.retrievable
    joins(:coursework).where(
      Coursework.arel_table[:kind].eq('regular')
    )
  end

  def signature_assignment?
    coursework&.kind&.to_sym == :signature
  end

  def assignment?
    grading_policy.try(:name) == 'Assignments'
  end

  def category
    in_class? ? 'In Class' : 'Take Home'
  end

  def percentage
    course_module_points = course_module.assignments.map(&:points).sum
    (points * course_module_percentage) / course_module_points
  end

  def course_module_percentage
    course_module.percentage
  end

  def assignments_for(user)
    return unless user.role.respond_to?(:assignments)
    user.role.student_assignments.where(assignment_id: id)
  end

  def gradable_students_assignments
    student_assignments
      .includes(section: :section_students)
      .where(section_students: { status: 'enrolled' })
  end
end
