class AssetBundle < ApplicationRecord
  belongs_to :bindable, polymorphic: true
  belongs_to :user

  validates :user_id,       presence: true
  validates :bindable_id,   presence: true, numericality: true
  validates :bindable_type, presence: true

  has_attached_file :bundle

  validates_attachment_presence :bundle

  validates_attachment_content_type :bundle,
                                    content_type: %w(application/zip
                                                     application/octet-stream)

  after_create :send_notification

  private

  def send_notification
    AssetBundleMailer.notify_user(self).deliver
  end
end
