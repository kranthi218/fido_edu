class Advisor < ApplicationRecord

  belongs_to :user
  belongs_to :advisor_group

end
