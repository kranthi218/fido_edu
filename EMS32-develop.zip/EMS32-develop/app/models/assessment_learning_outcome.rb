# How a student performs on a particular assignment for
# a particular criterion (aka: CLO). An assignment submission
# will typically have one AssessmentLearningOutcome (aka: ALO)
# for each CLO associated with the submission's parent assignment.
class AssessmentLearningOutcome < ApplicationRecord
  belongs_to :course_learning_outcome, inverse_of: :assessment_learning_outcomes
  belongs_to :assessment,
             polymorphic: true,
             touch: true

  validates :course_learning_outcome_id,
            presence: true,
            uniqueness: { scope: :assessment_id }
  validates :score, presence: true

  def self.discussion_assessment_query
    <<-SQL
      INNER JOIN discussion_participants
      ON discussion_participants.id = assessment_learning_outcomes.assessment_id
      AND assessment_learning_outcomes.assessment_type = 'DiscussionParticipant'
      INNER JOIN discussions
      ON discussions.id = discussion_participants.discussion_id
    SQL
  end

  def self.assignments_assessment_query
    <<-SQL
      INNER JOIN student_assignments
      ON student_assignments.id = assessment_learning_outcomes.assessment_id
      AND assessment_learning_outcomes.assessment_type = 'StudentAssignment'
      INNER JOIN assignments
      ON assignments.id = student_assignments.assignment_id
    SQL
  end

  def self.average_plo_score_for(term, plo)
    scores = alo_plo_query(discussion_assessment_query, term, plo, :discussions)
    scores << alo_plo_query(assignments_assessment_query, term, plo, :assignments)
    tally_scores = scores.flatten
    return nil unless tally_scores.any?
    # get average ALO score accross coursework for student
    tally_scores.inject(0.0) { |acc, elem| acc + elem } / tally_scores.size
  end

  def self.average_clo_score_for(student, section, clo)
    scores = AssessmentLearningOutcome.joins(assignments_assessment_query)
                                      .where(assessment_learning_outcomes: { course_learning_outcome_id: clo })
                                      .where(student_assignments: { student_id: student })
                                      .where(assignments: {section_id: section}).pluck(:score).select{ |t| t >=1 && t <=4 }

    scores << AssessmentLearningOutcome.joins(discussion_assessment_query)
                                       .where(assessment_learning_outcomes: {course_learning_outcome_id: clo})
                                       .where(discussion_participants: { student_id: student })
                                       .where(discussions: {section_id: section}).pluck(:score).select{ |t| t >=1 && t <=4 }

    tally_scores = scores.flatten
    return nil unless tally_scores.any?
    # get average ALO score accross coursework for student
    tally_scores.inject(0.0) { |acc, elem| acc + elem } / tally_scores.size
  end

  def self.average_clo_score_for_signature_assignment(student, section, clo)
    scores = AssessmentLearningOutcome.joins(assignments_assessment_query)
                                      .where(assessment_learning_outcomes: { course_learning_outcome_id: clo })
                                      .where(student_assignments: { student_id: student })
                                      .where(assignments: {section_id: section, id: section.signature_assignment}).pluck(:score).select{ |t| t >=1 && t <=4 }

    tally_scores = scores.flatten
    return nil unless tally_scores.any?
    # get average ALO score accross coursework for student
    tally_scores.inject(0.0) { |acc, elem| acc + elem } / tally_scores.size
  end

  def self.average_ilo_score_for(term, ilo)
    scores = alo_ilo_query(discussion_assessment_query, term, ilo, :discussions)
    scores << alo_ilo_query(assignments_assessment_query, term, ilo, :assignments)
    tally_scores = scores.flatten
    return nil unless tally_scores.any?
    # get average ALO score accross coursework for student
    tally_scores.inject(0.0) { |acc, elem| acc + elem } / tally_scores.size
  end

  def self.alo_ilo_query(coursework_query, term, ilo, query_type)
    AssessmentLearningOutcome.joins(coursework_query)
                             .joins(course_learning_outcome: [
                                      clo_course_terms: [
                                        clo_course_term_plo_program_terms: [
                                          plo_program_term: [
                                            ilo_term_plo_program_terms: [
                                              :ilo_term
                                            ]
                                          ]
                                        ]
                                      ]
                                    ])
                             .where(ilo_terms: { term_id: term.id, ilo_id: ilo.id })
                             .where(query_type => { section_id: Section.where(term_id: term.id).pluck(:id) })
                             .pluck(:score).select { |t| t >= 1 && t <= 4 }
  end

  def self.alo_plo_query(coursework_query, term, plo, query_type)
    AssessmentLearningOutcome.joins(coursework_query)
                             .joins(course_learning_outcome: [
                                      clo_course_terms: [
                                        clo_course_term_plo_program_terms: [
                                          plo_program_term: [
                                            :plo,
                                            program_term: %I[term]
                                          ]
                                        ]
                                      ]
                                    ])
                             .where(plos: { id: plo.id })
                             .where(query_type => { section_id: Section.where(term_id: term.id).pluck(:id) })
                             .pluck(:score).select { |t| t >= 1 && t <= 4 }
  end
end
