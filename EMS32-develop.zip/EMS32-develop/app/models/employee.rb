class Employee < ApplicationRecord

  belongs_to :user
  validates :user_id, uniqueness: true


  def full_name
    [user.first_name, user.last_name].join(" ")
  end
end
