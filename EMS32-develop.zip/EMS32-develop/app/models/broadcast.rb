# Broadcasts without department specified are intended to be public facing
# and accessible to all users.
#
# Example: An ITU administrator notifying all students and
# staff that campus hours have been extended for a particular date.
class Broadcast < ApplicationRecord
  AGE_CUTOFF = 90.days

  # Mailing status
  enum status: %i[pending started delivered errored]

  belongs_to :user, foreign_key: 'creator_id'
  belongs_to :department

  validates :title, presence: true
  validates :content, presence: true

  # Adding buffer time of one minute
  # which allows us to create the announcement instantly
  validates_datetime :published_at,
                     on_or_after: -> { 1.minute.ago },
                     if: :new_or_upcoming?

  # Don't enforce future dates if we're validating a broadcast
  # that has already been published
  validates_datetime :published_at

  validate :visible_to_students_or_faculty_or_both_checked
  validate :published_at_immutable_after_delivery

  scope :recent, -> { order(published_at: :desc) }

  scope :by_department_or_global, (lambda do |department_ids|
    where(department_id: department_ids).or(where(department_id: nil))
  end)

  scope :for_students, -> { where(visible_to_students: true) }
  scope :for_faculty,  -> { where(visible_to_faculty: true)  }

  # constant inheritance doesn't work for scopes since they are defined
  # at load time(?). So self will only ever point to the parent class
  def self.current
    where(
      arel_table[:published_at].gteq(self::AGE_CUTOFF.ago).and(
        arel_table[:published_at].lteq(Time.current)
      )
    )
  end

  private

  def visible_to_students_or_faculty_or_both_checked
    return if visible_to_students || visible_to_faculty
    errors.add :base, :target_is_not_specified
  end

  def published_at_immutable_after_delivery
    return if pending? || !published_at_changed?
    errors.add :published_at, :changed_after_delivery
  end

  def new_or_upcoming?
    new_record? || published_at_was.future?
  end
end
