# frozen_string_literal: true

class CourseTerm < ApplicationRecord
  has_many   :clo_course_terms, dependent: :destroy
  has_many   :course_learning_outcomes, through: :clo_course_terms
  belongs_to :course
  belongs_to :term
  has_many :coursework, as: :courseworkable

  scope :published, -> { where(published: true).order('term_id desc') }

  def signature_assignment
    coursework.where(kind: :signature).last&.content
  end

  def self.for_course_and_term(course, term)
    joins(:course).where(course_id: course.id, term_id: term.id)
  end

  def publish!
    duplicate_signature_assignment_to_course_term
    copy_signature_assignments_to_term_sections
    create_clo_course_term_links
    self.published = true
    save
  end

  def duplicate_signature_assignment_to_section(section)
    return nil unless signature_assignment
    section.coursework.where(kind: :signature).destroy_all
    sig_ass = signature_assignment.deep_clone

    sig_ass.starts_at = section.starts_at
    sig_ass.ends_at = section.ends_at

    coursework = Coursework.create(kind: :signature, courseworkable: section)

    sig_ass.coursework = coursework
    sig_ass.save

    if sig_ass.errors.any?
      logger.info "#{sig_ass.title} is invalid. Reason(s)"
      logger.info sig_ass.errors.full_messages.join(', ')
      coursework.destroy!
    else
      duplicate_links signature_assignment, sig_ass
      duplicate_assets signature_assignment, sig_ass
      duplicate_alos sig_ass
    end

    sig_ass
  end

  private

  def copy_signature_assignments_to_term_sections
    course.sections.where(term: term).each do |section|
      duplicate_signature_assignment_to_section section
    end
  end

  def create_clo_course_term_links
    course.course_learning_outcomes.current.where(section: nil).each do |clo|
      clo_course_term = CloCourseTerm.where(course_learning_outcome: clo, course_term: self)
                                     .first_or_create!

      create_clo_course_term_plo_program_term_links clo_course_term
    end
  end

  def create_clo_course_term_plo_program_term_links(clo_course_term)
    clo = clo_course_term.course_learning_outcome
    program_term = ProgramTerm.where(program: course.program, term: term).first
    program_term.plo_program_terms.each do |plo_program_term|
      next unless clo.plos.include? plo_program_term.plo
      clo_course_term.plo_program_terms << plo_program_term
    end
  end

  def duplicate_alos(sig_ass)
    course.signature_assignment.course_learning_outcomes.each do |clo|
      next unless course.course_learning_outcomes.current.include?(clo)
      sig_ass.course_learning_outcomes << clo
    end
  end

  def duplicate_links(course_sig_ass, sig_ass)
    course_sig_ass.links.each do |link|
      new_link = link.deep_dup
      new_link.linkable_id = sig_ass.id
      new_link.save
    end
  end

  def duplicate_signature_assignment_to_course_term
    course_sig_ass = course.signature_assignment
    coursework.where(kind: :signature).destroy_all
    return nil unless course_sig_ass
    sig_ass = course.signature_assignment.deep_clone
    new_coursework = Coursework.create(kind: :signature, courseworkable: self)

    sig_ass.coursework = new_coursework
    sig_ass.save

    duplicate_links course_sig_ass, sig_ass

    duplicate_assets course_sig_ass, sig_ass
    duplicate_alos sig_ass
    sig_ass
  end

  def duplicate_assets(course_sig_ass, sig_ass)
    course_sig_ass.assets.each do |asset|
      new_asset = asset.deep_dup
      new_asset.attachable_id = sig_ass.id
      new_asset.attachment = asset.attachment
      new_asset.save
    end
  end
end
