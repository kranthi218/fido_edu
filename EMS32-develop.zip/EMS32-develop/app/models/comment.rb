class Comment < ApplicationRecord
  belongs_to :commentable,
             polymorphic: true
  belongs_to :user
  has_attached_file :attachment
  do_not_validate_attachment_file_type :attachment
  validates_attachment :attachment,
                       size: { less_than: 200.megabytes }
end
