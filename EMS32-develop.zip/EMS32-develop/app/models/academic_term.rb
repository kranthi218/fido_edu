class AcademicTerm < ApplicationRecord
  has_many :sections
  has_many :terms
#  validates :name, :presence => true, :uniqueness => true
end
