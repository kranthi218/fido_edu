# DiscussionTopicComment represents a particular student's
# comments on an individual DiscussionTopic.
class DiscussionComment < ApplicationRecord
  PARTICIPATABLE_TYPES = %w[Faculty Student].freeze

  has_ancestry orphan_strategy: :adopt
  belongs_to :participatable, polymorphic: true
  belongs_to :user
  belongs_to :discussion
  has_many :assets, as: :attachable

  accepts_nested_attributes_for :assets, allow_destroy: true

  validates :discussion_id,
            presence: true
  validates :user_id,
            presence: true
  validates :participatable_id,
            presence: true
  validates :participatable_type,
            presence: true,
            inclusion: { in: PARTICIPATABLE_TYPES }
  validates :content,
            presence: true

  scope(:from_student, lambda do |discussion_id, student_id|
    where(discussion_id: discussion_id)
      .where(participatable_type: 'Student')
      .where(participatable_id: student_id)
  end)

  scope :visible, -> { where(hidden: false) }

  alias replies children

  after_create :build_participation_indicator, if: :participatable_is_student?

  after_destroy do
    destroy_participant_indicator if participatable_is_student? && only_comment_by_author?
  end

  def read_by_user?(user)
    DiscussionCommentReader.new(user, discussion).read? self
  end

  def mark_as_read_by_user(user)
    DiscussionCommentReader.new(user, discussion).read_comment! self
  end

  def mark_as_unread_by_user(user)
    DiscussionCommentReader.new(user, discussion).unread_comment! self
  end

  private

  def build_participation_indicator
    discussion.discussion_participants
              .find_or_create_by(student: participatable, section: discussion.section)
  end

  def destroy_participant_indicator
    discussion.discussion_participants
              .find_by(student: participatable, section: discussion.section)
              .try(:destroy)
  end

  def participatable_is_student?
    participatable_type == 'Student'
  end

  # Indicate if there are any other discussion comments by this comment's
  # author that share this discussion id.
  def only_comment_by_author?
    discussion.discussion_comments
              .where(user: user)
              .where(self.class.arel_table[:id].not_eq(id))
              .none?
  end
end
