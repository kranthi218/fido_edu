# A Discussion represents a topic of discourse with a tree-like
# collection of comments/responses to that topic.
class Discussion < ApplicationRecord
  include AssetsExtension
  include CourseworkExtension
  include LinksExtension
  include PublicActivity::Common

  # belongs_to :section, touch: true

  has_many :activities, as: :trackable, dependent: :destroy

  belongs_to :course_module

  has_many :discussion_participants
  has_many :students, through: :discussion_participants
  has_many :discussion_comments
  has_many :assessment_learning_outcomes, as: :assessment
  has_many :course_learning_outcomes,
           through: :assessment_learning_outcomes,
           as: :assessment,
           dependent: :destroy

  validates :points, numericality: { greater_than_or_equal_to: 0 }
  validates_presence_of :title
  validates_presence_of :topic

  accepts_nested_attributes_for :assets, allow_destroy: true

  alias_attribute :submissions, :discussion_participants

  delegate :graded, :ungraded, to: :discussion_participants

  def self.for_student(student)
    where(section_id: student.section_ids)
  end

  # For create_activity method and grader widget
  alias_attribute :title, :topic

  def faculty_users
    coursework.section&.faculty.map(&:user)
  end

  def visible_discussion_comments
    discussion_comments.where(hidden: false)
  end

  def unread_comments(current_user, read_discussion_comment_ids)
    dc_arel = DiscussionComment.arel_table
    discussion_comments
      .where(dc_arel[:user_id].not_eq(current_user.id))
      .where(dc_arel[:id].not_in(read_discussion_comment_ids))
  end
end
