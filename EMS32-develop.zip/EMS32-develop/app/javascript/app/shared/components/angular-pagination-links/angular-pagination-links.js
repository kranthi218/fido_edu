;(function (angular) {

  function paginationLinks ($state, $parse) {

    // Helper functions

    // Create page object used in template
    function makePage (number, text, isActive) {
      return {
        number: number,
        text: text,
        active: isActive
      };
    }

    function calculateTotalPages (totalItems, itemsPerPage) {
      var totalPages = itemsPerPage < 1 ? 1 : Math.ceil(totalItems / itemsPerPage);
      return Math.max(totalPages || 0, 1);
    }

    function generatePages (currentPage, totalPages, maxSize, rotate) {
      var pages = [];

      // Default page limits
      // Default page limits
      var startPage = 1,
          endPage = totalPages,
          isMaxSized = maxSize && maxSize < totalPages;

      // recompute if maxSize
      if (isMaxSized) {
        if (rotate) {
          // Current page is displayed in the middle of the visible ones
          startPage = Math.max(currentPage - Math.floor(maxSize/2), 1);
          endPage   = startPage + maxSize - 1;

          // Adjust if limit is exceeded
          if (endPage > totalPages) {
            endPage   = totalPages;
            startPage = endPage - maxSize + 1;
          }
        } else {
          // Visible pages are paginated with maxSize
          startPage = ((Math.ceil(currentPage / maxSize) - 1) * maxSize) + 1;

          // Adjust last page if limit is exceeded
          endPage = Math.min(startPage + maxSize - 1, totalPages);
        }
      }

      // Add page number links
      for (var number = startPage; number <= endPage; number++) {
        var page = makePage(number, number, number === currentPage);
        pages.push(page);
      }

      // Add links to move between page sets
      if (isMaxSized && ! rotate) {
        if (startPage > 1) {
          var previousPageSet = makePage(startPage - 1, '...', false);
          pages.unshift(previousPageSet);
        }

        if (endPage < totalPages) {
          var nextPageSet = makePage(endPage + 1, '...', false);
          pages.push(nextPageSet);
        }
      }

      return pages;
    }

    // Component controller and link functions

    function paginationLinksCtrl ($scope, $attrs) {
      var vm = this;

      vm.initPages = function () {
        vm.totalPages = calculateTotalPages(vm.totalItems, vm.itemsPerPage);
        vm.pages = generatePages(vm.currentPage, vm.totalPages, vm.maxSize, vm.rotate);
      };

      var maxSize = $attrs.maxSize && parseInt($attrs.maxSize, 10);
      if (!maxSize || isNaN(maxSize) || maxSize <= 1) maxSize = 9;
      vm.maxSize = maxSize;

      if (!vm.itemsPerPage) vm.itemsPerPage = 10;
      vm.currentPage = vm._currentPage || 1;

      vm.rotate = $attrs.rotate !== 'false';
      vm.initPages();

      vm.pageParamName  = $attrs.pageParamName;
      vm.directionLinks = $attrs.directionLinks === 'true';
      vm.boundaryLinks  = $attrs.boundaryLinks !== 'false';
      vm.useClicks = $attrs.useClicks === 'true';

      var texts = ['previousText', 'nextText', 'firstText', 'lastText'];
      for (var i = 0; i < texts.length; i++) {
        var textKey = texts[i];
        if (!vm[textKey] && $attrs[textKey]) vm[textKey] = $attrs[textKey];
      }


      vm.getLinkToPage = function (page) {
        var stateParams = {};
        stateParams[vm.pageParamName || 'page'] = page;

        return $state.href(vm.linksToState || $state.current.name, stateParams, { inherit: true });
      };

      vm.isActive = function (page) {
        return vm.currentPage === page.number;
      };

      vm.noPreviousPage = function () {
        return vm.currentPage === 1;
      };

      vm.noNextPage = function () {
        return vm.currentPage === vm.totalPages;
      };

      vm.isDisabled = function () {
        return false;
      };

      vm.changePage = function (number) {
        vm.currentPage = number;
        vm._currentPage = number;
      }

      $scope.$watch('vm._currentPage', function (newValue) {
        vm.currentPage = newValue || 1;
        vm.initPages();
      });

      $scope.$watchGroup(['vm.totalItems', 'vm.itemsPerPage'], function () {
        vm.initPages();
      });
    }


    return {
      restrict: 'EA',
      scope: {},
      controller: ['$scope', '$attrs', paginationLinksCtrl],
      controllerAs: 'vm',
      bindToController: {
        _currentPage: '=currentPage',
        totalItems: '=',
        itemsPerPage: '=',
        useClicks: '=?',
        onChange: '&',
        linksToState: '@'
      },
      templateUrl: function(element, attrs) {
        var url = 'app/shared/components/angular-pagination-links/templates/_pagination-links.html';

        if( attrs.useClicks === "true") {
          url = 'app/shared/components/angular-pagination-links/templates/_pagination-clicks.html';
        }
        return url;
      }
    };
  }


  angular.module('angular-pagination-links', [])
    .directive('paginationLinks', [
      '$state',
      '$parse',
      paginationLinks
    ]);

})(angular);
