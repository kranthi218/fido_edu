/*
 * angular-modalbox v0.1.16
 *
 * Simple and nice modal component for AngularJS
 * Somewhat based on Angular UI Bootstrap Modal concept but is different in that:
 * - Not tied to Twitter Bootstrap (despite that being a nice choice)
 * - Doesn't use onTransitionEnd event and uses ngAnimate animations instead
 * - Modals can appear over multiple containers
 * - Loading indicators while data is being resolved / templates being loaded
 */


'use strict';

;(function (factory) {

  if (typeof define === 'function' && define.amd) {
    define(['angular'], function (angular) {
      return factory(angular, document);
    });
  } else {
    factory(angular, document);
  }

}(function (angular, document, undefined) {

  angular.module('angular-modalbox', [])

    .provider('modalbox', function () {

      var _provider = this;

      _provider.settings = {
        baseZIndex:        1040,
        containerCssClass: 'modalbox-open modal-open',
        loadingIndicatorTemplate: '<div class="modalbox-loading-indicator modalbox-loading-indicator-animate">' +
                                  '<div class="modalbox-loading-icon"><div class="icon fa fa-refresh fa-spin"></div></div></div>'
      };

      _provider.defaults = {
        cssClass:           '',
        backdropCssClass:   '',
        container:          'body',
        keyboard:           true,
        backdrop:           true,
        loadingIndicator:   true,
        template:           false,
        templateUrl:        false,
        resolve:            {}
      };

      this.$get = ['$injector', '$document', '$rootScope', '$compile', '$q', '$http', '$templateCache', '$animate', '$controller', '$timeout',
        function ($injector, $document, $rootScope, $compile, $q, $http, $templateCache, $animate, $controller, $timeout) {

          // Internal helper functions

          function isResolvable (value) {
            return angular.isFunction(value) || angular.isArray(value);
          }

          function shouldPreload (modalbox) {
            var resolvables = 0;

            if (modalbox.resolve) {
              angular.forEach(modalbox.resolve, function (value, key) {
                if (isResolvable(value)) resolvables++;
              });
            }

            return (!modalbox.template && !$templateCache.get(modalbox.templateUrl)) || resolvables > 0;
          }

          function getTemplatePromise (modalbox) {
            return modalbox.template ?
              $q.when(modalbox.template) :
              $http.get(modalbox.templateUrl, { cache: $templateCache }).then(function (result) {
                return result.data;
              });
          }

          function getPreloadingPromises (modalbox) {
            var promises = [];

            // Note: template promise is always first
            promises.push(getTemplatePromise(modalbox));

            // Custom resolve promises
            if (modalbox.resolve) {
              angular.forEach(modalbox.resolve, function (value, key) {
                promises.push($q.when(isResolvable(value) ? $injector.invoke(value) : value));
              });
            }

            return promises;
          }

          function showLoadingIndicator (modalbox) {
            if (!modalbox || !modalbox.loadingIndicator || !_provider.settings.loadingIndicatorTemplate) return;

            var loadingEl = angular.element(_provider.settings.loadingIndicatorTemplate);
            loadingEl.css('z-index', _provider.settings.baseZIndex + 5 + modalbox.layerIndex * 10);
            if (!modalbox.backdrop) loadingEl.addClass('no-backdrop');

            $animate.enter(loadingEl, modalbox.$containerEl);

            modalbox.$loadedPromise.finally(function () {
              $animate.leave(loadingEl).then(function () {
                loadingEl = undefined;
              });
            });
          }


          // Stack keeps track of all our modalboxes
          // and maintains the correct order.
          var modalboxStack = {
            modalboxes: [],

            top: function ($containerEl, visibleOnly, withBackdropOnly) {
              visibleOnly = !!visibleOnly;

              if (!$containerEl && !visibleOnly && !withBackdropOnly) {
                return this.modalboxes[this.modalboxes.length - 1];
              }

              for (var i = this.modalboxes.length - 1; i >= 0; i--) {
                if (!$containerEl || (this.modalboxes[i].$containerEl && this.modalboxes[i].$containerEl[0] === $containerEl[0])) {
                  if (!visibleOnly || (visibleOnly && this.modalboxes[i].$shown)) {
                    if (!withBackdropOnly || (withBackdropOnly && this.modalboxes[i].backdrop)) return this.modalboxes[i];
                  }
                }
              }

              return null;
            },

            count: function ($containerEl) {
              if (!$containerEl) return this.modalboxes.length;
              if (!$containerEl.length) return 0;

              var count = 0;
              this.modalboxes.forEach(function (modalbox) {
                if (modalbox.$containerEl && $containerEl[0] === modalbox.$containerEl[0]) count++;
              });

              return count;
            },

            add: function (modalbox) {
              if (!modalbox) return;
              this.modalboxes.push(modalbox);
            },

            remove: function (modalbox) {
              for (var i = 0; i < this.modalboxes.length; i++) {
                if (this.modalboxes[i] === modalbox) this.modalboxes.splice(i, 1);
              }
            }
          };


          // Internal service to manage backdrops
          var backdropUtil = {

            // Internal cache to quickly find backdrops by container element
            byContainer: {},

            // Show the backdrop for given modalbox if there is no
            // backdrop in its container yet. If there is one -
            // it just applies appropriate css classes and adjusts
            // z-index accordingly.
            showBackdropFor: function (modalbox) {
              if (!modalbox || !modalbox.backdrop) return;

              var backdrop = backdropUtil.byContainer[modalbox.$containerEl[0]];
              var isNewBackdrop = false;

              if (!backdrop) {
                backdrop = {
                  $el: angular.element('<div modalbox-backdrop class="modalbox-backdrop modalbox-backdrop-animate modal-backdrop"></div>'),
                  layerIndex: -1,
                  cssClasses: []
                };

                isNewBackdrop = true;
              }

              // Adjust z-index
              backdrop.layerIndex = modalbox.layerIndex;
              this.adjustZIndex(backdrop);

              // Switch CSS classes
              var topVisible = modalboxStack.top(modalbox.$containerEl, true, true);
              if (topVisible && topVisible.backdropCssClass) backdrop.$el.removeClass(topVisible.backdropCssClass);
              if (modalbox.backdropCssClass) backdrop.$el.addClass(modalbox.backdropCssClass);

              // Update the cache
              backdropUtil.byContainer[modalbox.$containerEl[0]] = backdrop;

              if (isNewBackdrop) $animate.enter(backdrop.$el, modalbox.$containerEl);
            },

            // Hides the backdrop for given modalbox
            // if there are no visible modalboxes for its
            // container. If there is another box in the stack
            // though, it will apply appropriate css classes
            // and adjust z-index accordingly.
            hideBackdropFor: function (modalbox) {
              var $containerEl = modalbox.$containerEl;
              var topVisible = modalboxStack.top($containerEl, true, true);
              var backdrop = backdropUtil.byContainer[$containerEl[0]];

              if (!backdrop) return;

              // Actually destroy backdrop in this case
              if (!topVisible) {
                // Deregister the backdrop right away so that
                // if new modalbox activates in the same container,
                // it has a chance to create new one, as this one is
                // guaranteed to be destroyed from now on
                backdropUtil.byContainer[$containerEl[0]] = undefined;
                $animate.leave(backdrop.$el).then(function () {
                  backdrop.$el = null;
                });

                return;
              }

              // Adjust z-index and CSS classes otherwise
              if (modalbox.backdropCssClass) backdrop.$el.removeClass(modalbox.backdropCssClass);

              if (topVisible) {
                if (topVisible.backdropCssClass) backdrop.$el.addClass(topVisible.backdropCssClass);
                backdrop.layerIndex = topVisible.layerIndex;
                this.adjustZIndex(backdrop);
              }
            },

            adjustZIndex: function (backdrop) {
              backdrop.$el.css('z-index', _provider.settings.baseZIndex + (backdrop.layerIndex && 1 || 0) + backdrop.layerIndex * 10);
            }
          };


          // Scope convenience methods and properties
          function extendScope (modalbox) {
            var scope = modalbox.scope;

            angular.extend(modalbox.scope, {

              $show: function () {
                scope.$$postDigest(function () {
                  modalbox.$show();
                });
              },

              $hide: function () {
                scope.$$postDigest(function () {
                  modalbox.$hide();
                });
              },

              $resolve: function (result) {
                scope.$$postDigest(function () {
                  modalbox.$resolve(result);
                });
              },

              $reject: function (reason) {
                scope.$$postDigest(function () {
                  modalbox.$reject(reason);
                });
              },

              $close: function (result) {
                scope.$$postDigest(function () {
                  modalbox.$close(result);
                });
              },

              $dismiss: function (reason) {
                scope.$$postDigest(function () {
                  modalbox.$dismiss(reason);
                });
              }
            });

            Object.defineProperty(modalbox.scope, '$shown', {
              get : function () { return !!modalbox.$shown; },
              enumerable : true,
              configurable : true
            });

            Object.defineProperty(modalbox.scope, '$hidden', {
              get : function () { return !modalbox.$shown; },
              enumerable : true,
              configurable : true
            });

            Object.defineProperty(modalbox.scope, '$loading', {
              get : function () { return !!modalbox.$loading; },
              enumerable : true,
              configurable : true
            });
          }


          // Modalbox shows/hides itself but these
          // neat "callbacks" handle all of the other
          // stuff like backdrops, container classes, etc
          function onModalboxShow (modalbox) {
            modalbox.$containerEl.addClass(_provider.settings.containerCssClass);
            if (modalbox.loadingIndicator) showLoadingIndicator(modalbox);
            backdropUtil.showBackdropFor(modalbox);
          }

          function onModalboxHide (modalbox) {
            backdropUtil.hideBackdropFor(modalbox);

            if (!modalboxStack.count(modalbox.$containerEl)) {
              modalbox.$containerEl.removeClass(_provider.settings.containerCssClass);
            }
          }


          // Modalbox "class"
          var Modalbox = function (options) {
            angular.extend(this, _provider.defaults, options);

            if (!this.template && !this.templateUrl) {
              throw new Error('Modalbox needs either "template" or "templateUrl" option defined.');
            }

            var _this = this;

            this.scope = (options.scope || $rootScope).$new();

            this.$shown = false;
            this.$loading = false;

            // Deferreds

            this.$loadedDeferred = $q.defer();
            this.$loadedPromise = this.$loadedDeferred.promise;

            this.$deferred = $q.defer();
            this.$promise = this.$deferred.promise;

            extendScope(this);

            // Container and layer index inside that
            this.$containerEl = angular.element(document.querySelector(this.container || 'body'));
            this.layerIndex = modalboxStack.count(this.$containerEl);


            if (!shouldPreload(this)) {
              // No need to show an indicator if nothing to preload
              this.loadingIndicator = false;
            } else {
              this.$loading = true;
              this.$loadedPromise.finally(function () {
                _this.$loading = false;
              });
            }

            this.$promise.finally(function () {
              _this.$destroy();
            });

            // Preload both template and whatever we have in `resolve`
            // Note: Even if there is nothing to preload, to simplify the
            // code and avoid lots of checks for template,
            // everything is handled here
            $q.all(getPreloadingPromises(this)).then(function (resolved) {
              // Note: resolved[0] is always existing or resolved template
              _this.template = resolved.shift();

              // In case controller is specified - initialize it
              if (_this.controller) {
                var ctrlLocals = {
                  $scope: _this.scope,
                  modalboxInstance: _this
                };

                var i = 0;
                angular.forEach(_this.resolve, function (value, key) {
                  ctrlLocals[key] = resolved[i++];
                });

                $controller(_this.controller, ctrlLocals);
              }

              _this._initElement();
              _this.$el.append($compile(angular.element(_this.template))(_this.scope));
              _this.$loadedDeferred.resolve();
            }, function (reason) {
              _this.$loadedDeferred.reject(reason);
              _this.$deferred.reject(reason);
            });

            // Add to stack so that it can be tracked,
            // searched and take part in ordering (z-index adjustments)
            modalboxStack.add(this);
          };

          angular.extend(Modalbox.prototype, {

            _initElement: function () {
              var rawModalboxEl = angular.element('<div tabindex="-1" modalbox class="modalbox modalbox-animate modal open"></div>');
              rawModalboxEl.data('modalboxInstance', this);
              this.$el = $compile(rawModalboxEl)(this.scope);

              this.$el.css('z-index', _provider.settings.baseZIndex + 10 + this.layerIndex * 10);
            },

            get $hidden () {
              return !this.$shown;
            },

            $show: function (options) {
              var _this = this;

              if (this.loadingIndicator) onModalboxShow(this);

              return this.$loadedPromise.then(function () {
                _this.$shown = true;
                if(!_this.loadingIndicator) onModalboxShow(_this);

                return $animate.enter(_this.$el, _this.$containerEl);
              });
            },

            $hide: function (options) {
              this.$shown = false;
              onModalboxHide(this);

              return $animate.leave(this.$el);
            },

            $resolve: function (result) {
              this.$deferred.resolve(result);
            },

            $reject: function (reason) {
              this.$deferred.reject(reason);
            },

            // Alias for `$resolve()`
            $close: function (result) {
              return this.$resolve(result);
            },

            // Alias for `$reject()`
            $dismiss: function (reason) {
              return this.$reject(reason);
            },

            $destroy: function () {
              var _this = this;

              var doDestroy = function () {
                if (_this.scope) _this.scope.$destroy();

                if (_this.$el) {
                  _this.$el.remove();
                  _this.$el = null;
                }

                _this.$containerEl = null;
              };

              // Remove from the stack
              modalboxStack.remove(this);

              if (this.$shown) {
                this.$hide().then(function () {
                  doDestroy();
                });
              } else {
                doDestroy();
              }
            }
          });


          // ESC key support
          $document.bind('keydown', function (e) {
            if (e.which === 27) {
              var modalbox = modalboxStack.top(null, true);

              if (modalbox && modalbox.keyboard) {
                $rootScope.$apply(function () {
                  modalbox.$dismiss();
                });
              }
            }
          });


          // Public service API
          return {
            // Just init, don't show
            $new: function (options) {
              return new Modalbox(options);
            },

            $show: function (options) {
              var modalbox = this.$new(options);
              modalbox.$show();
              return modalbox;
            }
          };

        }];

    })

    .directive('modalbox', ['modalbox', '$timeout', function (modalbox, $timeout) {
      return {
        restrict: 'EA',
        replace: true,
        transclude: true,
        scope: { },
        template: '<div ng-click="dismiss($event)" ng-transclude></div>',
        link: function (scope, el, attrs) {
          $timeout(function () {
            el[0].focus();
          });

          var mb = el.data('modalboxInstance');
          if (!mb) return;


          scope.dismiss = function (e) {
            if (e.target !== e.currentTarget) return;

            if (mb && mb.backdrop !== 'static') {
              e.preventDefault();
              e.stopPropagation();
              mb.$dismiss();
            }
          };
        }
      };
    }]);

}));
