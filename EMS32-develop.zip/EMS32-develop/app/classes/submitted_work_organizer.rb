# Provides a useful interface to student submission models such as:
# StudentAssignment, DiscussionParticioant, QuizScores
class SubmittedWorkOrganizer
  attr_reader :submissions

  def initialize(section, student)
    @section     = section
    @student     = student
    @submissions = gather_submissions
    @deadlines   = @student.deadlines_for_section(@section)
  end

  # Return or hide submission score if:
  #  - susmission is not yet graded
  #  - submission is a quiz score and was set to hide result
  # @param work [StudentAssignment, DiscussionParticipant, QuizScore]
  # @return [float]
  def score_if_visible(work)
    return 0.0 unless work.graded?
    return work.score unless work.is_a?(QuizScore)
    return work.score unless work.coursework.hide_scores_on_submission

    due_date(work.coursework).past? ? work.score : 0.0
  end

  # @ Check whether student submissions is draft
  # @param work [StudentAssignment, DiscussionParticipant, QuizScore]
  # @return [boolean]
  def draft?(work)
    return false unless work.is_a?(StudentAssignment)

    return false if work.published?
    return false if @section.ends_at.past?
    return true  if work.coursework.soft_deadline

    due_date(work.coursework).future?
  end

  # Detects whether submission was made late
  # @param work [StudentAssignment, DiscussionParticipant, QuizScore]
  # @return [boolean]
  def late?(work)
    return false unless work.coursework.try(:soft_deadline)
    return false unless work.submitted_at

    work.submitted_at > work.coursework.ends_at
  end

  def points_earned_to_date
    submissions.reduce(0.0) do |sum, work|
      if work.graded? && work.score
        sum + work.score
      else
        sum
      end
    end
  end

  def visible_points_earned_to_date
    submissions.reduce(0.0) do |sum, work|
      sum + score_if_visible(work)
    end
  end

  def submission_for(coursework)
    @submissions.find { |e| e.coursework == coursework }
  end

  def due_date(coursework)
    deadline(coursework).try(:ends_at) || coursework.ends_at
  end

  private

  def deadline(coursework)
    @deadlines.find { |e| e.coursework == coursework }
  end

  def gather_submissions
    assignments = StudentAssignment
                  .submissions_for_student_for_section(@section.id, @student.id)
    discussions = DiscussionParticipant
                  .submissions_for_student_for_section(@section.id, @student.id)
    quizzes     = QuizScore
                  .scores_for_student_for_section(@section.id, @student.id)
    assignments + discussions + quizzes
  end
end
