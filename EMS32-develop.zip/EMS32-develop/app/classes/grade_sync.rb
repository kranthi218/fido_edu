require 'course_code'

# This class encapsulates the logic reqiured to export student grades from
# EMS back to Janzebar/Ex
class GradeSync
  GENERAL_LOGGER_MSG = <<-MSG.strip_heredoc
    [ERROR] %s - SectionStudent ID: %s
    [BACKTRACE] %s
  MSG

  class GradeSyncError < StandardError
    attr_reader :parameters

    def initialize(parameters = {})
      @parameters = parameters
    end
  end

  # Raised when try to find StudentCourseHistory failed during sync process
  class NoStudentCourseHistoryError < GradeSyncError
    LOGGER_MSG = '[SKIP] No StudentCourseHistory for SectionStudent(%s)'.freeze

    def message
      @message ||= <<-MSG.strip_heredoc.gsub(/(\s+)/, ' ').strip
        An error occurred while attempting to detect corresponding to
        SectionStudent Ex::Rw::StudentCourseHistory when syncing grades
      MSG
    end
  end

  # Raised if no mathing to Ex::Section for EMS Section found
  class NoExSectionError < GradeSyncError
    LOGGER_MSG = '[ERROR] No Ex::Section for EMS Section(%s)'.freeze

    def message
      @message ||= 'An error occurred while attempting find Ex::Section'
    end
  end

  # Raised if orphaned SectionStudent detected
  class OrphanedSectionStudentError < StandardError
    LOGGER_MSG = '[SKIP] Can not find Student for SectionStudent(%s)'.freeze

    def message
      @message ||= <<-MSG.strip_heredoc.gsub(/(\s+)/, ' ').strip
        An error occured on attempt to load related to SectionStudent
        Student record when syncing grades
      MSG
    end
  end

  # Raised if CourseCodeParser parser returns nil
  class CourseCodeParseError < GradeSyncError
    LOGGER_MSG = '[SKIP] no course for %s'.freeze

    def message
      @message ||= 'An error occurred while attempting to parse coursecode'
    end
  end

  class WithdrawnSectionStudent < GradeSyncError
    LOGGER_MSG = '[SKIP] Will not apply grade for Withdrawn StudentCourseHistory'.freeze

    def message
      @message ||= <<-MSG.strip_heredoc
        A StudentCourseHistory has been recorded as withdrawn, but a
        SectionStudent with a grade exists
      MSG
    end
  end

  attr_writer :logger
  attr_reader :ex_grades

  def initialize
    @parser = CourseCodeParser.new
    @ex_grades = Ex::Grade.all

    yield(self) if block_given?
  end

  def sync_user(sect_st)
    sch = Ex::Rw::StudentCourseHistory.find_by_section_student(sect_st)

    raise NoStudentCourseHistoryError unless sch.present?

    update_grade!(sect_st, sch)

  rescue GradeSyncError => e
    report_error(e, section_student_id: sect_st.id)
  end

  # Sync single Section Final Grades to Ex
  # @param section [Section] EMS Section to sync and finalize
  def sync_section!(section)
    ex_section = find_ex_section(section)
    sync_ex_section(ex_section)
  rescue GradeSyncError, ActiveRecord::RecordNotFound => e
    report_error(e, section_id: section.id)
  end

  # @param ex_sections [Array<Ex::Section>, ActiveRecord::Relation]
  #   A collection of Ex::Section records which we are to find and import
  #   enrollments for.
  def sync!(ex_sections)
    ex_sections.select do |ex_section|
      begin
        sync_ex_section(ex_section)
      rescue GradeSyncError => e
        report_error(e)
      end
    end
  end

  private

  def find_ex_section(section)
    Ex::Section
      .active
      .for_term(section.term)
      .find_by(crs_cde: section.ex_course_code) || raise(NoExSectionError)
  end

  def sync_ex_section(ex_section)
    cc = parse_crs_cde!(ex_section)

    # Select the graded section with a matching section number
    # not yet submitted
    sect = cc.sections(ex_section.ems_term.id)
             .find_by(
               section: cc.section,
               grades_submitted: true,
               finalized: false
             )

    # Nothing to do
    return unless sect

    # Skip sync date conditions if section was not synced yet
    updated_after_sync =
      if sect.synced_at
        SectionStudent.arel_table[:updated_at].gt(sect.synced_at)
      else
        'TRUE'
      end

    sect_sts = SectionStudent
               .active_enrollments
               .includes(:grade, student: :user)
               .where(section_id: sect.id)
               .where(updated_after_sync)
               .where.not(grade_id: nil)

    schs = ex_section.ex_rw_student_course_histories.active_courses

    return unless update_grades!(sect_sts, schs)

    # Finalize section
    sect.update(finalized: true, synced_at: Time.now)
  end

  # This metod trying to find corresponding to SectionStudent Ex record
  # and update its grade to match submitted in EMS
  #
  # @param sect_sts [ActiveRecord::Relation<SectionStudent>] a collection of
  #   section student records representing the current enrollments for the
  #   specified section
  # @param schs [Array<Ex::Rw::StudentCourseHistory>] a collection
  #   of student course history records from Ex representing the desired
  #   enrollments for a section inherited from Ex::Rw
  # @return [Boolean] will return true if no errors happens during transaction
  def update_grades!(sect_sts, schs)
    Ex::Rw.transaction do
      sect_sts.find_each do |sect_st|
        begin
          sch = schs.find do |i|
            i.id_num == sect_st.student.student_number.to_i
          end
          raise NoStudentCourseHistoryError unless sch.present?

          update_grade!(sect_st, sch) if sch.grade_cde.blank?

        rescue GradeSyncError => e
          report_error(e, section_student_id: sect_st.id)
        rescue => e
          report_general_error(e, sect_st)
        end
      end

      return true
    end
  end

  def update_grade!(sect_st, sch)
    raise OrphanedSectionStudentError unless sect_st.student
    raise WithdrawnSectionStudent if sch.withdrawn?
    if sect_st.grade.nil?
      sch.ex_grade = nil
      sch.transaction_sts = 'C'
    else
      grade_cde = sect_st.grade.janzebar_name
      sch.ex_grade = ex_grades.find { |g| g.grade_cde == grade_cde }
      sch.transaction_sts = 'H'
    end

    sch.save
  end

  def parse_crs_cde!(ex_section)
    crs_cde = ex_section.crs_cde.strip

    @parser.parse(crs_cde) or
        fail CourseCodeParseError.new(crs_cde: crs_cde)
    end

  # Notify Airbrake of problems when we fail to sync grades
  # for particular SectionStudent. And drop a line to logger
  #
  # @param error [Exception] a class inheritet of any kind of Exception,
  #   used to generate useful error messages when reporting to Airbrake.
  #   LOGGER_MSG error template for logger
  # @param parameters [Hash] any parameters need to be included in notification
  #   Values should correspond to LOGGER_MSG parameters
  def report_error(error, parameters = nil)
    parameters ||= error.parameters

    Airbrake.notify(error, parameters: parameters)
    logger.info format(error.class::LOGGER_MSG, *parameters.values)

    nil
  end

  def report_general_error(error, sect_st)
    Airbrake.notify(
      error,
      parameters: { section_student_id: sect_st.id }
    )

    logger.info format(GENERAL_LOGGER_MSG,
                       error,
                       sect_st.id,
                       error.backtrace)
    nil
  end

  def logger
    @logger ||= Logger.new(STDOUT)
  end
end
