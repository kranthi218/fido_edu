class Access::MediaTechnician < Access::AccessGroup

end
