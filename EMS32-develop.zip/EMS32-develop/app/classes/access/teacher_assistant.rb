# This group will create the access permissions needed for teacher assistants
#
class Access::TeacherAssistant < Access::AccessGroup


  # def create_or_update(data)
  #   data[:permissions].each do |permission|
  #     new_perm = Permission.where(type: permission[:type],
  #                                 term_id: permission[:term_id],
  #                                 section_id: permission[:section_id],
  #                                 department_id: permission[:department_id])
  #                                 .first_or_create
  #     unless new_perm.update_attributes(permission)
  #       @user.errors.add(:base, new_perm.errors.full_messages)
  #     end
  #   end
  # end

end
