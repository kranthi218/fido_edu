class Access::AssessmentManagement < Access::AccessGroup
end
