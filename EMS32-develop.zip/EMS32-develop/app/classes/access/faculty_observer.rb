class Access::FacultyObserver < Access::AccessGroup
  def create_or_update(group_type, group)
    group_permission = { group_type => {} }

    group.values.each do |p|
      perm = Permission.new p.merge(user_id: @user_id)
      perm.view = true if perm.update_create? || perm.trash?
      perm.update_create = true if perm.trash?

      perm.save
      group_permission[group_type][perm.group_name] = perm
    end

    non_selected_permision = Access.generate_permissions

    # overwrite the new records with the ones we have just created.
    non_selected_permision.merge(group_permission)
  end
end
