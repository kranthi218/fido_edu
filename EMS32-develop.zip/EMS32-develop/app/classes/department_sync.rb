

# This class encapsulates the logic reqiured to import courses from a
# given academic year/term
class DepartmentSync
  attr_writer :logger

  def initialize
    @logger = Logger.new(STDOUT)
  end

  def sync!(ex_departments)
    department = Department.arel_table

    ex_departments.each do |dpt|
      name_or_description = department[:number].eq(dpt.dept_cde)
                                               .or(department[:name].eq(dpt.dept_desc))

      d = Department.where(name_or_description).first_or_initialize
      d.assign_attributes(name: dpt.dept_desc, number: dpt.dept_cde)

      # notify_new(d) if d.new_record?
      @logger.debug format('created new department: %s', d.number) if d.new_record?
      d.save
    end
  end

  def notify_new(department)
    body = "Created new department #{department.name} with code #{department.number} \n\n"

    ActionMailer::Base.mail(
      from: 'dbteam+ems32-department_sync@itu.edu',
      to: 'dbteam@itu.edu',
      subject: "DepartmentSync Notification: #{Time.zone.now.to_formatted_s(:rfc822)}",
      body: body
    ).deliver!
  end
end
