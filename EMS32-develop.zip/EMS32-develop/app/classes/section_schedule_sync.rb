# This class is responsible for sync (import) data from Ex::SectionSchedule to
# EMS Section's Schedules.
# Data schemas in Ex and EMS are pretty different
# @see #stick_start_date_to_class_day
# @see #stick_end_date_to_class_day
#
class SectionScheduleSync
  # Raised if no mathing to Ex::Section for EMS Section found
  class NoExSectionError < StandardError
    LOGGER_MSG = '[ERROR] No Ex::Section for EMS Section(%s): %s '.freeze

    def message
      @message ||= 'An error occurred while attempting find Ex::Section'
    end
  end

  attr_writer :logger

  def initialize
    yield(self) if block_given?
  end

  # This method will sync schedule for every Section of desired Term
  # @param term [Term] EMS Term
  def sync!(term)
    term.sections.find_each { |section| sync_section section }
  end

  # This method will sync single Section schedule records
  # @param section [Section] EMS Section
  def sync_section(section)
    @ex_section   = find_ex_section(section)
    @ex_schedules = @ex_section.ex_section_schedules

    @ex_schedules.each do |ex_schedule|
      find_or_build_schedules(section, ex_schedule).each do |ems_schedule|
        create_or_update_schedule(ems_schedule, ex_schedule)
      end

      delete_section_schedules_except_listed_days(section, ex_schedule)
    end

    delete_section_schedules_except_listed(section, @ex_schedules)
  rescue NoExSectionError
    logger.warn format(
      NoExSectionError::LOGGER_MSG,
      section.try(:id),
      section.try(:course_and_section_no)
    )
  end

  private

  # This method will iterate through Ex::SectionSchedule days and initialize
  # Schedule records for each found day. In Ex single record may include a few
  # week days data, in EMS one record - one day.
  # @param section [Section] EMS Section
  # @param ex_schedule [Ex::SectionSchedule]
  # @return [<Array> Schedule]
  def find_or_build_schedules(section, ex_schedule)
    ex_schedule.class_days.map do |class_day|
      section.schedules.find_or_initialize_by(
        class_day: class_day,
        ex_appid: ex_schedule.appid
      )
    end
  end

  # This method will populate Schedule dates and save object
  def create_or_update_schedule(ems_schedule, ex_schedule)
    ems_schedule.assign_attributes(
      start_date:      stick_start_date_to_class_day(ems_schedule, ex_schedule),
      end_date:        stick_end_date_to_class_day(ems_schedule, ex_schedule),
      start_time:      ex_schedule.begin_tim.utc,
      end_time:        ex_schedule.end_tim.utc,
      lecture_hall_id: find_or_create_lecture_hall(ex_schedule).try(:id)
    )

    ems_schedule.save
  end

  # Ex::SectionSchedule may represent a few days of week, Schedule only one.
  # In case we have short range in ex record for example Mon, Tue, Wed, 1-3 of
  # Sept, we should create 3 ems schedule records one per day i.e. Mon 1, Tue 2,
  # Wed 3. This method will correct start date of schedule to stick
  # (start from) particular week day.
  # @param ems_schedule [Schedule]
  # @param ex_schedule  [Ex::SectionSchedule]
  def stick_start_date_to_class_day(ems_schedule, ex_schedule)
    if ems_schedule.class_day == ex_schedule.begin_weekday
      ex_schedule.begin_dte.utc.to_date
    else
      Chronic.parse(
        ems_schedule.class_day,
        now: ex_schedule.begin_dte.to_date,
        context: :future # look forward
      )
    end
  end

  # Stick to the last weekday that fit in ex_schedule range and not exceed it.
  # @see stick_start_date_to_class_day
  # @param ems_schedule [Schedule]
  # @param ex_schedule  [Ex::SectionSchedule]
  def stick_end_date_to_class_day(ems_schedule, ex_schedule)
    if ems_schedule.class_day == ex_schedule.end_weekday
      ex_schedule.end_dte.utc.to_date
    else
      Chronic.parse(
        ems_schedule.class_day,
        now: ex_schedule.end_dte.to_date,
        context: :past # look backward
      )
    end
  end

  # This method will build appids list from specified ex_schedules and use it as
  # a whitelist. All the other shedules of specified section will be removed.
  # @param section [Section]
  # @param ex_schedules [<Array> Ex::SectionSchedule]
  def delete_section_schedules_except_listed(section, ex_schedules)
    section.schedules
           .where.not(ex_appid: ex_schedules.pluck(:appid))
           .delete_all
  end

  # This method will destroy ems_schedules where ex has changed schedule details
  # @param ems_schedule [Schedule]
  # @param ex_schedule  [Ex::SectionSchedule]

  def delete_section_schedules_except_listed_days(section, ex_schedule)
    section.schedules
           .where(ex_appid: ex_schedule.appid)
           .where.not(class_day: ex_schedule.class_days)
           .delete_all
  end

  # This method will try to find Ex Section that match given EMS Section or
  # Throw error
  # @param ems_section [Section]
  # @return [Ex::Section]
  def find_ex_section(ems_section)
    Ex::Section.by_ems_section(ems_section) || raise(NoExSectionError)
  end

  # @param ex_schedule [Ex::SectionSchedule]
  # @return [LectureHall]
  def find_or_create_lecture_hall(ex_schedule)
    LectureHall.find_or_create_by(name: ex_schedule.room_cde.try(:strip))
  end

  def logger
    @logger ||= Logger.new(STDOUT)
  end
end
