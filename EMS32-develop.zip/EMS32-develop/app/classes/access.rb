# Access (Authorization) is a composite class that aggregates a user's
# permissions and answers questions as to authorization business logic.
#
# Every logged in user has their access instantiated by :load_permissions
# callback in application_controller
#
# Since authorization is full stack, you will find code that interacts with
# Access in a number of places. This code will need to be maintained in sync
# with available permissions.
#
# View Methods
#   In this system, what menus a user sees is highly dependant on what they
#   have permission to access. So you will find the methods for building menus
#   in app/decorators/user_decorator
#
#   Permissions are currently implemented as data structures, they can be found
#   in PermissionAccessDataStructures
#
#   Since available permissions are a data structure, not a table, we use
#   helpers for their view logic. That can be found helpers/admin/admim_helper
#
#   Assigned permissions also have their own view requirements, and those
#   methods live in app/decorators/permission_decorator
#
# Controller Methods
#   allowed
#
# Valid group types are:
#
# When adding new permissions, remember to update the inclusion hashes
# in permission.rb model
#
class Access
  include PermissionAccessDescriptions
  include PermissionAccessDataStructures

  attr_reader :permissions

  def initialize(user_id)
    @user_id = user_id
    @permissions = Permission.where(user_id: user_id)
  end

  def available_permissions
    VISIBLE_PERMISSION_OPTS.keys - permissions.pluck(:group_type)
  end

  #------------------------------------------------------------------
  # User's have access to the admin dash if they have one or more
  # permissions that warrant it. The menu actions they will see once in
  # dash are built in the user_decorator
  def admin_access_allowed
    admin_permissions.any?
  end

  alias staff_access_allowed? admin_access_allowed

  def admin_permissions
    permissions.active.pluck(:group_type)
  end

  def allowed(something, options = {})
    options[:action_type] ||= :view

    if something.is_a?(ActiveRecord::Base)
      allowed_object(something, options)
    else
      allowed_group(something.to_sym, options)
    end
  end

  def permission_department_id_eq_or_nil(department_id)
    particular = Permission.arel_table[:department_id].eq(department_id)
    global     = Permission.arel_table[:department_id].eq(nil)
    particular.or(global)
  end

  def permission_term_id_eq_or_nil(term_id)
    particular = Permission.arel_table[:term_id].eq(term_id)
    global     = Permission.arel_table[:term_id].eq(nil)
    particular.or(global)
  end

  def permission_section_id_eq_or_nil(section_id)
    particular = Permission.arel_table[:section_id].eq(section_id)
    global     = Permission.arel_table[:section_id].eq(nil)
    particular.or(global)
  end

  private :permission_department_id_eq_or_nil, :permission_section_id_eq_or_nil

  def allowed_object(object, options = {})
    case object

    when Course, Department, CourseTerm
      department_id = object.try(:department).try(:id) || object.try(:id)
      conditions = permission_department_id_eq_or_nil(department_id)
      group_name = 'course'

    when Book, CourseResource
      term_id = object.try(:section).try(:term_id)
      conditions = permission_term_id_eq_or_nil(term_id)
      group_name = 'course_resource'

    when Broadcast
      department_id = object.try(:department).try(:id)
      conditions = permission_department_id_eq_or_nil(department_id)

    when Section
      conditions = permission_section_id_eq_or_nil(object.id)

    else
      raise NotImplementedError
    end

    level = Permission.arel_table[options[:action_type]].eq(true)

    group_name ||= object.class.name.downcase

    permissions.active
               .for_group(group_name)
               .where(conditions)
               .where(level)
               .exists?
  end

  def allowed_group(group, options = {})
    case group
    when :admin
      admin_access_allowed

    when :hod
      if options[:action_type].present? && options[:action_type].to_sym != :view
        raise 'For destructive operations please use allowed_object'
      end

      permissions.active.where(group_name: :head_of_department).exists?

    when :permission, :section, :course, :section_student,
         :course_resource, :coursework, :announcement, :report, :broadcast

      term_id        = options[:term_id] || Term.current.try(:id)
      specified_term = Permission.arel_table[:term_id].eq(term_id)
      all_terms      = Permission.arel_table[:term_id].eq(nil)
      level          = Permission.arel_table[options[:action_type]].eq(true)

      permissions.active
                 .for_group(group)
                 .where(specified_term.or(all_terms))
                 .where(level)
                 .exists?

    else
      raise 'Invalid permission request'
    end
  end

  def sections_available_for(group)
    group = group.to_s if group.is_a?(Symbol)
    permissions.for_group(group)
               .pluck(:section_id)
  end

  def faculty_of?(section_id)
    SectionFaculty.joins(:faculty).where(
      faculty: { user_id: @user_id },
      section_id: section_id
    ).exists?
  end

  def self.generate_permissions
    permissions = {}

    GROUPS.each do |group, group_permissions|
      permissions[group] = {}

      group_permissions.each do |gp, opts|
        constraints =
          if opts
            opts[:constraints]
          else
            VISIBLE_PERMISSION_OPTS[gp][:constraints]
          end.reduce({}) { |a, e| a.merge(e => true) }

        attributes = { group_name: group, group_type: gp }
        permissions[group][gp] = Permission.new(attributes.merge(constraints))
      end
    end

    permissions
  end

  def self.controls_for(group, type)
    case GROUPS[group]
    when Array
      ALL_PERMISSIONS[type]
    when Hash
      ALL_PERMISSIONS[type].merge(GROUPS[group][type])
    end
  end
end
