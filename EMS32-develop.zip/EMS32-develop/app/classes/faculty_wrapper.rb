class FacultyWrapper
  attr_reader :user, :faculty, :access

  def initialize(user_id)
    @user    = User.where(id: user_id).first
    @faculty = user.faculty
  end

  def id
    faculty.try(:id)
  end

  def of?(section)
    sections.include?(section)
  end

  # This method gathers and combines users sections from
  # SectionFaculty and Permission models
  # @return [ActiveRecord::Relation]
  def sections
    Section.from(query).order('created_at desc').distinct
  end

  def section_ids
    sections.pluck(:id)
  end

  # @param  [Section] Section instance
  # @return [ActiveRecord::Relation]
  def previous_sections(section)
    sections.where(Section.arel_table[:id].not_eq(section.id))
  end

  def has_previous_sections?(section)
    previous_sections(section).exists?
  end

  def terms
    Term.joins("JOIN #{query} ON terms.id = sections.term_id").uniq
  end

  def terms_ids
    terms.pluck(:term_id)
  end

  private

  def query
    subqueries = []
    subqueries << Section.joins(:permissions).where(
      permissions: {
        user_id: user.id,
        group_type: 'access_section',
        view: true
      }
    ).to_sql

    subqueries << Section.joins(:section_faculty).where(
      section_faculty: {
        faculty_id: faculty.id
      }
    ).to_sql if user.faculty

    format('(%s) AS sections', subqueries.join(' UNION '))
  end
end
