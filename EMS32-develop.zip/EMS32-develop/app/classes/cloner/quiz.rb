# Cloner::Quiz implementation
class Cloner::Quiz < Cloner::Base
  def perform
    options = { include: { questions: :question_answers }, validate: false }

    coursework = Coursework.create(courseworkable: section)
    @dest = src.deep_clone options do |_original, copy|
      if copy.is_a? Quiz
        copy.title             = compute_title
        copy.starts_at         = nil
        copy.ends_at           = nil
        copy.active            = false
        copy.visible           = false
        copy.course_module_id  = nil
        copy.grading_policy_id = nil
      end
    end

    perform_dates_calculation if requested_dates_calculation?
    result = dest.save(validate: false)

    coursework.content = dest
    coursework.save

    src.questions.each_with_index do |question, index|
      clone_assets(question, dest.questions[index])
    end

    logger.info format(RESOURCE_SUCCESS, dest.class, dest.id, section.id)

    result
  rescue StandardError => e
    logger.warn format(RESOURCE_ERROR, src.class, src.id, section.id, e)

    false
  end
end
