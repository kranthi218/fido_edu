# Cloner::Book implementation
class Cloner::Book < Cloner::Base
  def perform
    @dest = src.deep_clone do |_original, copy|
      copy.title = compute_title(scope: { author:     src.author,
                                          publisher:  src.publisher })
      copy.section_id = section.id
    end

    result = dest.save(validate: false) &&
             clone_assets(src, dest) &&
             clone_links(src, dest)

    logger.info format(RESOURCE_SUCCESS, dest.class, dest.id, section.id)

    result
  rescue StandardError => e
    logger.warn format(RESOURCE_ERROR, src.class, src.id, section.id, e)

    false
  end
end
