# Cloner::CourseResource implementation
class Cloner::CourseResource < Cloner::Base
  using ConsoleColorsStringRefinement

  ATTACHMENT_SUCCESS = "[CLONE] #{'done'.green} %s(%s) -> %s(%s)".freeze
  ATTACHMENT_ERROR   = "[CLONE] #{'failed'.red} Attachment -> %s(%s): %s".freeze

  def perform
    @dest = src.deep_clone do |_original, copy|
      copy.title      = compute_title
      copy.section_id = section.id
    end

    result = dest.save(validate: false) &&
             clone_assets(src, dest) &&
             normalize_attachment(src, dest) &&
             clone_links(src, dest)

    logger.info format(RESOURCE_SUCCESS, dest.class, dest.id, section.id)

    result
  rescue StandardError => e
    logger.warn format(RESOURCE_ERROR, src.class, src.id, section.id, e)

    false
  end

  private

  # This method will recreate model stored attachment using assets association
  # @param source      [Object] Original CourseRecource object
  # @param destination [Object] Copy object asset recipient
  def normalize_attachment(source, destination)
    return true unless source.attachment.exists?

    asset = Asset.new
    asset.attachment = source.attachment
    asset.attachable = destination
    asset.save(validate: false)

    logger.info format(ATTACHMENT_SUCCESS,
                       asset.class,
                       asset.id,
                       destination.class,
                       destination.id)

    true
  rescue StandardError => e
    logger.warn format(ATTACHMENT_ERROR,
                       destination.class,
                       destination.id,
                       e)

    false
  end
end
