# Faculties are not suppose to view current trimester's ongoing survey reports
# till it meet below dates
# Oct 1 - for every Fall trimester
# Feb 1 - for every Spring trimester
# June 1 - for every Summer trimester
class FacultySurveyReport
  class << self
    # method returns term starts_at or ends_at depends on
    # term and current time
    def term_deadline
      cutoff = {
        'FALL'   => Time.new(fall_term_year, 2),
        'SPRING' => Time.new(Time.now.year, 6),
        'SUMMER' => Time.new(Time.now.year, 10)
      }
      if Time.now > cutoff[Term.current.name.upcase]
        Term.current.ends_at
      else
        Term.current.starts_at
      end
    end

    private

    # fall starts in the month of aug and ends in jan
    # so there will be a variation in the year
    # so, IF current month is from sep-dec(fall months) then return next
    # year ELSE return current year
    def fall_term_year
      return Time.now.next_year.year if
        [8, 9, 10, 11, 12].include?(Time.now.month)
      Time.now.year
    end
  end
end
