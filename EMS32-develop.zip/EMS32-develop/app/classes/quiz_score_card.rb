# This class accepts a hash containing a quiz.id, user.id,
# and questions answers where the key to the answers is the question id.
#
class QuizScoreCard
  def initialize(quiz_score, quiz_answer)
    @quiz_score  = quiz_score
    @quiz_answer = quiz_answer
  end

  # returns quiz_score sum
  def score
    question = Question.find(@quiz_answer[:question_id])
    student_answer = @quiz_answer[:question_answers]

    case question.question_type
    when 'true_false'
      score_multiple_choice_answer(question, student_answer)
    when 'multiple_answer'
      score_multiple_answer_answer(question, student_answer || [])
    when 'multiple_choice'
      score_multiple_choice_answer(question, student_answer)
    when 'text_answer'
      create_or_update_text_answer(question, @quiz_answer)
    end
    QuizAnswer.where(quiz_score_id: @quiz_score.id).sum(:score)
  end

  private

  def create_or_update_text_answer(question, quiz_answer)
    state = quiz_answer[:text_answer].blank? ? 'incorrect' : nil

    QuizAnswer
      .find_or_create_by(
        quiz_score_id: @quiz_score.id,
        question_id:   question.id
      ).update(
        text_answer: quiz_answer[:text_answer],
        state: state
      )
  end

  def score_multiple_answer_answer(question, student_answer)
    correct_answers = question.question_answers
                              .where(answer: true)
                              .pluck(:id)
                              .map(&:to_s)

    student_answer.reject!(&:empty?)

    answer_set_count = student_answer.present? ? student_answer.count : 0
    total_correct_answer = 0
    student_score = 0
    state = :incorrect

    quiz_answer = QuizAnswer.where(quiz_score_id: @quiz_score.id,
                                   question_id: question.id)

    # if in case user resubmits the answers
    # deleting the existing answers
    quiz_answer.destroy_all if quiz_answer.present?
    student_answer.each_with_index do |answer, index|
      if answer.present? && correct_answers.include?(answer)
        state = :correct
        total_correct_answer += 1
      else
        total_correct_answer -= 1
      end

      if (index + 1) == answer_set_count &&
         total_correct_answer == correct_answers.count
        student_score = question.points.to_f
      end

      # cannot use 'find_create_update' Method here
      # because each time multiple answer will be create newly,
      # irrespective whether student submits answer for first time
      # or resubmitting the answer (in this case we destroy all user answers
      # related to question and recreate it again) which helps us to track
      # student latest multiple answers easily.

      QuizAnswer.create(
        quiz_score_id: @quiz_score.id,
        question_id: question.id,
        question_answer_id: answer,
        score: student_score,
        state: state
      )
    end
  end

  def score_multiple_choice_answer(question, student_answer)
    student_score = 0
    correct_answer = question.question_answers
                             .where(answer: true)
                             .pluck(:id)
                             .map(&:to_s)

    if correct_answer.include?(student_answer)
      state = :correct
      student_score = question.points.to_f
    else
      state = :incorrect
      student_score = 0
    end

    find_create_update(
      @quiz_score.id,
      question.id,
      student_answer,
      student_score,
      state
    )
  end

  def find_create_update(quiz_score_id, question_id, answer_ids, score, state)
    QuizAnswer
      .find_or_create_by(
        quiz_score_id: quiz_score_id,
        question_id: question_id
      ).update(
        question_answer_id: answer_ids,
        score: score,
        state: state
      )
  end
end
