# This class encapsulates the logic reqiured to import users from
# Janzebar/Ex into the EMS
class UserSync
  attr_writer :logger
  attr_reader :invalid_users

  CREATE_MESSAGE = 'Creating user(janzebar_id=%s) with email [%s]'.freeze
  UPDATE_MESSAGE = 'Updating user(janzebar_id=%s) with email [%s]'.freeze
  CHANGE_MESSAGE = 'Attrbiute changes: %s'.freeze

  def initialize
    yield(self) if block_given?
    @invalid_users = []
  end

  # Sync an individual user from Janzebar/Ex into the EMS
  # @param janzebar_id [Integer] The Janzebar/Ex id_num or EMS student ID
  #   of the user we wish to sync
  def sync_user!(janzebar_id)
    email_not_null = Ex::Name.arel_table[:email_address].not_eq(nil)
    ex_names = Ex::Name.where(id_num: janzebar_id).where(email_not_null)
    name_count = ex_names.count

    if name_count == 0
      raise "No matching records for student id #{janzebar_id}"
    elsif name_count > 1
      raise "Multiple records for student id #{janzebar_id}"
    end
    update_or_import_users(ex_names, type: :student)
  end

  # Sync students from Janzebar/Ex into the EMS
  #
  # Sync process is as follows:
  #   1. Find all users in Ex (ie: Ex::Name records) that are accepted students
  #      Janzebar/Ex
  #   2. Attempt to find that user within the EMS
  #   3. A. If a user was found, update that user with the data retreived from
  #         Janzebar/Ex
  #      B. If a user was not found, create a new user with Janzebar/Ex data.
  def student_sync!
    accepted_student_ids = Ex::Candidacy.joins(:ex_name).accepted.pluck(:id_num)

    active_student_ids = Ex::DegreeHistory.where(active: 'Y').pluck(:id_num) & accepted_student_ids

    email_not_null = Ex::Name.arel_table[:email_address].not_eq(nil)
    accepted_student_objects = Ex::Name.arel_table[:id_num].in(active_student_ids)
    accepted_users = Ex::Name.joins(:ex_candidacy)
                             .where(email_not_null)
                             .where(accepted_student_objects).distinct

    update_or_import_users accepted_users, type: :student
  end

  # Sync faculty from Janzebar/Ex into the EMS
  #
  # Sync process is as follows:
  #   1. Find all faculty in Ex (ie: Ex::Name records) that are instructors
  #      for all of the provided Ex::Section records (ie: users returend in the
  #      ex_faculty association)
  #   2. Attempt to find User records for those faculty within the EMS
  #   3. A. If a user was found, update that user with the data retreived from
  #         Janzebar/Ex
  #      B. If a user was not found, create a new user with Janzebar/Ex data.
  #
  # @param [Ex::Section, ActiveRecord::Relation] ex_sections The Ex::Section
  #   records from which to import faculty records
  def faculty_sync!(ex_sections = nil)
    ex_sections ||= Ex::Section.all

    # Associate this section with the correct insturctor
    faculty_id_nums = ex_sections
                      .map { |section| section.ex_faculty.pluck(:id_num) }
                      .flatten
                      .uniq
                      .sort

    email_not_null = Ex::Name.arel_table[:email_address].not_eq(nil)
    accepted_faculty = Ex::Name
                       .where(id_num: faculty_id_nums)
                       .where(email_not_null)

    update_or_import_users accepted_faculty, type: :faculty
  end

  def faculty_student_sync!(term)
    is_oft = Ex::StudentCourseHistory.arel_table[:crs_cde].matches('OFT%')
    faculty_in_oft_ids = Ex::StudentCourseHistory
                         .where(yr_cde: term.janzebar_year.to_s, trm_cde: term.janzebar_term)
                         .where(is_oft)
                         .pluck(:id_num)

    email_not_null = Ex::Name.arel_table[:email_address].not_eq(nil)
    faculty_students = Ex::Name
                       .where(email_not_null)
                       .where(id_num: faculty_in_oft_ids)

    update_or_import_users faculty_students, type: :student
  end

  def report_errors
    ActionMailer::Base.mail(
      from: 'dbteam+ems32-user_sync@itu.edu',
      to: 'dbteam@itu.edu',
      subject: "UserSync Errors: #{Time.zone.now.to_formatted_s(:rfc822)}",
      body: error_report_body
    ).deliver!
  rescue Net::SMTPAuthenticationError
    logger.warn "Error Report Mail couldn't be sent. Cause: #{$ERROR_INFO}"
    logger.warn error_report_body
  end

  # Query an instance of CourseCodeSync to see if any errors were generated
  # @return [Boolean] true if errors are present, otherwise false
  def errors?
    !@invalid_users.empty?
  end

  private

  def logger
    @logger ||= Logger.new(STDOUT)
  end

  # @param [Ex::Name, ActiveRecord::Relation] ex_names a collection
  #   of Ex::Name records
  # @param [Symbol] type May be either :student or :faculty,
  #   indicates the type of user association that must be built when creating
  #   a new users during an import
  def update_or_import_users(ex_names, type: :student)
    ex_names.find_each do |n|
      next if duplicates_detected?(n)
      user = fetch_or_build_user_with_ex_name(n)
      user.persisted? ? update_user(user) : create_user(user)

      # Create the relevant associations for this type of user if
      # they do not already exist as well update Student account is
      # on hold or not
      if type == :student
        create_student_for_user(user) unless user.student
        update_student_account_hold(user.student, n.ex_student)
      elsif type == :faculty && !user.faculty
        create_faculty_for_user(user)
      end
    end

    nil
  end

  # Detect if a given Ex::Name record shares an email with any other Ex::Name
  # records
  # @param name [Ex::Name]
  def duplicates_detected?(name)
    Ex::Name.where(email_address: name.email_address.strip).count > 1
  end

  def create_student_for_user(user)
    model = user.build_student(user_id: user, student_number: user.janzebar_id)

    if model.valid?
      model.save
    else
      msg = 'Unable to create Student for user(id=%s): %s'
      errors = model.errors.full_messages.join(', ')
      logger.warn format(msg, user.id, errors)
    end

    model.save
  end

  def update_student_account_hold(student, ex_student)
    if student.valid? && ex_student.present?
      student.update_column(:account_on_hold, ex_student.on_hold?)
    else
      msg = 'Unable to update account hold for Student (id=%s): %s'
      errors = student.errors.full_messages.join(', ')
      logger.warn format(msg, student.id, errors)
    end
  end

  def create_faculty_for_user(user)
    model = user.build_faculty(user_id: user)

    if model.valid?
      model.save
    else
      msg = 'Unable to create Faculty for user(id=%s): %s'
      errors = model.errors.full_messages.join(', ')
      logger.warn format(msg, user.id, errors)
    end

    model
  end

  def transcribe_ex_name_attrs_to_user(ex_name, user)
    email = clean(ex_name.email_address).downcase
    first_name = clean(ex_name.first_name)
    middle_name = clean(ex_name.middle_name)
    last_name = clean(ex_name.last_name)

    user.email = email.blank? ? nil : email
    user.first_name = first_name.blank? ? nil : first_name
    user.middle_name = middle_name.blank? ? nil : middle_name
    user.last_name = last_name.blank? ? nil : last_name
  end

  # Given a user, determins what the preferred janzebar ID is for this user
  #
  # Prefer faculty records on Ex to student records on Ex when they map to
  # the same user within the EMS.
  #
  # @note This method is important because it handles the use case where we
  #   have multiple records or users in Janzebar/Ex that map to a single
  #   user within the EMS. This can happen when a user is both a faculty and
  #   a student. In such cases, we want to save the Janzebar id_num for
  #   the student record as the student number and persist the Janzebar id_num
  #   for the faculty record as the EMS User record's janzebar_id
  #
  # @param [Ex::Name] ex_name The Ex::Name record which this user
  #   is associated
  # @param [User] user The User record in question
  def determine_janzebar_id_for_user(ex_name, user)
    # Immediately return the Janzebar ID if we're dealing with a new user or
    # a user that has not yet been associated with an Ex::Name record,
    # there is no special logic needed in this case.
    return ex_name.id_num if user.janzebar_id.blank? || !user.persisted?

    # If the user's janzebar_id matches with the Ex::Name record, it means
    # we've previously synced those records with each other. No further
    # processing is needed
    return ex_name.id_num if user.janzebar_id == ex_name.id_num

    # Past this point we're dealing with a persisted user, figure out if
    # they are a student, faculty, or both
    student_number = student_number_for_user(user)

    # Is this a Student and have we found a faculty record for that student?
    if student_number && student_number != ex_name.id_num
      # At this point, we're looking at an EMS User that is a student and we've
      # found a new Ex::Name Faculty record for that same user.
      # In this situation, we need to update the user record to point at the
      # new faculty record form Ex.
      ex_name.id_num
    else
      # Otherwise just keep the currently known Janzebar ID
      user.janzebar_id
    end
  end

  # @param [Symbol] type May be either :faculty or :student, used to determine
  #   what additional assocations need to be created when importing a new user
  # @todo Build or update Faculty and Student records when importing from Ex
  def fetch_or_build_user_with_ex_name(ex_name)
    user = User.where(janzebar_id: ex_name.id_num).first

    # Fall back to looking usrs up by email if no janzebar_id is present
    if user.nil? && ex_name.email_address.present?
      user = User.where(email: clean(ex_name.email_address)).first
    end

    user ||= User.new
    user.janzebar_id = determine_janzebar_id_for_user(ex_name, user)

    # Generate a random password for new users
    # Random token generation courtesy Devise#friendly_token
    unless user.persisted?
      user.password = SecureRandom
                      .urlsafe_base64(15).tr('lIO0', 'sxyz')
    end

    transcribe_ex_name_attrs_to_user(ex_name, user)

    user
  end

  def create_user(user)
    result = user.save

    if result
      user.invite!
      logger.info format(CREATE_MESSAGE, user.janzebar_id, user.email)
    else
      @invalid_users << user
      logger.warn format('Unable to create user(janzebar_id=%s) with email [%s]: %s', user.janzebar_id, user.email, user.errors.full_messages.join(', '))
    end

    result
  end

  def update_user(user)
    result = user.save

    if result
      logger.info format(UPDATE_MESSAGE, user.janzebar_id, user.email)
      logger.info format(CHANGE_MESSAGE, user.changes) unless user.changes.empty?
    else
      @invalid_users << user
      logger.warn format('Unable to update user(id=%s): %s', user.id, user.errors.full_messages.join(', '))
    end

    result
  end

  # Safely convert input into a string and strip it
  # of leading and trailing whitespace
  def clean(text)
    text.to_s.strip
  end

  def clean_student_number(student_number)
    student_number.to_s.gsub(/[^0-9]/, '').to_i
  end

  def student_number_for_user(user)
    clean_student_number(user.student.student_number) if user.student
  end

  def errors_for_user(user)
    format(
      "User(id=%s janzebar_id=%s)\n%s",
      user.id || 'nil',
      user.janzebar_id || 'nil',
      ErrorsWithAttributes.new(user).to_s
    )
  end

  def error_report_body
    body  = "Failed to import #{@invalid_users.size} users\n\n"
    body += @invalid_users.map { |u| errors_for_user(u) }.join("\n")
    body
  end
end
