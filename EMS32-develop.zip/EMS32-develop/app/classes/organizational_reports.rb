class OrganizationalReports
  CLO_CLASSES = [Assignment, Discussion, Quiz].freeze
  # HACK: FOR MBA
  DEPARTMENTS = [1].freeze

  # class SignatureAssignment
  #   # will be expanded for other departments
  #   def self.generate
  #     signature_assignments = Assignment.includes(section: [{course: :department}, :term])
  #                       .where(departments: {id: DEPARTMENTS.first})
  #                       .where.not(sections: {signature_assignment_id: nil})
  #     signature_assignments.each do |assignment|
  #       assignment.student_assignments.each do |assignment|
  #       end
  #     end
  #   end
  # end

  class Assignment
    attr_reader :rows, :file_name
    def initialize(limit = 100, file_name)
      @limit = limit
      @file_name = file_name
    end

    def cpt
      student_assignments = StudentAssignment.joins(assignment: { section: :course })
                                             .where("courses.course_no LIKE 'INT%'")
                                             .where("sections.section LIKE 'BA%'").limit(rows)
      to_csv(student_assignments)
    end

    def capstone
      student_assignments = StudentAssignment.joins(assignment: { section: :course })
                                             .where(courses: { course_no: ['MBN 697', 'MGT 690'] })
      to_csv(student_assignments)
    end

    def to_csv(student_assignments)
      CSV.open(file_name, 'wb') do |csv|
        csv << ['Term', 'Student ID', 'Course No', 'Section', 'Assignment', 'Score', 'Link to Report']
        student_assignments.each do |student_assignment|
          csv << [
            student_assignment.assignment.section.term.display_name,
            student_assignment.student.student_number,
            student_assignment.assignment.section.course_no,
            student_assignment.assignment.section.section,
            student_assignment.assignment.title,
            student_assignment.score,
            student_assignment.assets.first.try(:url)
          ]
        end
      end
    end
  end
end
