# The DiscussionCommentReader manages the read/unread state
# of all comments in a discussion from the context of the
# provided user.
#
# Additionally, an instance of this class may be used to
# determine if a given discussion comment has been read by
# a particular user in the context of a discussion.
class DiscussionCommentReader
  attr_reader :user_id
  attr_reader :discussion_id

  # Note: While Redis::Store supports namespacing of a number of
  # redis operations, set operations are not included.
  # We have to namespace things here manually in order
  # to get around that limitation.
  READ_COMMENTS_REDIS_KEY_STRING = 'app:user:%s:discussion:%s/comments_read'

  # @param user [User, Integer] An instance of of a User or a user id
  # @param discussion [Discussion, Integer] An instance of a Discussion or a discussion id
  def initialize(user, discussion)
    @user_id = user.try(:id) || user
    @discussion_id = discussion.try(:id) || discussion
  end

  # Mark the provided discussion comment as read
  # @param [DiscussionComment, Integer] An instance of a DiscussionComment or a discussion comment id
  def read_comment!(discussion_comment)
    id = discussion_comment.try(:id) || discussion_comment
    Rails::Redis.sadd(read_comments_redis_key, id)
  end

  # Mark the provided discussion comment as unrad
  # @param [DiscussionComment, Integer] An instance of a DiscussionComment or a discussion comment id
  def unread_comment!(discussion_comment)
    id = discussion_comment.try(:id) || discussion_comment
    Rails::Redis.srem(read_comments_redis_key, id)
  end

  # Indicate weather or not the provided discussion comment has been read
  # @param [DiscussionComment, Integer] An instance of a DiscussionComment or a discussion comment id
  # @return [Boolean] A boolean indicating if the indicated discussion comment has been read
  def read?(discussion_comment)
    id = discussion_comment.try(:id) || discussion_comment
    Rails::Redis.sismember(read_comments_redis_key, id)
  end

  # Return an unsorted array of all discussion comment ids that have been read
  # @return [Array<Integer>] An array of discussion comment ids
  def read_discussion_comment_ids
    Rails::Redis.smembers(read_comments_redis_key).map(&:to_i)
  end

  private

  def read_comments_redis_key
    format(READ_COMMENTS_REDIS_KEY_STRING, @user_id, @discussion_id)
  end
end
