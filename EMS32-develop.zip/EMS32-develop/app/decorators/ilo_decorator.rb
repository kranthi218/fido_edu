class IloDecorator < Draper::Decorator
  delegate_all

  def display_name
    strip_tags(description)
  end

  def ilo_as_table_row
    tooltip = "<span href='#' title='' data-toggle='popover' data-content=\"#{description}\" data-html=\"#{true}\">
      #{description.slice(0..100)}...</span>"
    "#{tooltip}".html_safe
  end
end
