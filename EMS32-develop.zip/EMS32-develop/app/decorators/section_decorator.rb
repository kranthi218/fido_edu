class SectionDecorator < Draper::Decorator
  delegate_all
  delegate :current_page, :total_pages, :limit_value
  decorates :section
  decorates_association :student

  def setup_status_display
    if object.setup_completed?
      "Setup Complete <i class='icon icon-thumbs-up text-success'></i>".html_safe
    else
      "Setup Incomplete <i class='icon icon-thumbs-down text-danger'></i>".html_safe
    end
  end

  ## this method is used for getting user associated with particular course
  def display_faculty_user
    object.faculty.map{ |f| f.user }.first
  end

  def heading
    format('%s %s', object.course_and_section_no, object.course.name)
  end
end
