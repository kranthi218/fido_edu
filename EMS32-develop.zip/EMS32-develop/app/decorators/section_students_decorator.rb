class SectionStudentsDecorator < Draper::CollectionDecorator
  # draper doesn't delegate collections
  def sort_by_full_name
    object.includes(student: :user)
      .order("users.first_name, users.middle_name, users.last_name ASC")
  end
end
