class LessonDecorator < Draper::Decorator
  delegate_all

  # Define presentation-specific methods here. Helpers are accessed through
  # `helpers` (aka `h`). You can override attributes, for example:
  #
  #   def created_at
  #     helpers.content_tag :span, class: 'time' do
  #       object.created_at.strftime("%a %m/%d/%y")
  #     end
  #   end
  def breadcrumb_title
    "Lesson: #{object.title}"
  end

  def for_coursework_widget
    h.content_tag(:li, "#{lesson.title} #{lesson.description}")
  end
end
