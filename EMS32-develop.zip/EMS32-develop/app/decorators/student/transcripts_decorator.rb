class Student::TranscriptsDecorator < Draper::Decorator
  delegate_all

end
