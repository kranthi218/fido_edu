class DiscussionDecorator < Draper::Decorator
  delegate_all

  def breadcrumb_title
    "Discussion: #{object.topic.truncate(18)}" if object.topic
  end
end
