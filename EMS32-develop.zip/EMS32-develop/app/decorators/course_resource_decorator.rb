class CourseResourceDecorator < Draper::Decorator
  delegate_all

  # Define presentation-specific methods here. Helpers are accessed through
  # `helpers` (aka `h`). You can override attributes, for example:
  #
  #   def created_at
  #     helpers.content_tag :span, class: 'time' do
  #       object.created_at.strftime("%a %m/%d/%y")
  #     end
  #   end

  def asset_kind
    category == 'documents' ? 'Documents' : 'Attachments'
  end

  def url_tag
    if category == 'video'
      '<i class="icon icon-video-camera"></i> Video'
    else
      '<i class="icon icon-link"></i> Url'
    end.html_safe
  end

end
