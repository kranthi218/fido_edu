# A decorator class for the Quiz model
class QuizDecorator < Draper::Decorator
  TIME_LIMITS = [5, 15, 30, 45, 60, 90, 120, 150, 190]
  TIME_LIMITS_HASH = Hash[TIME_LIMITS.map { |n| [n.to_s, n] }]

  delegate_all

  def breadcrumb_title
    format('Quiz: %s', object.title)
  end

  # A collection of times for use within Quiz forms
  # @return [Hash{String => Integer}]
  def time_limits
    TIME_LIMITS_HASH
  end
end
