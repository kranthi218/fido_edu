# Mailer for faculty's Class Roster
class RosterMailer < ActionMailer::Base
  def send_message(sender_name, recipient_name, recipient_email, course_no, subject, content)
    mail(from: "#{sender_name} <donotreply@ems.itu.edu>",
         to: "#{recipient_name} <#{recipient_email}>",
         subject: "#{course_no} | #{subject}",
         body: content,
         content_type: 'text/html'
        )
  end
end
