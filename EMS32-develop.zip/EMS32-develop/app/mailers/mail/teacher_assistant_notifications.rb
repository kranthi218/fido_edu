class TeacherAssistantNotifications < ActionMailer::Base
  def notify_newly_assigned_ta(teacher_assistant)
    @section = teacher_assistant.section
    subject = "You have been assigned as the TA for  #{teacher_assistant.section.name}"
    from 'EMS <donotreply@itu.edu>'
    recipients = if ENV['RAILS_ENV'] == 'development' || ENV['RAILS_ENV'] == 'staging'
                   default_emails
                 else
                   teacher_assistant.user.email
                 end

    mail(to: recipients, subject: subject)
  end
end
