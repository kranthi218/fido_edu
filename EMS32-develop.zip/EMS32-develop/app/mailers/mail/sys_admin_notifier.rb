class SysAdminNotifier < ActionMailer::Base
  def data_import_notification(data)
    subject "Finished Importing #{data}"
    from    'EMS <donotreply@itu.edu>'
    recipients default_emails
    sent_on Time.zone.now
    body data: :data
  end

  def ex_integration_mailer(_data, student)
    subject "Error Syncing my courses Student (primary key): #{student.id} : Student ID: #{student.student_number}"
    from    'EMS <donotreply@itu.edu>'
    recipients default_emails
    sent_on Time.zone.now
    body data: :data
  end

  def student_records_sync_error_notifier(error_message, student_number)
    subject "Error Syncing students record Student Number: #{student_number}"
    from    'EMS <donotreply@itu.edu>'
    recipients default_emails
    sent_on Time.zone.now
    body error_message: error_message
  end
end
