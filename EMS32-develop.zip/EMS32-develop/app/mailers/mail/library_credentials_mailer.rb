class Mail::LibraryCredentialsMailer < ActionMailer::Base
  def library_credentials(user)
    @user    = user
    @subject = I18n.t 'library_credentials_mailer.library_credentials.subject'
    mail(to: @user.email, subject: @subject)
  end
end
