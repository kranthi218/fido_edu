class AccountConfirmationMailer < ActionMailer::Base
  def account_confirmation(user)
    @user    = user
    @subject = I18n.t('account_confirmation_mailer.account_confirmation.subject')
    @confirmation_url = account_confirmation_url(user.perishable_token)
    mail(to: @user.email, subject: @subject)
  end

  def account_confirmed_notification(user)
    @user     = user
    @subject  = I18n.t('account_confirmation_mailer.account_confirmed_notification.subject')
    @root_url = root_url
    mail(to: @user.email, subject: @subject)
  end
end
