class Mail::SectionReminderNotifications < ActionMailer::Base
  default from: 'EMS Reminders <donotreply@ems.itu.edu>'

  def send_reminder(reminder, user)
    @reminder =   reminder
    mail(
      from:    'EMS Reminder <donotreply@itu.edu>',
      to:      user.decorate.mail_to,
      subject: @reminder.title
    )
  end

  def send_final_grading_period_reminder(section, faculty)
    @section = section
    mail(
      from:    'EMS Reminder <donotreply@itu.edu>',
      to:      faculty,
      subject: @section.display_name
    )
  end

  def send_section_ending_reminder(section, user)
    @section = section
    mail(
      from:    'EMS Reminder <donotreply@itu.edu>',
      to:      user,
      subject: @section.display_name
    )
  end
end
