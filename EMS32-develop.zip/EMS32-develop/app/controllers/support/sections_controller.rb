class Support::SectionsController <  Support::SupportController
  before_action only: %i(index) do |controller|
    controller.add_breadcrumb 'Sections'
  end

  before_action except: %i(index) do |controller|
    controller.add_breadcrumb 'Sections', support_sections_path(@sections)
  end

  def index
    @sections = Section.search(query_params,
                               filters: filters_params,
                               order: order_params,
                               page: page_params,
                               per: per_page_params)
  end

  def show
    @section          = Section.find(params[:id]).decorate
    @section_students = @section.section_students
                                .without_faculty
                                .includes(:grade, :student)
  end

  def edit
  end

  def update
    @section = Section.find(params[:id])
    if @section.update_attributes(section_params)
      redirect_to support_section_url(@section),
                  notice: t(:successfully_updated, record: 'Section')
    else
      render action: 'show'
    end
  end

  def class_roster
    @section  = Section.find(params[:id])
    @students = @section.students.page(params[:page])
    add_breadcrumb "Sections", support_sections_path(@section)
  end

  def coursework
    add_breadcrumb 'Coursework', coursework_support_section_path
  end

  private

  def section_params
    params.require(:section).permit(:final_grading_date)
  end

  attr_reader :section
  helper_method :section

  def search_params
    params.permit(
      :page,
      :per_page,
      search: [
        :id,
        :category,
        :department_id,
        :grading_method,
        :order,
        :program_id,
        :query,
        :setup_completed,
        :sort,
        :term_id
      ]
    ).fetch(:search, {})
  end

  def order_params
    { search_params[:sort] || 'updated_at' => search_params[:order] || 'desc' }
  end

  def page_params
    params[:page] || 1
  end

  def per_page_params
    params[:per_page] || 20
  end

  def query_params
    search_params.fetch(:query, nil)
  end

  def filters_params
    search_params.extract!(
      :category,
      :department_id,
      :grading_method,
      :program_id,
      :setup_completed,
      :term_id
    )
  end
end
