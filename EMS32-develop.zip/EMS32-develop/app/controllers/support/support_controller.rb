class Support::SupportController < ApplicationController
  layout 'support'

  before_action do
    authorize(:support, :access?)
  end

  add_breadcrumb 'Support Dashboard', :support_root_path
end
