class Support::UsersController < Support::SupportController
  layout 'support/users'
  respond_to :html, :json

  def index
    @users = User.search(search_params, page: params[:page])
  end

  def show
    @user = User.find params.require(:id)

    if Student.exists?(user_id: @user.id)
      @section_student = SectionStudent
                         .where(student_id: @user.student.id, status: %w(enrolled graded))
                         .order('term_id DESC')

    else
      @section_student = []
    end

    if Faculty.exists?(user_id: @user.id)
      @section_faculty = SectionFaculty
                         .where(faculty_id: @user.faculty.id)
                         .order('created_at DESC')

    else
      @section_faculty = []
    end
  end

  def edit
    @user = User.find params.require(:id)
    @permission = find_or_build_access_permission(@user)
  end

  def update
    @user = User.find params.require(:id)

    if @user.update_attributes(user_params)
      redirect_to support_users_path, notice: 'User updated'
    else
      render 'edit', alert: 'An error occurred'
    end
  end

  def invite
    @user = User.find params.require(:id)

    authorize @user

    if @user.invite!
      redirect_to support_user_path(@user), notice: 'User has been invited'
    else
      redirect_to support_user_path(@user), alert: 'An error occurred'
    end
  end

  def invite_all
    InviteJob.perform_later(Term.current)
    redirect_to support_users_path, notice: 'Invite worker has been scheduled'
  end

  # The only permission that is granted from support is the ability to
  # grant permissions. All others are in the Admin section.
  def update_permissions
    @user = User.find params.require(:id)
    @permission = find_or_build_access_permission(@user)

    if @permission.update_attributes(permission_params)
      redirect_to edit_support_user_path(@user), notice: 'Permissions updated'
    else
      render :edit
    end
  end

  private

  def search_params
    params.fetch(:search, {}).fetch(:q, nil)
  end

  def user_params
    params.require(:user).permit(
      :first_name,
      :middle_name,
      :last_name,
      :password,
      :email
    )
  end

  def find_or_build_access_permission(user)
    Permission.where(
      user_id: user.id,
      group_type: 'access_permission'
    ).first_or_initialize
  end

  def permission_params
    params.require(:user).require(:permission).permit(
      :disabled,
      :view,
      :update_create
    )
  end
end
