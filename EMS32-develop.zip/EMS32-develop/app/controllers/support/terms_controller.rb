class Support::TermsController < Support::SupportController
  def new
    @term = Term.new
  end

  def create
    @term = Term.new term_params
    if @term.save
      redirect_to support_terms_path, notice: 'Term created.'
    else
      render 'new', alert: 'An error occurred'
    end
  end

  def update
    @term = Term.find(params[:id])
    if @term.update_attributes(term_params)
      redirect_to support_terms_path, notice: 'Term updated.'
    else
      render 'edit', alert: 'An error occurred'
    end
  end

  def edit
    @term = Term.find(params[:id])
  end

  def index
    @terms = Term.recent
  end

  def show
    @term = Term.find(params[:id])
  end

  def final_grading_date
    @term = Term.find(params[:id])
    return unless params[:section]
    sections = Section.where(term: @term)
    date = Timeliness::Parser.parse(final_grading_date_params, zone: Time.zone)
    if sections.update_all(final_grading_date: date)
      redirect_to support_terms_path, notice: 'Final Grading Date updated.'
    else
      render 'final_grading_date', alert: 'An error occurred'
    end
  end

  private

  def term_params
    params.require(:term).permit(:name, :starts_at, :ends_at, :active)
  end

  def final_grading_date_params
    params.require(:section).fetch(:final_grading_date)
  end
end
