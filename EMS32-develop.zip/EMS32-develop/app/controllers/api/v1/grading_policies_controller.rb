class Api::V1::GradingPoliciesController < Api::V1::ApiController
  before_action :find_grading_policy, only: %i(show update destroy)
  before_action :find_parent

  def index
    authorize @parent, :show?

    render json: @parent.grading_policies
  end

  def show
    authorize @grading_policy

    render_policy
  end

  def update
    authorize @grading_policy

    render_policy { @grading_policy.update_attributes(policy_attributes) }
  end

  def create
    @grading_policy = @parent.grading_policies.new(policy_attributes)

    authorize @grading_policy

    render_policy { @grading_policy.save }
  end

  def destroy
    authorize @grading_policy

    render_policy { @grading_policy.destroy }
  end

  private

  def find_parent
    @parent = if params[:section_id]
                Section.find(params[:section_id])
              else
                @grading_policy.section
              end
  end

  def find_grading_policy
    @grading_policy = GradingPolicy.find params[:id]
  end

  def render_policy
    if !block_given? || yield
      render json: @grading_policy
    else
      render @grading_policy.errors, status: :unprocessable_entity
    end
  end

  def policy_attributes
    params.require(:grading_policy).permit(
      :name,
      :weight,
      :active
    )
  end
end
