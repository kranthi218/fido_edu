class Api::V1::CloCourseTermsController < Api::V1::ApiController
  before_action :find_course_term, only: :index
  before_action :find_clo, only: :index

  def index
    clo_course_terms = CloCourseTerm.where(course_term: @course_term)
    clo_course_terms = clo_course_terms.where(clo: @clo) if @clo

    render json: clo_course_terms
  end

  private

  def find_course_term
    @course_term = CourseTerm.find_by(id: params[:course_term_id])
  end

  def find_clo
    @clo = CourseLearningOutcome.find_by(id: params[:course_learning_outcome_id])
  end
end
