# This controller handles Links RESTful API
class Api::V1::LinksController < Api::V1::ApiController
  before_action :find_link, except: %i(create)
  before_action :find_linkable

  def create
    authorize @linkable, :update?

    @link = @linkable.links.new(link_attributes)

    render_link { @link.save }
  end

  def destroy
    @link = Link.find params[:id]

    authorize @linkable, :update?

    render_link { @link.destroy }
  end

  private

  def render_link
    if !block_given? || yield
      render json: @link, serializer: LinkSerializer
    else
      render json: @link.errors, status: :unprocessable_entity
    end
  end

  def find_link
    @link = Link.find params[:id]
  end

  def find_linkable
    return (@linkable = @link.linkable) if @link
    model = params[:link][:linkable_type].classify.constantize
    @linkable = model.find params[:link][:linkable_id]
  end

  def link_attributes
    params.require(:link).permit(:url)
  end
end
