class Api::V1::CourseModulesController < Api::V1::ApiController
  before_action :find_course_module, only: %i(show update destroy)
  before_action :find_parent

  def index
    authorize @parent, :show?

    render json: @parent.course_modules.order('position')
  end

  def show
    authorize @course_module

    render_course_module
  end

  def create
    @course_module = @parent.course_modules.new(course_module_attributes)

    authorize @course_module

    render_course_module { @course_module.save }
  end

  def update
    authorize @course_module

    render_course_module do
      @course_module.update_attributes(course_module_attributes)
    end
  end

  def destroy
    authorize @course_module

    render_course_module { @course_module.destroy }
  end

  def sort
    authorize @parent, :edit?

    sort_positions.each do |item|
      course_module = @parent.course_modules.find(item[:id])
      course_module.update_attribute('position', item[:position])
    end

    render json: @parent.course_modules.order('position')
  end

  private

  def sort_positions
    params.require(:sort).permit(
      positions: [:id, :position]
    ).fetch(:positions, [])
  end

  def render_course_module
    if !block_given? || yield
      render json: @course_module
    else
      render json: @course_module.errors, status: :unprocessable_entity
    end
  end

  def find_parent
    @parent = if params[:section_id]
                Section.find(params[:section_id])
              else
                @course_module.section
              end
  end

  def find_course_module
    @course_module = CourseModule.find(params[:id])
  end

  def course_module_attributes
    params.require(:course_module).permit(
      :name,
      :percentage,
      :position,
      :visible
    )
  end
end
