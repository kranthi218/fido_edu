class Api::V1::PloProgramTermsController < Api::V1::ApiController
  before_action :find_program_term, only: :index
  before_action :find_plo, only: :index

  def index
    plo_program_terms = PloProgramTerm.where(program_term: @program_term)
    plo_program_terms = plo_program_terms.where(plo: @plo) if @plo

    render json: plo_program_terms
  end

  private

  def find_program_term
    @program_term = ProgramTerm.find_by(id: params[:program_term_id])
  end

  def find_plo
    @plo = Plo.find_by(id: params[:plo_id])
  end
end
