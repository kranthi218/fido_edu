class Api::V1::SectionStudentsController < Api::V1::ApiController
  before_action :find_parent,  only: :index
  before_action :find_section, except: :index

  def index
    section_students = policy_scope(@parent.section_students)
                       .in_status(index_status_params)
                       .includes(:term,
                                 :grade,
                                 :deadlines,
                                 section: :course,
                                 student: :user)

    render json: section_students
  end

  def update
    @section_student = @section.section_students.find(params[:id])

    authorize @section_student, :update?

    render_section_student do
      @section_student.update_attributes(section_student_attributes)
    end
  end

  def update_all
    authorize @section, :update?

    @section.assign_attributes(section_students_attributes)

    if @section.save
      head :ok
    else
      render json: @section.errors, status: :unprocessable_entity
    end
  end

  private

  def index_params
    params.permit(:status, :user_id, :include)
  end

  def index_status_params
    index_params.fetch(:status, 'enrolled,graded')
                .split(',') & SectionStudent::PERMITTED_STATUSES
  end

  def render_section_student
    if !block_given? || yield
      render json: @section_student
    else
      render json: @section_student.errors, status: :unprocessable_entity
    end
  end

  def section_students_attributes
    params.require(:update_all).permit(
      section_students_attributes: [
        :id,
        :extra_points,
        :student_id,
        :feedback,
        :grade_id
      ]
    )
  end

  def section_student_attributes
    params.require(:section_student).permit(
      :extra_points,
      :feedback,
      :grade_id
    )
  end

  def find_section
    @section = Section.find(params[:section_id])
  end

  def find_parent
    @parent = if params[:section_id]
                Section.find(params[:section_id])
              elsif params[:user_id]
                User.find(params[:user_id])
              end
  end
end
