class Api::V1::SectionFacultyController < Api::V1::ApiController
  before_action :find_parent, only: :index

  def index
    authorize SectionFaculty

    section_faculty = @parent.section_faculty
                             .includes(faculty: :user,
                                       section: %i[course term faculty])

    render json: section_faculty, include: '**'
  end

  private

  def find_parent
    @parent = if params[:section_id]
                Section.find(params[:section_id])
              elsif params[:user_id]
                User.find(params[:user_id])
              end
  end
end
