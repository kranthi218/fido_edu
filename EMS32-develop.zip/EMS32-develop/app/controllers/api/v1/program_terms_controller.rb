class Api::V1::ProgramTermsController < Api::V1::ApiController
  before_action :find_department
  before_action :find_term
  before_action :find_program
  before_action :find_program_term, only: [:update, :course_term_clos_to_plo_count]

  def index
    program_terms = ProgramTerm.joins(:program)

    program_terms = program_terms.where(programs: { department_id: @department.id }) if @department

    program_terms = program_terms.where(term: @term) if @term

    program_terms = program_terms.where(program: @program) if @program

    render json: program_terms
  end

  def update
    authorize @program_term

    render_program_term do
      @program_term.publish!
    end
  end

  def course_term_clos_to_plo_count
    render json: @program_term.course_term_clos_to_plo_count
  end

  private

  def find_department
    @department = Department.find_by(id: params[:department_id])
  end

  def find_term
    @term = Term.find_by(id: params[:term_id])
  end

  def find_program_term
    @program_term = ProgramTerm.find_by(id: params[:id])
  end

  def find_program
    @program = Program.find_by(id: params[:program_id])
  end

  def program_attributes
    params.require(:program_term).permit(
      :published
    )
  end

  def render_program_term
    if !block_given? || yield
      render json: @program_term
    else
      render json: @program_term.errors, status: :unprocessable_entity
    end
  end
end
