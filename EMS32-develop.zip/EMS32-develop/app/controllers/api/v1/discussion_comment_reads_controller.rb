# This controller is responsible for toggling of DiscussionComment read status
class Api::V1::DiscussionCommentReadsController < Api::V1::ApiController
  using CastToBooleanStringRefinement

  before_action :find_discussion_comment

  def update
    DiscussionPolicy.new(current_user, @discussion_comment.discussion).show?

    if read_attributes.fetch(:read)
      @discussion_comment.mark_as_read_by_user(current_user)
    else
      @discussion_comment.mark_as_unread_by_user(current_user)
    end

    render json: { success: true }, status: :ok
  end

  private

  def find_discussion_comment
    @discussion_comment = DiscussionComment.find(params[:discussion_comment_id])
  end

  def read_attributes
    params.require(:read).permit(:read)
  end
end
