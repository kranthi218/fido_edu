# This controller handles SupportTickets RESTful APIs
class Api::V1::SupportTicketsController < Api::V1::ApiController
  def create
    response = ZendeskAPI::Ticket.create(
      Rails.application.config.zendesk,
      support_ticket_attributes
    )

    if response
      render json: response
    else
      render json: { base: [t('zendesk.create.error')] },
             status: :unprocessable_entity
    end
  end

  private

  def support_ticket_attributes
    attrs = params.require(:support_ticket).permit(
      :subject,
      :description
    )

    {
      subject: attrs[:subject],
      comment: { value: attrs[:description] },
      requester: {
        email: current_user.email,
        name:  current_user.name
      },
      custom_fields: [{
        id: 23_956_368, # ID Number custom field id from Zendesk
        value: current_user.janzebar_id
      }]
    }
  end
end
