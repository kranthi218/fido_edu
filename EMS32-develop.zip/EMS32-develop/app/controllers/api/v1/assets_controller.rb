# This controller handles Assets RESTful API
class Api::V1::AssetsController < Api::V1::ApiController
  before_action :find_asset, except: %i(create)
  before_action :find_attachable

  def create
    authorize @attachable, :update?

    @asset = @attachable.assets.new(asset_attributes)

    @asset.creator_id = current_user.id if current_user

    render_asset { @asset.save }
  end

  def update
    authorize @attachable, :update?

    render_asset { @asset.update_attributes(asset_attributes) }
  end

  def destroy
    @asset = Asset.find params[:id]

    authorize @attachable, :update?

    render_asset { @asset.destroy }
  end

  private

  def render_asset
    if !block_given? || yield
      render json: @asset
    else
      render json: @asset.errors, status: :unprocessable_entity
    end
  end

  def find_asset
    @asset = Asset.find params[:id]
  end

  def find_attachable
    return (@attachable = @asset.attachable) if @asset
    model = params[:attachable_type].classify.constantize
    @attachable = model.find params[:attachable_id]
  end

  def asset_attributes
    params.require(:asset).permit(:attachment)
  end
end
