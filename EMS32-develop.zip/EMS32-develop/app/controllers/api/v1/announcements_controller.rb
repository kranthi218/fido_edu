class Api::V1::AnnouncementsController < Api::V1::ApiController
  before_action :find_context
  before_action :find_announcement, except: %i(index create)

  def index
    render json: @context.announcements.includes(:assets, :links)
  end

  def show
    render_announcement
  end

  def create
    @announcement = @context.announcements.new(announcement_attributes)
    @announcement.creator_id = current_user.id if current_user

    authorize @announcement

    render_announcement { @announcement.save }
  end

  def update
    authorize @announcement

    render_announcement do
      @announcement.update_attributes(announcement_attributes)
    end
  end

  def destroy
    authorize @announcement

    render_announcement { @announcement.destroy }
  end

  private

  def render_announcement
    if !block_given? || yield
      render json: @announcement
    else
      render json: @announcement.errors, status: :unprocessable_entity
    end
  end

  def find_announcement
    @announcement = @context.announcements.find params[:id]
  end

  def find_context
    @context =
      if params[:section_id].present?
        Section.find params[:section_id]
      end
  end

  def announcement_attributes
    params.require(:announcement).permit(
      :title,
      :content,
      :published_at,
      links_attributes: %i[id url]
    )
  end
end
