class Api::V1::CourseworkController < Api::V1::ApiController
  using CastToBooleanStringRefinement

  ALLOWED_COURSEWORK = %w[Assignment Discussion Quiz Lesson].freeze
  GRADABLE_COURSEWORK = %w[Assignment Discussion Quiz].freeze

  before_action :find_section

  def index
    authorize @section, :show?

    @coursework = @section.coursework

    @coursework = @coursework.where(
      content_type: params[:gradable] ? GRADABLE_COURSEWORK : ALLOWED_COURSEWORK
    )

    @coursework = @coursework.retrievable if retrievable_only?
    @coursework = @coursework.active unless include_inactive?

    if course_module_id
      @coursework = @coursework.select do |c|
        !c.content.nil? && c.content.course_module_id == course_module_id.to_i
      end
    end

    @coursework = @coursework.map(&:content).compact
    render json: @coursework
  end

  def move
    authorize @section, :edit?

    @coursework = find_coursework(params[:type], params[:id])
    @coursework.assign_attributes(move_attributes)
    @coursework.validate

    errors = @coursework.errors.to_hash.slice(:starts_at, :ends_at)

    if errors.empty? && @coursework.save(validate: false)
      render json: @coursework
    else
      render json: errors, status: :unprocessable_entity
    end
  end

  def import
    coursework      = import_attributes.fetch(:coursework, [])
    calculate_dates = import_attributes.fetch(:calculate_dates, true)
    cloner          = Cloner::Coursework.new(@section, calculate_dates)

    response = coursework.map do |item|
      work = find_coursework(item[:type], item[:id])

      authorize work, :import?

      {
        id:     work.id,
        type:   item[:type],
        status: cloner.perform(work)
      }
    end

    render json: response.to_json
  end

  private

  def retrievable_only?
    params.fetch(:retrievable, '').to_boolean
  end

  def include_inactive?
    params.fetch(:include_inactive, '').to_boolean
  end

  def find_coursework(type, id)
    type = type.camelize

    return unless ALLOWED_COURSEWORK.include?(type)

    type.constantize.find(id)
  end

  def find_section
    raise ActiveRecord::RecordNotFound unless params[:section_id]
    @section = Section.find(params[:section_id])
  end

  def move_attributes
    params.require(:move).permit(
      :starts_at,
      :ends_at,
      :active
    )
  end

  def import_attributes
    params.require(:import).permit(
      :calculate_dates,
      coursework: %i[id type]
    )
  end

  def course_module_id
    id = params.fetch(:course_module_id, nil)
    id.blank? ? nil : id.to_i
  end
end
