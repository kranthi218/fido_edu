class Api::V1::LessonsController < Api::V1::ApiController
  before_action :find_lesson, only: %i(show update destroy course_module)
  before_action :find_parent

  def index
    authorize @parent, :show?

    render json: @parent.lessons
  end

  def show
    authorize @lesson

    render_lesson
  end

  def create
    @lesson = @parent.lessons.new(lesson_attributes)
    coursework = @parent.coursework.create(kind: :regular)
    @lesson.coursework = coursework
    authorize @lesson

    create_and_render_lesson { @lesson.save }
  end

  def update
    authorize @lesson

    render_lesson { @lesson.update_attributes(lesson_attributes) }
  end

  def destroy
    authorize @lesson

    render_lesson { @lesson.destroy }
  end

  def course_module
    authorize @lesson, :update?

    target_id = params.require(:course_module).fetch(:id)
    target    = @parent.course_modules.find_by(id: target_id)

    render_lesson do
      @lesson.update_attribute(:course_module_id, target.try(:id))
    end
  end

  private

  def render_lesson
    if !block_given? || yield
      render json: @lesson, include: '**'
    else
      render json: @lesson.errors, status: :unprocessable_entity
    end
  end

  def create_and_render_lesson
    if !block_given? || yield
      render json: @lesson, include: '**'
    else
      @lesson.coursework.destroy!
      render json: @lesson.errors, status: :unprocessable_entity
    end
  end

  def find_lesson
    @lesson = Lesson.find(params[:id])
  end

  def find_parent
    @parent = if params[:section_id]
                Section.find(params[:section_id])
              else
                @lesson.section
              end
  end

  def lesson_attributes
    params.require(:lesson).permit(
      :course_module_id,
      :description,
      :ends_at,
      :hours,
      :position,
      :publish,
      :starts_at,
      :title,
      :url,
      :active,
      assets: []
    )
  end
end
