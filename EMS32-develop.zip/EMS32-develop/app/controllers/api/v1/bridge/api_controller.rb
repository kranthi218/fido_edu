# Base controller for api controllers
class Api::V1::Bridge::ApiController < Api::V1::ApiController
  skip_before_action :authenticate_user!
  before_action :authenticate
  after_action :set_pagination, only: [:index]
  before_action :initialize_per_page, only: [:index]

  # app_responders help to determine what version of the API controllers to use
  require 'app_responders'
  respond_to :json

  def show
    render json: @resource
  end

  # Set root to false as this helps standardize things for the front-end.
  # No need to repeat in each controller call.
  def default_serializer_options
    {
      root: false
    }
  end

  protected

  def find_resource
    @resource = controller_name.classify.constantize.find(params[:id])
  end

  def set_pagination
    scope = @resources

    response.headers["X-total"] = scope.total_count.to_s
    response.headers["X-offset"] = scope.offset_value.to_s
    response.headers["X-limit"] = scope.limit_value.to_s
  end

  def initialize_per_page
    params[:per_page] ||= 25
  end

  def authenticate
    authenticate_token || render_unauthorized
  end

  def authenticate_token
    authenticate_with_http_token do |token, options|
      token == api_token
    end
  end

  def render_unauthorized
    self.headers['WWW-Authenticate'] = 'Token realm="Application"'
    render json: 'Invalid Access Token', status: 401
  end

  def api_token
    'KFKECHZ2YHKM3SE5KYU6'
  end

end
