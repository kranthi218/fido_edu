# This controller handles Users RESTful APIs
class Api::V1::Bridge::UsersController < Api::V1::Bridge::ApiController
  before_action :find_resource, only: :show

  JSON_CLASSNAME = :user

  def show
    render json: @resource, serializer: ::Bridge::UserSerializer
  end

  def index
    @resources = User.page(params[:page]).per(params[:per_page])
    render json: @resources, each_serializer: ::Bridge::UserSerializer
  end
end
