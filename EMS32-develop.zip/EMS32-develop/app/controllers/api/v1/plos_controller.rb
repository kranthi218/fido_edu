# Program learning outcomes
class Api::V1::PlosController < Api::V1::ApiController
  before_action :find_department
  before_action :find_program, only: %i(index sort)
  before_action :find_plo, only: %i(show update destroy)

  def index
    authorize Plo

    scope = if @program
              @department.plos.for_program(@program)
            else
              @department.plos
            end

    render json: scope.includes(:ilos)
  end

  def show
    authorize @plo

    render_plo
  end

  def create
    @plo = @department.plos.new(plo_attributes)

    authorize @plo

    render_plo { @plo.save }
  end

  def update
    authorize @plo

    render_plo { @plo.update_attributes(plo_attributes) }
  end

  def destroy
    authorize @plo

    render_plo { @plo.destroy }
  end

  def sort
    authorize @department, :edit?

    sort_positions.each do |item|
      plo = @program.plos.find(item[:id])
      plo.update_attribute('position', item[:position])
    end

    render json: @program.plos
  end

  private

  def sort_positions
    params.require(:sort).permit(
      positions: [:id, :position]
    ).fetch(:positions, [])
  end

  def render_plo
    if !block_given? || yield
      render json: @plo
    else
      render json: @plo.errors, status: :unprocessable_entity
    end
  end

  def find_plo
    @plo = @department.plos.find(params[:id])
  end

  def find_program
    @program = Program.find_by(id: params[:program_id])
  end

  def find_department
    @department = Department.find(params[:department_id])
  end

  def plo_attributes
    # duplicate param to fix deselect all ilos issue
    # Will be fixed in next Rails releases (deep_munge issue)
    # @see https://github.com/rails/rails/issues/13420
    params.require(:plo).permit(
      :description,
      :program_id,
      :active,
      :name,
      :ilo_ids,
      ilo_ids: []
    )
  end
end
