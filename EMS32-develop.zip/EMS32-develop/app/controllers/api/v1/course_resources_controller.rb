class Api::V1::CourseResourcesController < Api::V1::ApiController
  before_action :find_course_resource, only: %i(show update destroy)
  before_action :find_parent

  def index
    authorize @parent, :show?

    render json: @parent.course_resources
  end

  def show
    authorize @course_resource

    render_course_resource
  end

  def create
    @course_resource = @parent.course_resources.new(course_resource_attributes)

    authorize @course_resource

    render_course_resource { @course_resource.save }
  end

  def update
    authorize @course_resource

    render_course_resource do
      @course_resource.update_attributes(course_resource_attributes)
    end
  end

  def destroy
    authorize @course_resource

    render_course_resource { @course_resource.destroy }
  end

  private

  def render_course_resource
    if !block_given? || yield
      render json: @course_resource
    else
      render json: @course_resource.errors, status: :unprocessable_entity
    end
  end

  def find_course_resource
    @course_resource = CourseResource.find(params[:id])
  end

  def find_parent
    @parent = if params[:section_id]
                Section.find(params[:section_id])
              else
                @course_resource.section
              end
  end

  def course_resource_attributes
    params.require(:course_resource).permit(
      :category,
      :content,
      :title,
      :url
    )
  end
end
