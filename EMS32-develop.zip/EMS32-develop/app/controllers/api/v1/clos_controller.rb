# Course learning outcomes
class Api::V1::ClosController < Api::V1::ApiController
  using CastToBooleanStringRefinement

  before_action :find_clo, only: %i(show update destroy)
  before_action :find_parent
  before_action :assign_creator_id_to_rubrics, only: %i(create)
  before_action :assign_updater_id_to_rubrics, only: %i(update)

  def index
    authorize @parent, :show?

    clos = @parent.course_learning_outcomes
    clos = clos.where(active: active?) if index_attributes[:active]

    render json: clos,
           each_serializer: CloSerializer
  end

  def show
    authorize @clo

    render_clo
  end

  def create
    @clo = @parent.course_learning_outcomes.new(clo_attributes)
    authorize @clo
    render_clo { @clo.save }
  end

  def update
    authorize @clo

    render_clo { @clo.update_attributes(clo_attributes.to_h) }
  end

  def sort
    authorize @parent, :edit?

    sort_positions.each do |item|
      clo = @parent.course_learning_outcomes.find(item[:id])
      clo.update_attribute(:position, item[:position])
    end

    render json: @parent.course_learning_outcomes,
           each_serializer: CloSerializer
  end

  private

  def sort_positions
    params.require(:sort).permit(
      positions: [:id, :position]
    ).fetch(:positions, [])
  end

  def render_clo
    if !block_given? || yield
      render json: @clo, serializer: CloSerializer
    else
      render json: @clo.errors, status: :unprocessable_entity
    end
  end

  def find_parent
    @parent = if params[:course_id]
                Course.find(params[:course_id])
              else
                @clo.section || @clo.course
              end
  end

  def find_clo
    @clo = CourseLearningOutcome.find(params[:id])
  end

  def clo_attributes
    # temporary fix by duplicating params
    # will be resolved in next rails version
    params.require(:clo).permit(
      :name,
      :active,
      :publish,
      :position,
      :description,
      :plo_ids,
      rubrics_attributes: [:id, :title, :description, :creator_id, :updater_id],
      plo_ids: []
    )
  end

  def index_attributes
    params.permit(:active)
  end

  def active?
    params.fetch(:active, '').to_boolean
  end

  def assign_creator_id_to_rubrics
    return unless params[:clo][:rubrics_attributes]
    params[:clo][:rubrics_attributes].each do |r|
      r[:creator_id] = current_user.id
    end
  end

  def assign_updater_id_to_rubrics
    return unless params[:clo][:rubrics_attributes]
    params[:clo][:rubrics_attributes].each do |r|
      r[:updater_id] = current_user.id
    end
  end
end
