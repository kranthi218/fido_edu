class Api::V1::QuestionAnswersController < Api::V1::ApiController
  before_action :find_question
  before_action :find_question_answer, only: %i(show update destroy)

  def index
    authorize @question, :show?

    render json: @question.question_answers
  end

  def show
    authorize @question_answer

    render_question_answer
  end

  def create
    @question_answer =
      @question.question_answers.new(question_answer_attributes)

    authorize @question_answer

    render_question_answer { @question_answer.save }
  end

  def update
    authorize @question_answer

    render_question_answer do
      @question_answer.update_attributes(question_answer_attributes)
    end
  end

  def destroy
    authorize @question_answer

    render_question_answer { @question_answer.destroy }
  end

  private

  def render_question_answer
    if !block_given? || yield
      render json: @question_answer
    else
      render json: @question_answer.errors, status: :unprocessable_entity
    end
  end

  def find_question_answer
    @question_answer = QuestionAnswer.find params[:id]
  end

  def find_question
    @question = Question.find params[:question_id]
  end

  def question_answer_attributes
    params.require(:question_answer).permit(
      :answer,
      :choice,
      :points,
      :question_type
    )
  end
end
