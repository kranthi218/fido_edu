# This controller handles Coursework's submissions to use with Grader
class Api::V1::StudentSubmissionsController < Api::V1::ApiController
  using CastToBooleanStringRefinement

  ALLOWED_SUBMISSIONS = %w(StudentAssignment DiscussionParticipant QuizScore)
  ALLOWED_COURSEWORK  = %w(Assignment Discussion Quiz)
  SUBMISSION_ATTRIBUTES = [
    :id,
    :score,
    :student_id,
    :feedback,
    :graded,
    :unsubmitted,
    :published,
    assessment_learning_outcomes_attributes: [
      :id,
      :score,
      :course_learning_outcome_id
    ]
  ]

  before_action :find_submission, only: %i(update destroy)
  before_action :find_coursework, only: %i(show create index)

  def index
    authorize @coursework, :edit?

    @submissions = @coursework.submissions.includes(
      :assessment_learning_outcomes,
      @coursework.class.model_name.singular,
      @coursework.is_a?(Assignment) ? :assets : nil,
      student: [:user]
    )

    if display_unsubmitted?
      @submissions += @coursework.build_unsubmitted(@submissions)
    end

    render json: @submissions, each_serializer: StudentSubmissionSerializer
  end

  def show
    student     = @coursework.section.students_with_inactive.find(params[:id])
    @submission = @coursework.submissions.for_student(student).first
    @submission ||= build_unsubmitted(@coursework, params[:id])

    authorize @submission

    render json: @submission, serializer: submission_serializer
  end

  def create
    @submission = @coursework.submissions.new unsubmitted_submission_attributes
    @submission.section_id = params[:section_id]
    authorize @submission, :create?

    if @submission.save
      create_activity

      render json: @submission, serializer: submission_serializer
    else
      render json: @submission.errors, status: :unprocessable_entity
    end
  end

  def update
    authorize @submission, :update?

    if @submission.update_attributes(submission_attributes)
      create_activity :update

      render json: @submission, serializer: submission_serializer
    else
      render json: @submission.errors, status: :unprocessable_entity
    end
  end

  def destroy
    authorize @submission, :destroy?

    if @submission.destroy
      render json: build_unsubmitted(@submission.coursework,
                                     @submission.student_id),
             serializer: submission_serializer
    else
      render json: @submission.errors, status: :unprocessable_entity
    end
  end

  private

  def submission_serializer
    (@submission.class.to_s + 'Serializer').constantize
  end

  def create_activity(event = :create)
    section = @submission.section

    @submission.create_activity(
      event,
      owner: section,
      recipient: @submission.student,
      parameters: {
        title: @submission.coursework.title,
        section: section.try(:course_and_section_no)
      }
    )
  end

  def find_coursework
    if ALLOWED_COURSEWORK.include?(params[:coursework_type].try(:camelize))
      model       = params[:coursework_type].camelize.constantize
      @coursework = model.find params[:coursework_id]
    else
      head :forbidden
      false
    end
  end

  def find_submission
    if ALLOWED_SUBMISSIONS.include?(params[:type].try(:camelize))
      model = params[:type].camelize.constantize
      @submission = model.find params[:id]
    else
      head :forbidden
      false
    end
  end

  def build_unsubmitted(coursework, student_id)
    coursework.submissions.build(
      student_id: student_id,
      unsubmitted: true,
      score: nil,
      section: coursework.section
    )
  end

  def submission_attributes
    params.require(:student_submission)
          .permit(*SUBMISSION_ATTRIBUTES)
  end

  def unsubmitted_submission_attributes
    params.require(:student_submission)
          .permit(*SUBMISSION_ATTRIBUTES)
  end

  def display_unsubmitted?
    params[:display_unsubmitted] && params[:display_unsubmitted].to_boolean
  end
end
