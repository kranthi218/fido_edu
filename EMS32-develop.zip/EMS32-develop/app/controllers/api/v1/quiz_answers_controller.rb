class Api::V1::QuizAnswersController < Api::V1::ApiController
  after_action :update_quiz_score, only: :update
  def update
    @quiz_answer = QuizAnswer.find params[:id]

    authorize @quiz_answer

    render_quiz_answer do
      @quiz_answer.update_attributes(quiz_answer_attributes)
    end
  end

  private

  def render_quiz_answer
    if !block_given? || yield
      render json: @quiz_answer
    else
      render json: @quiz_answer.errors, status: :unprocessable_entity
    end
  end

  def quiz_answer_attributes
    params.require(:quiz_answer).permit(
      :state,
      :score
    )
  end

  def update_quiz_score
    quiz_score = @quiz_answer.quiz_score
    score      = QuizAnswer.where(quiz_score_id: quiz_score.id).sum(:score)
    graded     = quiz_score.all_answers_graded?

    quiz_score.update_attributes(score: score, graded: graded)
  end
end
