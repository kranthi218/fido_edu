class Api::V1::ProfilesController < Api::V1::ApiController
  def show
    render json: current_user, serializer: ProfileSerializer
  end
end
