# This controller handles Sections RESTful APIs
class Api::V1::SectionsController < Api::V1::ApiController
  before_action :find_term, only: %i[index]
  before_action :find_section, only: %i[show update]

  has_search_params defaults: { sort: 'course.name' },
                    filters: %i[ category
                                 department_id
                                 grading_method
                                 program_id
                                 syllabus_approved
                                 term_id ]

  def index
    sections = Section.custom_search(query_param, filter_params)
                      .filter(ids: { values: permitted_sections.pluck(:id) })
                      .order(sorting_params)
                      .page(page_param)
                      .per(per_page_param)

    set_search_headers(sections)

    @indices = sections.reduce({}) do |acc, elem|
      acc.merge(elem.id => elem.attributes)
    end

    render json: sections.load(
      section: {
        scope: Section.includes(
          :term,
          :course,
          :section_availabilities,
          section_faculty: { faculty: :user },
          schedules: :lecture_hall
        )
      }
    ).objects
  end

  def show
    authorize @section

    respond_to do |format|
      format.json { render json: @section }
      format.pdf  { export_pdf }
    end
  end

  def update
    authorize @section

    render_section { @section.update_attributes(section_attributes) }
  end

  private

  def render_section
    if !block_given? || yield
      render json: @section
    else
      render json: @section.errors, status: :unprocessable_entity
    end
  end

  def permitted_sections
    SectionPolicy::Scope.new(current_user,
                             Section.for_term(@term),
                             params.fetch(:role, :both)).resolve
  end

  def section_attributes
    params.require(:section).permit(
      :bio,
      :chat,
      :description,
      :additional_policies,
      :grading_method,
      :course_modules_layout,
      :additional_learning_outcomes,
      :instructors_policies,
      :office_hours
    )
  end

  def find_term
    @term = Term.find_by(id: params[:term_id]) || Term.current
  end

  def find_section
    @section = Section.find(params[:id])
  end

  def export_pdf
    coursework_timeline =
      CourseworkTimeline.new(@section).group_courseworks_by_milestones

    render pdf: format('%s Syllabus', @section.course_and_section_no),
           template: '/shared/sections/syllabus.pdf',
           layout: 'layouts/pdf.html.haml',
           disposition: 'attachment',
           show_as_html: params.key?('debug'),
           locals: { section: @section,
                     coursework_timeline: coursework_timeline }
  end
end
