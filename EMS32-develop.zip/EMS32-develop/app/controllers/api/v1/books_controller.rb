class Api::V1::BooksController < Api::V1::ApiController
  before_action :find_book, only: %i(show update destroy)
  before_action :find_parent

  def index
    authorize @parent, :show?

    render json: @parent.books
  end

  def show
    authorize @book

    render_book
  end

  def create
    @book = @parent.books.new(book_attributes)

    authorize @book

    render_book { @book.save }
  end

  def update
    authorize @book

    render_book { @book.update_attributes(book_attributes) }
  end

  def destroy
    authorize @book

    render_book { @book.destroy }
  end

  private

  def render_book
    if !block_given? || yield
      render json: @book
    else
      render json: @book.errors, status: :unprocessable_entity
    end
  end

  def find_book
    @book = Book.find(params[:id])
  end

  def find_parent
    @parent = if params[:section_id]
                Section.find(params[:section_id])
              else
                @book.section
              end
  end

  def book_attributes
    params.require(:book).permit(
      :author,
      :description,
      :edition,
      :isbn,
      :publication_date,
      :publisher,
      :required,
      :title,
      :instructor_regular_edition_copy,
      :instructor_teaching_edition_copy,
      :course_reserve_copies,
      :available_used,
      :copy_format,
      :media,
      :book_media_type,
      :dvd_media_type,
      :package_media_type
    )
  end
end
