# This controller handles DiscussionComments RESTful API
class Api::V1::DiscussionCommentsController < Api::V1::ApiController
  using CastToBooleanStringRefinement

  before_action :find_discussion_comment, except: %i[create index]
  before_action :find_discussion

  def index
    authorize @parent, :show?

    discussion_comments = @parent
                          .discussion_comments
                          .send(index_scope)
                          .includes(:user, :assets)

    render json: discussion_comments
  end

  def create
    @discussion_comment =
      @parent.discussion_comments.new(discussion_comment_attributes)

    @discussion_comment.user = current_user
    @discussion_comment.participatable = participatable_for_user

    authorize @discussion_comment, :update?

    render_discussion_comment { @discussion_comment.save }
  end

  def update
    authorize @discussion_comment, :update?

    render_discussion_comment do
      @discussion_comment.update_attributes(discussion_comment_attributes)
    end
  end

  def destroy
    authorize @discussion_comment, :update?

    render_discussion_comment { @discussion_comment.destroy }
  end

  private

  def index_scope
    params.fetch(:include_hidden, '').to_boolean ? 'all' : 'visible'
  end

  def render_discussion_comment
    if !block_given? || yield
      render json: @discussion_comment
    else
      render json: @discussion_comment.errors, status: :unprocessable_entity
    end
  end

  def find_discussion_comment
    @discussion_comment = DiscussionComment.find params[:id]
  end

  def find_discussion
    @parent = if params[:discussion_id]
                Discussion.find params[:discussion_id]
              elsif params[:student_submission_id]
                DiscussionParticipant.find params[:student_submission_id]
              elsif @discussion_comment
                @discussion_comment.discussion
              end
  end

  def discussion_comment_attributes
    params.require(:discussion_comment).permit(
      :discussion_id,
      :parent_id,
      :content,
      :hidden
    )
  end

  def participatable_for_user
    policy = DiscussionCommentPolicy.new(current_user, @discussion_comment)
    section = @parent.is_a?(Discussion) ? @parent.coursework.section : @parent.section
    if policy.faculty_of?(section)
      current_user.faculty
    elsif policy.student_of?(section)
      current_user.student
    end
  end
end
