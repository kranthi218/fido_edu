class Api::V1::FaqWhitelistController < Api::V1::ApiController
  def index
    render json: { whitelisted: whitelisted? }
  end

  private

  def whitelisted?
    FAQ_WHITELIST.include?(current_user.email) ||
      (current_admin_user? && FAQ_WHITELIST.include?(current_admin_user.email))
  end
end
