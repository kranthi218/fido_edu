class Api::V1::GradebooksController < Api::V1::ApiController
  include FinalGradesExtension

  before_action :find_section
  before_action :ensure_all_grades_set, only: :finalize

  def show
    authorize @section, :edit?

    render json: submissions_for(@section, student_status_params),
           each_serializer: GradebookSerializer
  end

  def student_roster
    authorize @section, :edit?

    @section_students = @section.section_students
                                .active_enrollments
                                .includes(%i[section student user grade])

    render json: @section_students, each_serializer: StudentRosterSerializer
  end

  def finalize
    authorize @section

    render json: finalize_grades(@section)
  end

  private

  # @see StudentRosterSerializer
  def student_roster_organizer
    @student_roster_organizer ||= StudentRosterOrganizer.new(@section)
  end

  helper_method :student_roster_organizer

  def find_section
    @section = Section.find(params[:section_id])
  end

  def submissions_for(section, status)
    active_student_ids = section.section_students
                                .in_status(status)
                                .pluck(:student_id)

    StudentAssignment
      .includes(assignment: %i[section student_deadlines])
      .where(assignment_id: section.assignments.active.gradable)
      .where(student_id: active_student_ids) +
      DiscussionParticipant
      .includes(discussion: %i[section student_deadlines])
      .where(discussion_id: section.discussions.active.gradable)
      .where(student_id: active_student_ids) +
      QuizScore
      .includes(quiz: %i[section student_deadlines])
      .where(quiz_id: section.quizzes.active.gradable)
      .where(student_id: active_student_ids)
  end

  def ensure_all_grades_set
    return if SectionStudent.for_section(@section).ungraded.none?

    render json: { message: 'All students have to be graded' },
           status: :unprocessable_entity
  end

  def student_status_params
    params.permit(:status)
          .fetch(:status, 'enrolled,graded')
          .split(',') & SectionStudent::PERMITTED_STATUSES
  end
end
