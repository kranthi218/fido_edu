class Api::V1::DiscussionsController < Api::V1::ApiController
  before_action :find_discussion, only: %i[show update destroy course_module]
  before_action :find_parent

  def index
    authorize @parent, :show?

    render json: @parent.discussions
  end

  def show
    authorize @discussion

    render_discussion
  end

  def create
    @discussion = @parent.discussions.new(discussion_attributes)
    coursework = @parent.coursework.create(kind: :regular)
    @discussion.coursework = coursework
    authorize @discussion

    create_and_render_discussion { @discussion.save }
  end

  def update
    authorize @discussion

    render_discussion { @discussion.update_attributes(discussion_attributes) }
  end

  def destroy
    authorize @discussion

    render_discussion { @discussion.destroy }
  end

  def course_module
    authorize @discussion, :update?

    target_id = params.require(:course_module).fetch(:id)
    target    = @parent.course_modules.find_by(id: target_id)

    render_discussion do
      @discussion.update_attribute(:course_module_id, target.try(:id))
    end
  end

  private

  def render_discussion
    if !block_given? || yield
      render json: @discussion, include: '**'
    else
      render json: @discussion.errors, status: :unprocessable_entity
    end
  end

  def create_and_render_discussion
    if !block_given? || yield
      render json: @discussion, include: '**'
    else
      @discussion.coursework.destroy!
      render json: @discussion.errors, status: :unprocessable_entity
    end
  end

  def find_discussion
    @discussion = Discussion.includes(course_learning_outcomes:
      [rubrics: [:rubric_score_guides]]).find(params[:id])
  end

  def find_parent
    @parent = if params[:section_id]
                Section.find(params[:section_id])
              else
                @discussion.section
              end
  end

  def discussion_attributes
    if params[:discussion].key?(:course_learning_outcome_ids)
      params[:discussion][:course_learning_outcome_ids] ||= []
    end

    params.require(:discussion).permit(
      :course_module_id,
      :category,
      :content,
      :ends_at,
      :grading_policy_id,
      :points,
      :hours,
      :rubric_id,
      :soft_deadline,
      :starts_at,
      :title,
      :topic,
      :active,
      :visible,
      :minimum_words,
      assets: [],
      links_attributes: %i[id url],
      course_learning_outcome_ids: []
    )
  end
end
