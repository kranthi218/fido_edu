# Api::V1 endpoint for Quizzes
#
class Api::V1::QuizzesController < Api::V1::ApiController
  before_action :find_quiz, only: %i(update destroy course_module)
  before_action :find_parent

  def index
    authorize @parent, :show?

    render json: @parent.quizzes
  end

  def show
    @quiz = Quiz.includes(questions: %i(assets question_answers))
            .find(params[:id])

    authorize @quiz

    respond_to do |format|
      format.json do
        render json: @quiz, include: [questions: %i(assets question_answers)]
      end

      format.pdf { export_pdf }
    end
  end

  def create
    @quiz = @parent.quizzes.new(quiz_attributes)
    coursework = @parent.coursework.create(kind: :regular)
    @quiz.coursework = coursework

    authorize @quiz

    create_and_render_quiz { @quiz.save }
  end

  def update
    authorize @quiz

    render_quiz { @quiz.update_attributes(quiz_attributes) }
  end

  def destroy
    authorize @quiz

    render_quiz { @quiz.destroy }
  end

  def course_module
    authorize @quiz, :update?

    target_id = params.require(:course_module).fetch(:id)
    target    = @parent.course_modules.find_by(id: target_id)

    render_quiz do
      @quiz.update_attribute(:course_module_id, target.try(:id))
    end
  end

  private

  def render_quiz
    if !block_given? || yield
      render json: @quiz, include: [questions: %i(assets question_answers)]
    else
      render json: @quiz.errors, status: :unprocessable_entity
    end
  end

  def create_and_render_quiz
    if !block_given? || yield
      render json: @quiz, include: [questions: %i(assets question_answers)]
    else
      @quiz.coursework.destroy!
      render json: @quiz.errors, status: :unprocessable_entity
    end
  end

  def find_quiz
    @quiz = Quiz.includes(course_learning_outcomes:
      [rubrics: [:rubric_score_guides]]).find(params[:id])
  end

  def find_parent
    @parent = if params[:section_id]
                Section.find(params[:section_id])
              else
                @quiz.section
              end
  end

  def quiz_attributes
    if params[:quiz].key?(:course_learning_outcome_ids)
      params[:quiz][:course_learning_outcome_ids] ||= []
    end

    params.require(:quiz).permit(
      :active,
      :allocate_total_points,
      :attempts,
      :course_module_id,
      :description,
      :ends_at,
      :grading_method,
      :grading_policy_id,
      :hide_scores_on_submission,
      :hours,
      :points,
      :rubric_id,
      :show_answers,
      :shuffle_questions,
      :soft_deadline,
      :starts_at,
      :time_limit,
      :title,
      :visible,
      assets: [],
      course_learning_outcome_ids: [],
      questions_attributes: []
    )
  end

  def parent_name
    @parent.try(:course_and_section_no) || @parent.try(:course_no)
  end

  def export_pdf
    render pdf: "#{parent_name} #{@quiz.title}",
           template: '/shared/quizzes/quiz.pdf',
           layout: 'layouts/pdf.html.haml',
           disposition: 'attachment',
           locals: { quiz: @quiz }
  end
end
