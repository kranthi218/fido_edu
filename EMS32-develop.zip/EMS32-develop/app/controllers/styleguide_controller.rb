class StyleguideController < ActionController::Base

  add_breadcrumb 'Styleguide', :styleguide_root_path

  before_action except: :index do
    add_breadcrumb params[:action].humanize.titleize
  end

  def index
  end

  def bootstrap_customizations
  end

  def creating_new_styles
  end

end
