# `CalendarController` manages the work of adding, viewing,
# and removing items from a user's calendar
class CalendarsController < ApplicationController
  before_action :fetch_calendar

  attribute_view_helper :calendar

  respond_to :html, :json

  def show
    respond_with(@calendar) do |format|
      format.html { render :show, layout: false }
    end
  end

  def create
    ci = @calendar.items.create(calendar_params)

    if ci.persisted?
      respond_with(@calendar) do |format|
        format.html { render :show, layout: false }
      end

    else
      render json: @calendar, status: :not_acceptable
    end
  end

  def destroy
    @calendar.items.find(params[:id]).destroy
    url = student_dashboard_path(
      anchor: view_context.dom_id(@calendar))

    respond_with(@calendar) do |format|
      format.html { redirect_to url }
    end
  end

  private

  def fetch_calendar
    @calendar = Calendar.includes(:items).where(user_id: current_user).first ||
      Calendar.create(user_id: current_user.id)
  end

  def calendar_params
    params.require(:calendar_item).permit([:title, :due_at])
  end
end
