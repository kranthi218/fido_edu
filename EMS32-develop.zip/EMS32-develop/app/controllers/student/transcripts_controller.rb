class Student::TranscriptsController < Student::StudentController
  def index
    student_number = current_user.student.student_number
    params[:div_cde] = "MS" if params[:div_cde].nil?
    @active_enrollments = Ex::StudentCourseHistory
      .where(id_num: student_number, crs_div: params[:div_cde])
      .visible_courses
      .order("yr_cde desc, trm_cde desc")
      .group_by(&:yr_cde)

    @student_transcript_summary = Ex::StudentDivMaster
      .find_by_id_num(student_number)

    @student_sum_of_term_enrollments = Ex::StudentTermSum
      .sum_of_enrollment_by_term
      .by_student_number(student_number)
      .order("yr_cde desc, trm_cde desc")

    respond_to do |format|
      format.html { render layout: !pjax? }
      format.pdf do
        render pdf: format('%s - Unofficial Transcript', current_user.name),
               template: 'student/transcripts/index',
               header: {
                 html: {
                   template: 'shared/transcripts/header',
                   locals: {
                     student: @student.student
                   }
                 },
                 spacing: 10
               },
               footer: {
                 left: 'Page: [page] of [topage]',
                 spacing: 10
               },
               margin: {
                 top: 30,
                 bottom: 30
               },
               layout: 'layouts/pdf.html.haml', show_as_html: params[:html]
      end
    end
  end
end
