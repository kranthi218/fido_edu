# This controller handles the viewing and submission
# of an individual Discussion.
class Student::DiscussionsController < Student::StudentController
  attribute_view_helper :section

  before_action only: :index do
    authorize_and_load_section
    apply_generic_coursework_breadcrumbs
    add_breadcrumb 'Discussions'
  end

  def index
    @discussion_organizer =
      SectionUnreadDiscussionCounts.new section, current_user, :student
  end
end
