class Student::QuizzesController < Student::StudentController
  before_action only: %i(index show edit update back) do
    authorize_and_load_section
    apply_generic_coursework_breadcrumbs if @section
  end

  before_action only: %i(show edit update back) do
    @quiz = @section.quizzes.find(params[:id])

    authorize @quiz, :show?

    validate_coursework_availability @quiz
    @quiz_score = QuizScore.student_quiz_score(@quiz.id, @student.id).first
  end

  def index
    @quizzes = QuizPolicy::Scope.new(current_user, Quiz, @section).resolve
  end

  def edit
    if @quiz.taken_by?(@student.id)
      @error = t('controllers.student.quizzes.quiz_taken')

    elsif @quiz.overdue?(@student.id)
      @error = t('controllers.student.quizzes.overdue')

    else

      # resume quiz
      if @quiz_score.present?
        @question        = resume_quiz(@quiz.id, @quiz_score, @student.id)
        @question_number = @quiz_score.question_set.index(@question.id) + 1

      # taking quiz for very first time.
      else
        question_set = @quiz.question_id_set
        @quiz_score  = new_quiz_score(@student, @quiz, question_set)

        authorize @quiz_score, :submit?

        @quiz_score.save

        # @question sets to first question
        @question        = Question.find(question_set.first)
        @question_number = question_set.index(@question.id) + 1
      end

      @error = timer_expired_message if @quiz_score.ended?

    end
    render :quiz_status if @error.present?
  end

  def show
    @quiz_status = q_status
    @score = q_score if @quiz_status
  end

  def update
    time = Time.zone.now

    # current_ question implies question submitted by student.
    current_question = params[:quiz][:quiz_answer][:question_id].to_i
    button_clicked   = params[:button]
    score_card       = QuizScoreCard.new(@quiz_score, quiz_answer_params)

    authorize @quiz_score, :submit?

    # Ocassionally, students will click the browser back button after
    # submitting quiz. The following conditional helps in finding whether
    # student has already submitted the quiz or not
    if @quiz_score.graded? || @quiz_score.submitted_at?
      @error = t('controllers.student.quizzes.quiz_taken')

      render layout: false, template: 'student/quizzes/quiz_status'
      return
    end

    # Now figure out if student exceeded their timelimit.
    # Give them 1 minute (magic number) to avoid rejecting submissions near the
    # end of the time limit due to network latency.
    if @quiz_score.timer_expired?(guard: 1.minute)
      @error = timer_expired_message

      render layout: false, template: 'student/quizzes/quiz_status'
      return

    else
      update_quiz_score(@quiz_score, current_question, score_card)

      # if user click submit quiz(final) button or quiz is auto submitted
      # then updates quiz submit time and render quiz status.
      if %w(finished timeout).include?(button_clicked)
        student_submitted_at(@quiz_score, time, button_clicked)

        @success = q_status

        render layout: false, template: 'student/quizzes/quiz_status'
        return
      end

      @question = QuizNavigation.new(@quiz_score, current_question)
                                .next_or_previous_question(button_clicked)

      render layout: false, partial: 'student/quizzes/question/question'
    end
  end

  private

  attr_reader :quiz
  helper_method :quiz

  def q_status
    return unless @quiz_score.present? &&
                  (@quiz_score.submitted_at.present? ||
                   @quiz_score.unsubmitted? ||
                   @quiz_score.ended?)

    if @quiz_score.timed_out?
      t('controllers.student.quizzes.quiz_auto_submission')

    else
      t('controllers.student.quizzes.quiz_submitted',
        quiz_submitted_at: view_context
        .format_datetime(@quiz_score.submitted_at))
    end
  end

  def q_score
    return t(
      'controllers.student.quizzes.quiz_score',
      score: @quiz_score.score.to_s,
      total_points: view_context.number_with_precision(
        quiz.assigned_question_points,
        precision: 1
      )
    ) if @quiz_score.graded? &&
         (!@quiz.hide_scores_on_submission ||
          @quiz.deadline(@quiz_score.student).try(:past?))

    t('controllers.student.quizzes.quiz_score_pending_due_date', due_date: view_context.format_datetime(@quiz.deadline(@quiz_score.student)))
  end

  def timer_expired_message
    t(
      'controllers.student.quizzes.timer_expired_message',
      quiz_ends_at:    view_context.format_datetime(@quiz.ends_at),
      quiz_time_limit: @quiz.time_limit,
      quiz_started_at: view_context.format_datetime(@quiz_score.started_at),
      quiz_started_time_ago:
        view_context.time_ago_in_words(@quiz_score.started_at),
      current_time: view_context.format_datetime(Time.zone.now)
    )
  end

  def new_quiz_score(student, quiz, question_set)
    QuizScore.new(
      student_id:     student.id,
      quiz_id:        quiz.id,
      started_at:     Time.zone.now,
      question_set:   question_set,
      first_question: question_set.first,
      last_question:  question_set.last,
      status:         'started',
      section:        @section
    )
  end

  # We save the students responses regardless whether their scores will count
  # so we have them if we make an error.
  def update_quiz_score(quiz_score, current_question, score_card)
    quiz_score.update_attributes(
      score: score_card.score,
      current_question: current_question,
      ip: request.remote_ip
    )
  end

  # method takes inputs quiz_id, quiz_score, student_id
  # rertuns next question which will dispaly to student
  def resume_quiz(quiz_id, quiz_score, student_id)
    current_question = QuizScore.where(
      student_id: student_id,
      quiz_id: quiz_id).first.try(:current_question)

    if current_question.nil?
      Question.find(quiz_score.question_set.first)

    # if user answered last question by clicking previous button
    # and resumed the quiz then we display last question
    elsif current_question == quiz_score.question_set.last
      Question.find(quiz_score.question_set.last)

    else
      QuizNavigation.new(quiz_score, current_question).next_question
    end
  end

  def success(success)
    render locals: { success: success }
  end

  # updating submitted_at,close_at on submit of last question or auto submission
  def student_submitted_at(quiz_score, time, status)
    quiz_score.update_attributes(
      status:       status,
      graded:       quiz_score.all_answers_graded?,
      submitted_at: time,
      close_at:     Time.current
    )
  end

  def first_question?(quiz_score, question)
    question.id == quiz_score.question_set.first
  end
  helper_method :first_question?

  def last_question?(quiz_score, question)
    question.id == quiz_score.question_set.last
  end
  helper_method :last_question?

  def student_response(quiz_score, question)
    quiz_answers = QuizAnswer.where(quiz_score_id: quiz_score.id,
                                    question_id: question.id)

    if question.question_type == 'text_answer'
      quiz_answers.first&.text_answer
    else
      quiz_answers.pluck(:question_answer_id)
    end
  end
  helper_method :student_response

  def quiz_answer_params
    params.require(:quiz).require(:quiz_answer).permit(
      :question_id,
      :question_answers,
      :text_answer,
      question_answers: []
    )
  end

  # If a student starts a quiz before the deadline but but the duration of the
  # quiz runs past the deadline, ensure the student is aware of the time
  # remaining.
  #
  # Example:
  #   A student has a quiz that is due at 7pm.
  #   That quiz allows a student to take up to 60 minutes to finish the quiz.
  #   The student starts the quiz at 6:30pm, leaving them 30 minutes of quiz
  #     time before the quiz deadline has passed.
  #   In the quiz instructions, we let them know that they only have 30
  #     minutes remaining to complete the quiz.
  def quiz_time_instructions
    deadline  = QuizScore.calc_ends_at(@quiz, @student)
    remaining = deadline - Time.current

    if remaining < quiz.time_limit.to_i.minutes
      t('controllers.student.quizzes.time_remaining_until_deadline',
        time_remaining: view_context.time_ago_in_minutes(deadline),
        deadline:       view_context.format_datetime(deadline))
    else
      t('controllers.student.quizzes.time_remaining', minutes: quiz.time_limit)
    end
  end
  helper_method :quiz_time_instructions
end
