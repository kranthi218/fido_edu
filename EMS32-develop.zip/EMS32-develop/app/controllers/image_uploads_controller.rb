class ImageUploadsController < UploadsController
  before_action :validate_images, only: [:create]

  private

  def validate_images
    json_response = {
      message: 'One of the attached files is not an image.',
      error: 'true'
    }
    invalid_files = params['file'].select { |file| !valid_image?(file) }

    render(json: json_response, status: :error) if invalid_files.any?
  end

  def valid_image?(file)
    ['image/png',
     'image/jpg',
     'image/gif',
     'image/jpeg',
     'image/pjpeg'].include? file.content_type
  end
end
