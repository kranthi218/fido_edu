class Reports::FinalGradesProgressController < Reports::ReportsController
  add_breadcrumb 'Reporting Dashboard', :reports_dashboard_path
  add_breadcrumb 'Final Grades Progress Report',
                 :reports_final_grades_progress_index_path

  before_action only: :show do
    if params.include?(:id)
      @term = Term.find(params.require(:id))
      @data = generate_report_data @term
      add_breadcrumb @term.display_name
    end
  end

  def index
    redirect_to(action: :show, id: params[:id]) if params[:id].present?
  end

  def show
    respond_to do |format|
      format.html
      format.csv do
        add_report_as_csv_response_headers response, @term
        render plain: report_as_csv(@data)
      end
    end
  end

  private

  # Generate a hash of keys and values representing a progress report
  # of students who have recieved final grades on a section by section basis
  #
  # @params [Term] term an instance of Term
  def generate_report_data(term)
    graded_sections = SectionStudent
                      .joins(:section)
                      .where(sections: { term_id: term.id })
                      .where(status: 'graded')
                      .where.not(grade_id: nil)
                      .group(:section_id)
                      .count

    term.sections.map do |sect|
      student_count = sect.students.count
      graded = graded_sections[sect.id] || 0

      if student_count.zero?
        percentage_of_students_graded = 100.0
      else
        percentage_of_students_graded = (graded.to_f / student_count) * 100
      end

      {
        course: sect.course_no,
        section: sect.section,
        graded: graded,
        enrolled: student_count,
        percent: percentage_of_students_graded,
        percent_string: view_context.number_to_percentage(
          percentage_of_students_graded,
          precision: 2,
          strip_insignificant_zeros: true
        ),
        faculty_name: sect.faculty.map { |f| f.user.full_name }.join('  '),
        faculty_email: sect.faculty.map { |f| f.user.email }.join('  '),
        status: section_status(sect),
        status_date: sect.synced_at || sect.grading_closed_at
      }
    end
  end

  # The the filename of the response when downloading the response content
  # as a CSV
  #
  # @param [ActionDispatch::Response] resp the response object to modify
  # @param [Term] term the term used to derive the report filename
  # @return [ActionDispatch::Response] the modified response object
  def add_report_as_csv_response_headers(resp, term)
    resp.headers['Content-Disposition'] = format(
      'attachment; filename="%{filename}"',
      filename: format(
        'final_grade_progress_report-%s_%s.%s.csv',
        term.name,
        term.year,
        Time.now.to_formatted_s(:number)
      )
    )

    resp
  end

  def section_status(sect)
    return 'synced'    if sect.finalized?
    return 'submitted' if sect.grades_submitted?
    'pending'
  end

  def report_as_csv(report_data)
    CSV.generate do |csv|
      csv << report_data.first.except(:percent_string).keys
      report_data.each { |hash| csv << hash.except(:percent_string).values }
    end
  end

  # Determine's the CSS class for a table row in the HTML view of the
  # grading progress report
  # @return [nil, String]
  def row_class(row)
    percentage = row[:percent]

    case
    when percentage > 0 && percentage < 100
      'warning'
    when percentage == 0
      'danger'
    else
      nil
    end
  end
  helper_method :row_class
end
