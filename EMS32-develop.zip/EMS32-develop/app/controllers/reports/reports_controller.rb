class Reports::ReportsController < ApplicationController
  layout 'reports'

  before_action :authorize_reports

  private

  def authorize_reports
    authorize :report, :access?
  end
end
