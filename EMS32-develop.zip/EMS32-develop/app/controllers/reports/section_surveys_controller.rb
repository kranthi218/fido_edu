class Reports::SectionSurveysController < Reports::ReportsController
  layout 'reports/section_surveys'

  helper Reports::SectionSurveysHelper

  helper_method :xls_params

  skip_before_action :authorize_reports, except: %i(index)

  def index
    add_breadcrumb 'Reporting Dashboard', :reports_dashboard_path
    @terms = Term.reporting
    @departments = Department.all
  end

  def report
    @survey_report = SurveyReport.new(search_params.to_h)
    @options = YAML.load_file(Rails.root.join(*%w(config survey_data_setup.yml)))['options']

    authorize @survey_report, :access?

    respond_to do |format|
      format.html { set_breadcrumb }
      format.xls do
        headers['Content-Disposition'] =
          format('filename=%s.xls', @survey_report.heading.tr!(' ', '_'))
      end
    end
  end

  def sections
    data = get_sections(
      params[:term_id],
      params[:department_id]
    )
    render json: data
  end

  def surveys
    data = get_surveys(params[:section_id])
    render json: data
  end

  private

  def search_params
    params.require(:search).permit(
      :term_id,
      :department_id,
      :section_id,
      :survey_id,
      :category
    )
  end

  def xls_params
    { search: search_params.to_h, format: :xls }
  end

  def get_sections(term_id, department_id)
    sections = Section.joins(:course).where(
      term_id: term_id,
      courses: { department_id: department_id }
    )
    sections.each_with_object({}) do |section, collection|
      collection[section.id] = section.report_selection_label
      collection
    end
  end

  def get_surveys(section_id)
    surveys = Survey.where(section_id: section_id)
    surveys.each_with_object({}) do |survey, collection|
      collection[survey.id] = survey.name
      collection
    end
  end

  def set_breadcrumb
    if current_user.role_type == 'Faculty'
      add_breadcrumb 'Faculty Dashboard', '/app/#/faculty'
    else
      add_breadcrumb 'Reporting Dashboard', :reports_dashboard_path
      add_breadcrumb 'Course Evaluations', :reports_section_surveys_path
    end

    add_breadcrumb @survey_report.heading
  end
end
