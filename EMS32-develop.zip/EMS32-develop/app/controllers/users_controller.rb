# Manages editing and updating of user information
class UsersController < ApplicationController
  include ActiveModel::ForbiddenAttributesProtection

  before_action only: [:show, :edit, :update] do |controller|
    controller.add_breadcrumb 'My Profile', :profile_path
    @user = current_user
    @student  = @user.student
    @faculty  = @user.faculty
    @employee = @user.employee
  end

  def new
    layout 'login'
    @student = Student.new
    @user = @student.build_user
  end

  def edit
    add_breadcrumb 'Edit'
  end

  def show
  end

  def update
    if update_user_with_user_params(@user)
      @user.avatar.reprocess! if @user.cropping? # reprocess when avatar is cropped
      redirect_to profile_path, notice: t('users.update.success')
    else
      add_breadcrumb 'Edit'
      render action: :edit
    end
  end

  private

  def user_params
    params.require(:user).permit(
      :gender,
      :last_name,
      :first_name,
      :middle_name,
      :ethnicity,
      :avatar,
      :current_password,
      :password,
      :password_confirmation,
      :crop_x,
      :crop_y,
      :crop_w,
      :crop_h,
      student_attributes: [
        :id,
        :date_of_birth,
        :country_of_birth
      ],
      faculty_attributes: [
        :id,
        :phone_number,
        :biography,
        :program_id
      ],
    )
  end

  # The `update_with_password` method will check for the presence of
  # a user's current password and reject changes to a user's password
  # unless their current password is included. The current password check
  # will be skipped if a new password is not included in the current
  # set of changes.
  def update_user_with_user_params(user)
    password_keys = %i(current_password password password_confirmation)
    password_changing = password_keys.any? { |k| user_params[k].present? }

    if password_changing
      # Password changes will log out the user due to their
      # session keys changing; sign them in here to avoid booting
      # them out after password changes
      sign_in(user, bypass: true) if user.update_with_password(user_params)

    else
      user.update_attributes user_params.except(:current_password)
    end
  end
end
