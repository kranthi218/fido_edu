class ChatController < ApplicationController
  before_action { authorize_and_load_section(:show?) }

  def ban
    ChatBlackList.create(section_id: params[:section_id],
                         user_id: current_user.id,
                         user_faculty_id: params[:user_faculty_id])

    flash[:alert] = "You don't have permission to access the chat for this course."
    render json: { status: "ok" }
  end
end
