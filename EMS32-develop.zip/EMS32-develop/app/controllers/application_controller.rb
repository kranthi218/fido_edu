# ApplicationController contains controller logic shared with
# **all** controllers in the application.
#
# @note Be sure to test liberally when adding or removing
#   things from this class.
class ApplicationController < ActionController::Base
  RESULTS_PER_PAGE = 25
  include FormtasticExtensions
  include VerifyRole
  include Pundit

  # This module allows us to reference controller variables within
  # models tracked by PublicActivity. This is particularly useful
  # when we can't easily derive who or what generated an activity
  # without additional context. ie: One of several faculty instructing
  # a class has updated an assignment for a particular section.
  include PublicActivity::StoreController

  before_action :authenticate_user!, unless: :devise_sessions_controller?
  before_action :check_avatar!, if: :user_signed_in?

  # Standardized handling of ElasticSearch missingindex errors
  # Probably overkill with Chewy
  rescue_from Elasticsearch::Transport::Transport::Errors::ServiceUnavailable,
              Faraday::TimeoutError do |exception|
    Airbrake.notify(exception)
    Rails.logger.debug(exception.message)

    redirect_to(
      url_for(controller: params[:controller], action: params[:action]),
      flash: {
        error: t('controllers.application.flash.searchkick_index_error')
      }
    )
  end

  rescue_from Pundit::NotAuthorizedError, with: :user_not_authorized

  # For each argument, make a private attribute reader and view helper
  # for the controller for which it is called.
  # @param [Array<String,Symbol>] method_names Any number of valid method names
  # @return [nil]
  def self.attribute_view_helper(*method_names)
    method_names.flatten.map(&:to_sym).each do |sym|
      attr_reader sym
      private sym
      helper_method sym
    end

    nil
  end

  # Alias for {.attribute_view_helper}
  # @see .attribute_view_helper
  # @return [nil]
  def self.attribute_view_helpers(*method_names)
    attribute_view_helper(*method_names)
  end

  def current_term
    @term = if params[:search] && params[:search][:term]
              Term.find(params[:search][:term])
            else
              Term.current
            end
  end
  helper_method :current_term

  def current_user
    UserDecorator.decorate(super) unless super.nil?
  end

  helper_method :current_user

  # This returns nil if there is no session
  def current_admin_user
    return unless session[:current_admin_user_id]
    @current_admin_user ||= User.find_by_id(session[:current_admin_user_id])
  end
  helper_method :current_admin_user

  def current_admin_user?
    current_admin_user.present?
  end

  helper_method :current_admin_user?

  def check_avatar!
    return if current_user.avatar.present? || current_admin_user?
    flash.now[:error] = t('controllers.application.flash.avatar_required')

    [edit_profile_path, logout_path, destroy_user_session_path].each do |path|
      return if path.start_with?(request.path)
    end

    redirect_to edit_profile_path
  end

  # This method notifies unauthorized access error appropriate way.
  # and response with rendered js string instead of redirect.
  # @return [nil]
  def user_not_authorized(exception = nil)
    respond_to do |format|
      format.html { render_exception exception }

      msg = exception ? exception.message : Rack::Utils::HTTP_STATUS_CODES[401]
      format.js { render text: "Notifier.alert('#{msg}');" }
      format.json { render json: { error: msg }, status: 401 }
    end
  end

  # rescue_from CanCan::AccessDenied do |exception|
  #   redirect_to authorization_exception_show_path, alert: exception.message
  # end

  def redirect_back_or_default(default = root_path, *options)
    tag_options = {}
    options.first.each { |k, v| tag_options[k] = v } unless options.empty?
    redirect_to((request.referer.present? ? :back : default), tag_options)
  end

  def pjax?
    request.headers['X-PJAX']
  end
  helper_method :pjax?

  def user_for_paper_trail
    current_admin_user || current_user
  end
  # custom variables to the event to be used in custom_options
  # for lograge

  def append_info_to_payload(payload)
    super
    payload[:user] = current_user && current_user.email
    payload[:ip] = request.remote_ip
    payload[:janzebar_id] = current_user && current_user.janzebar_id
    payload[:current_admin_user] = current_admin_user && current_admin_user.email
  end

  protected

  def devise_sessions_controller?
    is_a?(Devise::SessionsController)
  end

  def render_exception(exception)
    @exception = exception.message if exception
    render('authorization_exception/show', status: :unauthorized)
  end
end
