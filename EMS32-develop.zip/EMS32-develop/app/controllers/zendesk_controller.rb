class ZendeskController < ApplicationController
  def new
    @ticket = ZendeskTicket.new

    return unless user_signed_in?
    @ticket.email = current_user.email
    @ticket.name  = current_user.full_name
  end

  def create
    @ticket = ZendeskTicket.new(
      subject: params[:subject],
      body:    params[:body],
      email:   params[:email],
      name:    params[:name]
    )

    if @ticket.valid?
      response = ZendeskAPI::Ticket.create(
        Rails.application.config.zendesk,
        @ticket.to_hash
      )

      if response.present? && response.id.present?
        redirect_to new_help_url, notice: t('.success', number: response.id)
      else
        redirect_to new_help_url, alert: t('.error')
      end
    else
      render :new
    end
  end
end
