# Controller for the home screen
class HomeController < ApplicationController
  before_action do
    authorize(:home, :index?)
  end

  def index
    redirect_to user_role_root_path
  end

  private

  def access?(scope)
    Pundit.policy(current_user, scope).try(:access?)
  end

  def user_role_root_path
    if access? :faculty
      '/app/#/faculty'
    elsif access? :department
      '/app/#/hod'
    elsif access? :student
      student_dashboard_path
    elsif access? :support
      support_root_path
    elsif access? :report
      reports_dashboard_path
    elsif access? :staff
      '/app/#/staff'
    else
      authorization_exception_show_path
    end
  end
end
