# This class contains the methods common to all admin controllers.
class Admin::AdminController < ApplicationController
  layout 'admin'

  before_action do
    authorize(:admin, :access?)
  end

  before_action do
    add_breadcrumb 'Admin Dashboard', :admin_root_path
  end
end
