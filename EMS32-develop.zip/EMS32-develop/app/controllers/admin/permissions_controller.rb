class Admin::PermissionsController < Admin::AdminController
  VIEW_ACTIONS = %i(index show)
  UPDATE_CREATE_ACTIONS = %i(create update destroy)

  before_action only: VIEW_ACTIONS do
    authorize(:permission, :view?)
  end

  before_action only: UPDATE_CREATE_ACTIONS do
    authorize(:permission, :update_create?)
  end

  before_action do
    add_breadcrumb 'User Permissions', admin_permissions_path
  end

  def index
    @users = User.search(search_params, page: params[:page])
  end

  def user
    @user = User.find params.require(:user_id)
    @available_permissions = Access.generate_permissions
  end

  # Permissions are assigned in groups.
  # The subclass type is included on the form.
  # Here we use the form type to create a new object which in turn will create
  # the permissions from the provided data.
  # TODO: implement errors notification to user on validation errors
  def create
    user = params.fetch(:user)
    @user = User.find params.fetch(:user).require(:user_id)

    clss_name = 'Access::' + user.require(:group_name).to_s.camelcase
    @access_group = clss_name.classify.constantize.new @user.id

    @access_group.create_or_update user.require(:group_name),
                                   user.require(:permission)

    redirect_to user_admin_permissions_path(@user),
                notice: 'Permissions created'
  end

  def update
    permission = Permission.find params.require(:id)

    if permission.update_attributes(permission_attributes)
      redirect_to user_admin_permissions_path(permission.user),
                  notice: 'Permission updated'

    else
      redirect_to user_admin_permissions_path(permission.user),
                  error: 'Unable to update permission'
    end
  end

  def destroy
    permission = Permission.find params.require(:id)
    group_name = permission.group_name || 'access_group'
    access_group =
      ('Access::' + group_name.camelize).constantize.new(permission.user_id)

    access_group.destroy(permission)

    flash[:notice] = 'Permission removed'

    respond_to do |format|
      format.html { redirect_to user_admin_permissions_path(permission.user) }
      format.js { head :ok }
    end
  end

  private

  def search_params
    params.fetch(:search, {}).fetch(:q, nil)
  end

  def permission_attributes
    params.require(:permission).permit(
      :department_id,
      :section_id,
      :term_id,
      :user_id,
      :disabled,
      :view,
      :update_create,
      :trash
    )
  end
end
