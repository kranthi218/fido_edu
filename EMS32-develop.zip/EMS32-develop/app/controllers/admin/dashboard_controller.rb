class Admin::DashboardController < Admin::AdminController

  before_action only: [:show] do
    authorize(:dashboard, :show?)
  end


  def show
  end

end
