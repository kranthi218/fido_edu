module ApplicationHelper
  # This file is in use 1/2014
  def info_tooltip(title, msg)
    "<span class='info' data-original-title=\"#{title}\" data-toggle='popover' data-content=\"#{msg}\" data-html=\"#{true}\"><i class='icon icon-info'></i></span>".html_safe
  end

  def small_tooltip(title = nil, msg, selector)
    if title
      "<span class='#{selector}' data-original-title=\"#{title}\" data-toggle='popover' data-content=\"#{msg}\" data-html=\"#{true}\"><i class='icon icon-info'></i></span>".html_safe
    else
      "<span class='#{selector}' data-toggle='popover' data-content=\"#{msg}\" data-html=\"#{true}\"><i class='icon icon-info'></i></span>".html_safe
    end
  end

  def format_datetime_long(date_to_format)
    return unless date_to_format.respond_to?(:strftime)
    I18n.l date_to_format.in_time_zone, format: :datetime_long
  end

  def format_datetime(date_to_format)
    return unless date_to_format.respond_to?(:strftime)
    I18n.l date_to_format.in_time_zone, format: :datetime
  end

  def format_datetime_short(date_to_format)
    return unless date_to_format.respond_to?(:strftime)
    I18n.l date_to_format.in_time_zone, format: :datetime_short
  end

  def format_date(date_to_format)
    return unless date_to_format.respond_to?(:strftime)
    I18n.l date_to_format.in_time_zone, format: :date
  end

  def format_date_short(date_to_format)
    return unless date_to_format.respond_to?(:strftime)
    I18n.l date_to_format.in_time_zone, format: :date_short
  end

  def format_time_short(date_to_format, utc: false)
    return unless date_to_format.respond_to?(:strftime)
    return I18n.l date_to_format.in_time_zone('UTC'), format: :time_short if utc
    I18n.l date_to_format.in_time_zone, format: :time_short
  end

  def format_date_range(from, till)
    I18n.t(
      'time.date_range_html',
      from: format_date_short(from),
      till: format_date_short(till)
    ).html_safe
  end

  def format_time_range(from, till, is_utc: false)
    I18n.t(
      'time.date_range_html',
      from: format_time_short(from, utc: is_utc),
      till: format_time_short(till, utc: is_utc)
    ).html_safe
  end

  def notice(message)
    content_tag(:div, message, class: 'notice')
  end

  def bootstrap_class_for(flash_type)
    case flash_type
    when 'success'
      'alert-success'
    when 'notice'
      'alert-info'
    when 'error'
      'alert-danger'
    when 'alert'
      'alert-warning'
    else
      flash_type.to_s
    end
  end

  def user_can_see_chat?(section_id)
    !ChatBlackList.exists?(section_id: section_id, user_id: current_user.id)
  end

  # Generates the user data used for initializing the EMS in-app chat feature.
  # @return String a base64 encoded JSON blob
  def current_user_data_for_chat(section_id)
    user_type = 'student'
    user_type = 'faculty' if current_user.access.faculty_of?(section_id)

    @current_user_data_for_chat ||= Base64.encode64({
      id: current_user.id,
      name: current_user.full_name,
      type: user_type,
      avatar_url: current_user.avatar.url(:normal)
    }.to_json).gsub(/\n/, '')
  end

  def chat_environment
    if Rails.env == 'production' &&
       !['ems.itu.edu', 'ems31.itu.edu'].include?(ENV['WEB_HOST'])
      return 'demo'
    end
    Rails.env
  end
end
