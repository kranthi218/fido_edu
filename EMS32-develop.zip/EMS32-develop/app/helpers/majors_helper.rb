module MajorsHelper
end
