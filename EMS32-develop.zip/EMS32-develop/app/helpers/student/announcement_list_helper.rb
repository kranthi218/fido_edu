module Student::AnnouncementListHelper
  def modal_id(announcement)
    "#{dom_id(announcement)}-modal"
  end
end
