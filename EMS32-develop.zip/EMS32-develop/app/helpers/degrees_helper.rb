module DegreesHelper

  def full_degree_name(degree, major)
    if major
      "#{degree.name} in #{major.name}"
    else
      degree.name
    end
  end

end