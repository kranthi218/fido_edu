module Support::UsersHelper
  def invitation_status(user)
    if user.invitation_accepted_at
      'accepted'
    elsif user.invitation_sent_at
      'sent'
    end
  end

  def invitation_date(user)
    user.invitation_accepted_at || user.invitation_sent_at
  end
end
