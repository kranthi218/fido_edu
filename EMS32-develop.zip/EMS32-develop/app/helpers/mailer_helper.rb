module MailerHelper
  def asset_url(source)
    URI.join(root_url, asset_path(source)).to_s
  end
end
