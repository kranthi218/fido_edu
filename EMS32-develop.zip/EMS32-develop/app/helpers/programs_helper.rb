module ProgramsHelper

  def build_nested_form(form_builder, method, options = {})
    options[:object] ||= form_builder.object.class.reflect_on_association(method).klass.new
    options[:partial] ||= method.to_s.singularize
    options[:disabled] ||= false

    form_builder.fields_for(method, options[:object], :child_index => 'NEW_RECORD') do |f|
      render(:partial => "/admission_applications/#{options[:partial]}", :locals => { :f => f, :disabled => options[:disabled] })
    end
  end

  def generate_template(form_builder, method, options = {})
    escape_javascript build_nested_form(form_builder, method, options)
  end

  def generate_program_sections_report_template(sections)
    escape_javascript(render(:partial => "reports/clo_plo_mapping/sections", :locals => {:sections => sections}))
  end

end
