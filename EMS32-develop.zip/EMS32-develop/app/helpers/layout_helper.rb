module LayoutHelper

  def title(text)
    content_for(:title, text)
  end

  def header_navigation
    render partial: "navigation/main_navigation"
  end

  def dashboard?
    controller_name == "dashboard"
  end

  def selected_controller?(controller_name)
    (controller_name == params[:controller])
  end

  def selected_profile?(profile)
    (profile == params[:profile])
    return link.html_safe
  end

  def active_tab(controller_name, options)
    action_name = options[:action]
    profile = options[:profile]
    result = selected_controller?(controller_name)

    if action_name.present?
      result = result  && selected_action?(action_name)
    end

    if profile.present?
      result = result && selected_profile?(profile)
    end

    if params[:profile].present? && !profile.present?
       return ""
    end

    return result ? "on" : ""
  end

  def link_to_tab(title, url, controller_name, options={})
    data         = options.delete(:data)
    span_content = data.present? ? content_tag(:span, data) : ""
    css_class    = active_tab(controller_name, options)

    if css_class.present?
      link         = "<li class=#{css_class} >#{link_to(title, url)}#{span_content}</li>"
    else
      link         = "<li>#{link_to(title, url)}#{span_content}</li>"
    end

    return link.html_safe
  end

  def formatted_time(time, options = {})
    formatted_datetime(time, "%b %d, %Y at %I:%M %p %Z", options)
  end

  def formatted_datetime(time, format, options = {})
    options.symbolize_keys!
    options[:force_date] ||= false

    if (options[:force_date] == false) && time.present? && (time < Time.now.utc)
      return time_ago_in_words(time).sub(/about /, '') + " ago"
    else
      t = ""
      t += "#{options[:pretext]} " if options[:pretext]
      t += time.strftime(format)
      t += " #{options[:posttext]}" if options[:posttext]
      return t
    end
  end

  def time_ago_in_minutes(timestamp)
    minutes = ((timestamp - Time.current) / 60.0).round
    pluralize(minutes, 'minute')
  end

  def display_help_sidebar(options={})
    display = options.delete(:wider_content)
    content_for(:wider_content, 'wider-content') if display.present?
    content_for :sidebar do
      render :partial => "help/pages/left_sidebar"
    end
  end

  def ng_app(name)
    content_for(:ng_app, name)
  end
end
