# ActionView helpers to aid in generation of HTML required for the gobal
# siebar navigation
module SidebarHelper
  # Generate markup for a menu item in the global sidebar navigation
  # @param text [String] The text of the link in the generated menu item
  # @param url [String] The URL that this menu item will link to
  # @param html_options [Hash] HTML options to be applied to the source of the
  #   generated link. See {http://apidock.com/rails/ActionView/Helpers/UrlHelper/link_to ActionView::Helpers::UrlHelper#link_to} for reference
  # @param icon_class [String] FontAwesome icon to use within this menu item
  # @param active [Boolean] Determines if this is an active menu item or not
  #
  # @example A simple sidebar menu item
  #   sidebar_item('Home', '/home')
  #   <li><a href='/home'><span>Home</span></a></li>
  #
  # @example An active menu item with a font icon class
  #   sidebar_item('Profile', '/profile', icon_class: 'fa-user', active: true)
  #   # => <li class='active'><a href='/profile'><i class='fa fa-user'></i><span>Profile</span></a></li>
  def sidebar_item(text, url: nil, html_options: {}, icon_class: nil, active: false)
    list_item_class = active ? 'active' : nil
    icon_html = icon_class ? content_tag(:i, class: "fa #{icon_class}") {} : ''
    text_html = content_tag(:span) { text }

    content_tag(:li, class: list_item_class) do
      link_to(url, html_options) { icon_html.html_safe + text_html.html_safe }
    end
  end

  def sidebar_spacer
    content_tag(:li, class: 'spacer') { tag(:hr) }
  end
end
