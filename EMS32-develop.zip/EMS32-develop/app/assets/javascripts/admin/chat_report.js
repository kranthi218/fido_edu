$(function() {
  if (typeof(console) !== 'undefined') {
    console.log('ChatReport javascript dependencies loaded');
  }

  $(function() {
    var $chat_ui      = $(".chat-ui-floating")
      , $report_table = $('.report-table.chat-report');

    function getUserData(uuid) {
      return JSON.parse(
        decodeURIComponent(
          escape(
            window.atob(uuid)
          )
        )
      );
    };

    function fillUsers(messages) {
      var $userSelect = $(".filter form select")
          users       = [];

      $userSelect.empty();
      $userSelect.append("<option value=''>All users</option>");

      for (var i=0; i < messages.length; i++) {
        var message   = messages[i]
          , userData  = getUserData(message.uuid);

        if (users.indexOf(userData.name) == -1) {
          users.push(userData.name);
        }
      }

      users.sort();
      for (var i=0; i < users.length; i++) {
        $userSelect.append("<option value='"+ users[i] +"'>"+ users[i] +"</option>");
      }
    }

    function filterReport(messages, start, end, user) {
      var $reportTable = $(".report-table")
        , $reportBody  = $reportTable.find("tbody")
        , startTS      = (start == "") ? null : start
        , endTS        = (end   == "") ? null : end
        , userName     = (user  == "") ? null : user;

      $reportBody.empty();

      for (var i=0; i < messages.length; i++) {
        var message   = messages[i]
          , userData  = getUserData(message.uuid)
          , date      = new Date(message.date)
          , timestamp = date.getTime() - (date.getTimezoneOffset()*60);

        if ((userName == null || userName  == userData.name) &&
            (startTS  == null || timestamp >= startTS) &&
            (endTS    == null || timestamp <= endTS)) {

          var $row = $(
            "<tr>" +
            "  <td class='index'>"+ (i+1) + "</td>" +
            "  <td class='date'>"+ date.toLocaleString() + "</td>" +
            "  <td class='user'>"+ userData.name + "</td>" +
            "  <td class='message'>"+ message.text + "</td>" +
            "</tr>"
          );

          $reportBody.append($row);
        }
      }
    };

    if ($chat_ui.length && $report_table.length) {
      var env = $(".js-chat").data("env");

      // @TODO check this
      var channel = "chat-v2-courseterm-"+ $chat_ui.data("section");
      channel = (env == 'production') ? channel : channel + '-' + env;

      var chat    = new Chat(),
            pubnub  = PUBNUB.init({
            publish_key: chat.publishKey,
            subscribe_key: chat.subscribeKey,
            ssl: true
          });

      $(".datepicker").datetimepicker({
        timepicker: false,
        format: "Y-m-d"
      });

      pubnub.history({
        channel: channel,
        callback: function(m) {
          var messages = m[0];

          fillUsers(messages);
          filterReport(messages, "", "", "");

          $(".filter form").on("submit", function(event) {
            event.preventDefault();

            var $form     = $(this)
              , startDate = $form.find("#starts_at").val().trim()
              , endDate   = $form.find("#ends_at").val().trim()
              , userName  = $form.find("#user").val().trim();

            startDate = (startDate == "") ? "" : Date.parse(startDate + "T00:00:00");
            endDate   = (endDate   == "") ? "" : Date.parse(endDate + "T23:59:59");

            filterReport(messages, startDate, endDate, userName);
          });
        }
      });
    }
  });
});
