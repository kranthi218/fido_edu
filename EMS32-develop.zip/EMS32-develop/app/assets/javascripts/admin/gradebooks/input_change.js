$(function() {
  $(".input-change").on ('change input', function(e) {
    cts_id = $(e.target).data('id')
    $('#'+ cts_id).prop('checked', true);
    $("#cts_row_" + cts_id).removeClass('success');
    $("#cts_row_" + cts_id).addClass('warning');
  });
});
