//= require dataTables/jquery.dataTables
//= require dataTables/bootstrap/3/jquery.dataTables.bootstrap

$(function () {

  if(typeof window.EMS === 'undefined') window.EMS = {};

  var DataTables = EMS.DataTables = function () {
    this.$tables = $('table.sortable');
    this.defaults = {
      'paging': false,
      'info': false,
      'searching': false,
      'bAutoWidth': false,
    };
  };

  DataTables.prototype.columnDefs = function ($table) {
    return $table.find('th').map(function (index, th) {
      return {
        'bSortable': $(th).hasClass('unsortable') ? false : true,
      };
    });
  };

  DataTables.prototype.attachAll = function () {
    var that = this;

    this.$tables.each(function(index, table) {
      var $table = $(table);
      $table.DataTable(that.renderOptions($table));
    });
  };

  DataTables.prototype.renderOptions = function ($table) {
    var sortColumn = $table.attr('data-column') || 1;

    var options = $.extend({}, this.defaults, {
      'aoColumns': this.columnDefs($table),
      'order': [[ sortColumn, 'asc' ]]
    });

    if( $table.attr('data-emptyTable') ) {
      options['language'] = {
        'emptyTable': $table.attr('data-emptyTable')
      };
    }

    return options;
  };

});

$(function () {
  var dt = new EMS.DataTables();
  dt.attachAll();
});
