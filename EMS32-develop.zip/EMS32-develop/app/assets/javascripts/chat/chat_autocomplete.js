function ChatAutocomplete(chatView) {
  this.chatView         = chatView;
  this.triggerCharacter = "@";
  this.triggerRegex     = new RegExp(this.triggerCharacter + "[\\w\\s?]*", "g");
  this.messageField     = null;
  this.source           = this.chatView.users;
  this.active           = false;
  this.currentValue     = null;
};

ChatAutocomplete.prototype.run = function(messageField) {
  this.messageField = messageField;

  if (this.currentValue !== this.messageField.value) {
    this.currentValue = this.messageField.value;

    this._addEventListeners();
    var mentions = this._findMentions();

    this._showAutocomplete(mentions);
  }
};

ChatAutocomplete.prototype._getCursorPosition = function() {
  return this.messageField.selectionStart;
};

ChatAutocomplete.prototype._findTriggerPosition = function() {
  var inputValue        = this.messageField.value
    , cursorPosition    = this._getCursorPosition()
    , index             = inputValue.lastIndexOf(this.triggerCharacter, cursorPosition)
    , charBeforeTrigger = ''
    , substr            = inputValue.substring(index, cursorPosition)
    , match             = substr.match(this.triggerRegex);

  if (index === -1) {
    return -1;
  }

  // Should precede with a space
  charBeforeTrigger = inputValue.charAt(index - 1);
  if (charBeforeTrigger && charBeforeTrigger !== ' ') {
    return -1;
  }

  if (!match) {
    return -1;
  }

  if (substr.length > match[0].length) {
    return -1;
  }

  return index;
};

ChatAutocomplete.prototype._parseInputForTrigger = function() {
  var triggerIndex = this._findTriggerPosition()
    , inputValue   = this.messageField.value
    , afterTrigger = inputValue.substring(triggerIndex)
    , match        = afterTrigger.match(this.triggerRegex);

  if (triggerIndex === -1) {
    return null;
  } else {
    return {
      pre: inputValue.substring(0, triggerIndex),
      trigger: this.triggerCharacter,
      completion: match[0].substring(this.triggerCharacter.length),
      post: (inputValue.substring(triggerIndex + match[0].length) || " ")
    };
  }
};

ChatAutocomplete.prototype._findMentions = function() {
  var triggerIndex = this._findTriggerPosition()
    , parsedInput = this._parseInputForTrigger()
    , mentions    = [];

  if (triggerIndex === -1) {
    return [];
  }

  for (var i = 0; i < this.source.length; i++) {
    var data = this.source[i]
      , regExp = new RegExp(parsedInput.completion, "i");

    if (data.match(regExp)) {
      mentions.push(data);
    }
  }

  return mentions;
};

ChatAutocomplete.prototype._showAutocomplete = function(mentions) {
  var $autocomplete     = $(".auto-complete-ui")
    , $autocompleteList = $autocomplete.find("ul")
    , html              = "";

  if (mentions.length > 0) {
    $autocompleteList.empty();

    for (var i = 0; i < mentions.length; i++) {
      var active = "active";

      if (i > 0) {
        active = "";
      }

      html += "<li data-username='"+ mentions[i] +"' class='"+ active +"'>";
      html += "  <i class='icon icon-fa icon-user'></i>";
      html += mentions[i];
      html += "</li>";
    }

    $autocompleteList.append(html);
    $autocomplete
      .removeClass("hide")
      .css("top", "-"+ ($autocomplete.height()-3) +"px");
    this.active = true;
  } else {
    $autocomplete.addClass("hide");
    this.active = false;
  }
};

ChatAutocomplete.prototype._addEventListeners = function() {
  var $autocomplete     = $(".auto-complete-ui")
    , $autocompleteList = $autocomplete.find("ul");

  this.messageField.addEventListener("keydown", function(event) {
    var keyCode = (event.keyCode || event.charCode);

    if (this.active) {
      var $autocompleteActiveEl = $(".auto-complete-ui ul li.active");

      switch(keyCode) {
      case 13: // Enter key
        this._setValue($autocompleteActiveEl.data("username"));
        break;
      case 38: // UP key
        var $autocompletePrevEl = $autocompleteActiveEl.prev();

        if ($autocompletePrevEl.length > 0) {
          $autocompleteActiveEl.removeClass("active");
          $autocompletePrevEl.addClass("active");
        }
        break;
      case 40: // DOWN key
        var $autocompleteNextEl = $autocompleteActiveEl.next();

        if ($autocompleteNextEl.length > 0) {
          $autocompleteActiveEl.removeClass("active");
          $autocompleteNextEl.addClass("active");
        }
        break;
      }

      return false;
    }
  }.bind(this));

  $autocompleteList.on("click", function(event) {
    var $autocompleteActiveEl = $(event.target);
    this._setValue($autocompleteActiveEl.data("username"));
  }.bind(this));
};

ChatAutocomplete.prototype._setValue = function(value) {
  var $autocomplete     = $(".auto-complete-ui")
    , parsedInput       = this._parseInputForTrigger()
    , newCursorPosition = null;

  if (parsedInput) {
    newCursorPosition = (parsedInput.pre + parsedInput.trigger + value).length;
    value = parsedInput.pre + parsedInput.trigger + value + parsedInput.post;

    this.messageField.value = value;
    this.active = false;
    $autocomplete.addClass("hide");

    if (newCursorPosition) {
      this._setCursorPosition(newCursorPosition);
    }
  }
};

ChatAutocomplete.prototype._setCursorPosition = function(position) {
  var range;

  if (this.messageField.value.setSelectionRange) {
    this.messageField.value.setSelectionRange(position, position);
  } else if (this.messageField.value.createTextRange) {
    range = this.messageField.value.createTextRange();
    range.collapse(true);

    if (position < 0) {
      position = this.messageField.value.length + position;
    }

    range.moveEnd('character', position);
    range.moveStart('character', position);
    range.select();
  }
};
