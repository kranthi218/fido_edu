if(typeof(console) !== "undefined") {
  console.log("Chat javascript loaded");
}

function Chat(username, channel, uuid) {
  var env = $(".js-chat").data("env");

  this.userName       = username;
  this.channel        = (env == 'production') ? channel : channel + '-' + env;
  this.uuid           = uuid;
  this.publishKey     = "pub-c-ad8eb50d-274f-4e1b-b133-7df1bcfbcfb8"
  this.subscribeKey   = "sub-c-1dd80d8e-c43d-11e3-90c5-02ee2ddab7fe";
  this.counterChannel = "message-counter-" + this.uuid;
  this.counter        = 0;
};

Chat.prototype.connect = function() {
  this.connection = PUBNUB.init({
    publish_key: this.publishKey,
    subscribe_key: this.subscribeKey,
    ssl: true,
    uuid: this.uuid
  });

  this.socket = io.connect('https://pubsub.pubnub.com/events', {
    channel: this.channel + "-events",
    publish_key: this.publishKey,
    subscribe_key: this.subscribeKey,
    ssl: true
  });

  this.socket.on("connect", function(m) { }.bind(this));
};

Chat.prototype.subscribe = function(options) {
  this.connection.subscribe.apply(this.connection, arguments);
};

Chat.prototype.unsubscribe = function(options) {
  this.connection.unsubscribe.apply(this.connection, arguments);
};

Chat.prototype.time = function(options) {
  this.connection.time.apply(this.connection, arguments);
}

Chat.prototype.publish = function(options) {
  this.connection.publish.apply(this.connection, arguments);
};

Chat.prototype.history = function(options) {
  this.connection.history.apply(this.connection, arguments);
};

Chat.prototype.block = function(uuid, user_id) {
  this.socket.emit("block", {username: uuid, user_faculty_id: user_id});
};

Chat.prototype.onBlock = function(callback) {
  this.socket.on("block", function(data) {
    callback(data);
  });
};

Chat.prototype.messageCounter = function(value) {
  if (value == undefined) {
    return this.counter;
  } else {
    this.counter = value;
    PUBNUB.db.set(this.counterChannel, "" + value);
  }
};
