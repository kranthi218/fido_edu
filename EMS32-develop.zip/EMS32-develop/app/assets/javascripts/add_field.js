$(function() {

  console.log('add_field js loaded');

  $('body').on('click', 'a.clearForm', function(e){
    e.preventDefault();
    $(this).parent('form').trigger('reset');
  });

  // Reliably empties upload
 function reset_field(e){
    e.wrap('<form>').parent('form').trigger('reset');
    e.unwrap();
  };

 $('body').on('click', 'a.addField', function(e) {
    e.preventDefault();
    var fieldToClone = $(this).data('origin');
    console.log("We are cloning this element " + fieldToClone)
    var destinationElement = $(this).data('destination');
    console.log("We are appending it to this element " + destinationElement);
    // clone the field, but only one of them
    var newField = $(this).parent().siblings(fieldToClone).first().clone(false).val('')
    console.log("We are removing this class " + fieldToClone);
    // clear out existing values, false dosen't seem to work
    reset_field(newField);
    newField.removeClass('hide');
    // append it
    newField.appendTo($(this).closest(destinationElement));
  });

})
