$(function() {

  if(typeof(console) !== "undefined") {
    console.log("widget_init javascript dependencies loaded");
  }

  $(function() {
    var datepicker_options = {
      time: "fa fa-clock-o",
      date: "fa fa-calendar",
      up: "fa fa-arrow-up",
      down: "fa fa-arrow-down"
    };

    $(".datepicker").datetimepicker(datepicker_options);
    $(".date-with-alt").each(function (i) {
      $(".date-with-alt").datetimepicker(datepicker_options);
    });
  });

});
