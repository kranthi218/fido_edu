$(function() {

  $('body').tooltip({
    selector: '[data-toggle="tooltip"]',
    placement: 'auto',
    trigger: 'hover'
  });

  $('body').popover({
    selector: '[data-toggle="popover"]',
    placement: 'auto',
    trigger: 'hover',
    html: true
  });

  $('.collapse').collapse('hide');

});
