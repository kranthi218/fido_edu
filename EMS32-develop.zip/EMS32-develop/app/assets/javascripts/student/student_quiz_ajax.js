$(function() {

  $('#quiz_form').on('ajax:beforeSend', function (xhr) {
    // hidding modal popup if its activated
    $('#modal_id').modal('hide');
    });

  $('#quiz_form').on('ajax:success', function (event, data, status, xhr) {

    $('#quiz_form').html(data);
    // setting quiz_timer.js
    new EMS.QuizTimer();
  });

  $('#quiz_form').on('ajax:error', function (event,status, xhr) {
      $('.error').html("Server error")
    });
});
