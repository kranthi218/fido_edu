$(function() {

  $(document).ready(function () {
    var debounce_ajax = _.debounce(callAjax, 1000);

    $('#janzebar_id').bind('keyup paste', function() {
      default_dropdown_value($('[name="sections"]'),"Select a Section");
      default_dropdown_value($('[name="coursework_title"]'),"Select Coursework");
      $('[name="coursework_type"]').val("Select a Coursework Type");
      if($('#janzebar_id').val().length >= '5' ) {
        $('#flash_id').html('');
        debounce_ajax();
      } else {
        // setting courses,coursework_type,coursework_titles  dropdown to default value (i.e; select)
        default_dropdown_value($('[name="sections"]'),"Select a Section");
        default_dropdown_value($('[name="coursework_title"]'),"Select Coursework");
        $('[name="coursework_type"]').val("Select a Coursework Type");
      }
    });

  function callAjax() {
    var request = $.ajax({
        url: "/support/studentcourseworks/sections",
        type: "POST",
        data: { janzebar_id: $("#janzebar_id").val(), term: $('#term').val()}
      });

    request.success(function(data) {
      if(data && _.isObject(data))
      {
        var listItems= "";
      for (var key = 0; key < data.length; key++) {
        item = data[key];
        listItems += "<option value='" + item.id + "'>" + item.name + "</option>";}
        $('#flash_id').html('');
      $('[name="sections"]').html(listItems);
      }
      else
      {
        $('#flash_id').append(data);
            }
    });

    request.error(function(data ){
      alert("Server Error - failed to generate courses");
      return false;
    });
  }

    $('[name="coursework_type"]').change(function () {
      if($('[name="sections"]').val() != '' && $('[name="coursework_type"]').val() != '')
      {
        $('#flash_id').html('');
        $.ajax({
            url: "/support/studentcourseworks/coursework_titles",
            type: "POST",
            data: { janzebar_id: $("#janzebar_id").val(), section_id: $('[name="sections"]').val(), coursework_type: $('[name="coursework_type"]').val(),
            term: $('#term').val()},
            success: function(data) {
             if(data && _.isObject(data))
              {
                var titleslist= "";
                for (var item = 0; item < data.length; item++) {
                  value = data[item];
                  if($('[name="coursework_type"]').find('option:selected').text() == "Discussion")
                  {
                    titleslist += "<option value='" + value.id+ "'>" + value.topic + "</option>";
                  }
                  else
                  {
                    titleslist += "<option value='" + value.id+ "'>" + value.title + "</option>";
                  }

                }
                $('[name="coursework_title"]').html(titleslist);
              }
              else
              {
                $('#flash_id').append(data);
                default_dropdown_value($('[name="coursework_title"]'),"Select Coursework");
              }
            },
            error: function(data ){
              alert("Server Error - failed to generate coursework titles");
            return false;
            }
        });
      }
      else
      {
        // setting coursework_type, coursework type dropdown to default value (i.e; select)
        $('[name="coursework_type"]').val("Select a Coursework Type");
        default_dropdown_value($('[name="coursework_title"]'),"Select Coursework");
      }
    });

    $('[name="sections"]').change(function () {
      // setting coursework_type, coursework type dropdown to default value (i.e; select)
      $('[name="coursework_type"]').val("Select a Coursework Type");
      default_dropdown_value($('[name="coursework_title"]'),"Select Coursework");
    });

    function default_dropdown_value(element_id,text) {
      var default_value = "<option value='" + ''+ "'>" + text + "</option>";
      element_id.html(default_value);
    }

    // search for student course works
    $('#student_coursework_search').on('ajax:beforeSend', function (xhr) {
       $('#student_coursework_list').empty();
    });

    $('#student_coursework_search').on('ajax:success', function (event, data, status, xhr) {
       $('#student_coursework_list').html(data);
    });

    $('#student_coursework_search').on('ajax:error', function (event,status, xhr) {
      alert("error in processing the request");
    });

    $('#term').change(function () {
      $('#janzebar_id').val('');
      default_dropdown_value($('[name="sections"]'),"Select a Section");
      default_dropdown_value($('[name="coursework_title"]'),"Select Coursework");
      $('[name="coursework_type"]').val("Select a Coursework Type");
    });

  });
});
