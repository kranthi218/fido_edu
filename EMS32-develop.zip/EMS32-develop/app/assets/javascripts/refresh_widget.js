//<a class="refresh_widget" data-toggle="tab" data-form="course_modules" href="#course_modules">Course Modules</a>

$(function() {

  $('.refresh-widget').click(function(e) {
    e.preventDefault();
    var formToSubmit = $(this).data('form');
    $('form#'+formToSubmit).submit();
    console.log("Submitted form#"+ formToSubmit);
  });
  console.log("Refresh Widget enabled");

});
