# frozen_string_literal: true

class SectionIndex < Chewy::Index
  settings analysis: {
    filter: {
      edge_ngram: {
        type: 'edgeNGram',
        min_gram: 3,
        max_gram: 60,
        side: 'front'
      }
    },
    analyzer: {
      name: {
        type: 'custom',
        tokenizer: 'standard',
        filter: %w[lowercase asciifolding edge_ngram]
      }
    },
    normalizer: {
      sort: {
        type: 'custom',
        token_filter: %w[trim],
        filter: %w[lowercase]
      }
    }
  }

  define_type Section.includes(:course, :faculty) do
    field :syllabus_approved, type: 'boolean'
    field :category,          type: 'keyword', normalizer: 'sort'
    field :grading_method,    type: 'integer'
    field :term_id,           type: 'integer'

    field :updated_at, type: 'date' do
      field :sort, type: 'date'
    end

    field :final_grading_date, type: 'date' do
      field :sort, type: 'date'
    end

    field :course_and_section_no, type: 'text' do
      field :sort, type: 'keyword', normalizer: 'sort'
    end

    field :coursework_count, type: 'integer' do
      field :sort, type: 'integer'
    end

    # For direct filtering
    field :department_id,    type: 'integer', value: -> { course.department_id }
    field :program_id,       type: 'integer', value: -> { course.program_id }

    field :course do
      field :name, type: 'text', analyzer: 'standard' do
        field :sort, type: 'keyword', normalizer: 'sort'
      end

      field :department_id,   type: 'integer'
      field :program_id,      type: 'integer'

      field :course_no, type: 'text', value: -> { course_no.downcase } do
        field :exact, type: 'keyword'
        field :sort,  type: 'keyword', normalizer: 'sort'
      end
    end

    field :faculty_id, type: 'integer', value: -> { faculty.map(&:id) }
    field :faculty do
      field :name, type: 'text', analyzer: 'name', value: -> { full_name } do
        field :sort, type: 'keyword', normalizer: 'sort'
      end
    end

    field :total_points,                                  type: 'integer'
    field :total_hours,                                   type: 'integer'
    field :submission_count,                              type: 'integer'
    field :student_count,                                 type: 'integer'
    field :evaluations_count,                             type: 'integer'
    field :graded_submission_count,                       type: 'integer'
    field :signature_assignment_graded_submissions_count, type: 'integer'
    field :signature_assignment_total_submissions_count,  type: 'integer'
    field :signature_assignment_ends_at,                  type: 'date'
  end
end
