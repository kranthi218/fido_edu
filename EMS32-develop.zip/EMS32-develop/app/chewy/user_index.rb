# frozen_string_literal: true

class UserIndex < Chewy::Index
  settings analysis: {
    analyzer: {
      lowercase: {
        tokenizer: 'keyword',
        filter: %w[lowercase]
      }
    },
    normalizer: {
      sort: {
        type: 'custom',
        token_filter: %w[trim],
        filter: %w[lowercase]
      }
    }
  }

  define_type User.includes(:student, :faculty) do
    field :janzebar_id, type: 'keyword', index: 'true' do
      field :sort, type: 'keyword'
    end

    field :first_name, type: 'text' do
      field :sort, type: 'keyword', normalizer: 'sort'
    end

    field :last_name, type: 'text' do
      field :sort, type: 'keyword', normalizer: 'sort'
    end

    field :full_name, type: 'text', analyzer: 'standard' do
      field :exact, type: 'keyword'
      field :sort,  type: 'keyword', normalizer: 'sort'
    end

    field :email, type: 'keyword' do
      field :sort, type: 'keyword', normalizer: 'sort'
    end

    field :is_student, type: 'boolean', value: -> { student.present? }
    field :is_faculty, type: 'boolean', value: -> { faculty.present? }
  end
end
