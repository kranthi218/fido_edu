class JanzebarDegreeHistorySyncJob < ApplicationJob
  queue_as :default

  def perform
    dh = DegreeHistorySync.new
    dh.sync!
  end
end
