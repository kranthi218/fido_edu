class JanzebarGradeJob < ApplicationJob
  queue_as :sync
  sidekiq_options backtrace: true

  # @param term_id [Array<Term>, Term] array of terms(ids) or a single term(id)
  def perform(term_id)
    terms = Term.where(id: term_id)

    ex_sections = terms.inject([]) do |acc, term|
      acc.concat Ex::Section.where(
        trm_cde: term.janzebar_term,
        yr_cde: term.janzebar_year
      )
    end

    gs = GradeSync.new { |syncer| syncer.logger = grade_logger }

    gs.sync!(ex_sections)
  end

  protected

  def grade_logger
    Logger.new(File.join(Rails.root, 'log', 'janzebar_grade_sync.log'))
  end
end
