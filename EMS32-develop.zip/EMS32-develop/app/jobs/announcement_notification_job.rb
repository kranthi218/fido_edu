class AnnouncementNotificationJob < ApplicationJob
  queue_as :notifications

  def perform(announcement_id)
    announcement = Announcement.find(announcement_id)
    announcable  = announcement.announcable.is_a?(Section)
    recipients = if announcable
                   announcement.announcable.mailing_list
                 else
                   eannouncement.announcable.section.mailing_list
                 end

    announcement.started!

    recipients.each do |user|
      if announcable
        AnnouncementNotifier.send_announcement(announcement, user).deliver
      else
        Mail::SectionReminderNotifications.send_reminder(announcement, user).deliver
      end
    end

    announcement.delivered!
  rescue StandardError
    announcement&.errored!
  end
end
