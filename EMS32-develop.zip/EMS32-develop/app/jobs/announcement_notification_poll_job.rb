class AnnouncementNotificationPollJob < ApplicationJob
  queue_as :notifications

  def perform
    announcement = Announcement.current.published.pending.first
    AnnouncementNotificationJob.new.perform(announcement.id) if announcement
  end
end
