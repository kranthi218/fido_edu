class BroadcastNotificationPollJob < ApplicationJob
  queue_as :notifications

  def perform
    pending = Broadcast.current.pending.first
    BroadcastNotificationJob.new.perform(pending.id) if pending
  end
end
