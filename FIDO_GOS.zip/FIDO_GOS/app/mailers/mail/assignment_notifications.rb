class Mail::AssignmentNotifications < Mail::ApplicationMailer
  def student_assignment_submission_notification(student_assignment)
    @student_assignment = student_assignment
    title               = student_assignment.assignment.title

    mail(to: student_assignment.student.email,
         subject: "#{title} has been received)")
  end

  def grading_notification(student_assignment_grade)
    @student_assignment = student_assignment_grade.student_assignment
    title = student_assignment_grade.student_assignment.assignment.title

    mail(to: student_assignment_grade.student.email,
         subject: "Your #{title} assignment has been graded")
  end
end
