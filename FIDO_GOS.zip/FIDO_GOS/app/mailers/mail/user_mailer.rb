class UserMailer < ActionMailer::Base
  def account_merge_notification(user)
    subject = 'Your EMS account has been updated.'
    recipients = if ENV['RAILS_ENV'] == 'development' || ENV['RAILS_ENV'] == 'staging'
                   default_emails
                 else
                   user.email
                 end

    mail(bcc: recipients, subject: subject)
  end
end
