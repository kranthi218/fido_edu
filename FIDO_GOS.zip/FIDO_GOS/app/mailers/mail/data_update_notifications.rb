class DataUpdateNotifications < ActionMailer::Base
  def student_data_update_notification(user)
    @user = user
    @password_reset_url = new_password_url
    subject = 'Important: Your account has been updated.'
    mail(to: @user.email, subject: subject)
  end
end
