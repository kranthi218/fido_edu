class Mailer < ActionMailer::Base 
end

