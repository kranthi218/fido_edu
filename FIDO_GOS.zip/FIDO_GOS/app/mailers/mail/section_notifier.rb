class SectionNotifier < ActionMailer::Base
  def section_schedule_update_notification(section)
    subject  = "#{section.name} Schedule Changes"
    @section = section

    recipients = if %w[development staging].include?(Rails.env)
                   default_emails
                 else
                   section.mailing_list
                 end

    mail(bcc: recipients, subject: subject)
  end

  def section_update_notification(section)
    @section = section
    subject  = "#{section.name} changes"
    from 'EMS <donotreply@itu.edu>'

    recipients = if %w[development staging].include?(Rails.env)
                   default_emails
                 else
                   section.mailing_list
                 end

    mail(bcc: recipients, subject: recipients)
  end
end
