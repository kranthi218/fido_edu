class PasswordResets < ActionMailer::Base
  def password_reset_instructions(user)
    subject = 'EMS Login Details'
    @user   = user

    recipients = if ENV['RAILS_ENV'] == 'development' || ENV['RAILS_ENV'] == 'staging'
                   default_emails
                 else
                   user.email
                 end

    mail(to: recipients, subject: subject)
    #:password_change_url => edit_password_url(:token => user.perishable_token)
  end
end
