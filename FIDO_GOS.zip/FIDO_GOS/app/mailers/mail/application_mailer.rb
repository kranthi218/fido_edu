class Mail::ApplicationMailer < ActionMailer::Base
  include SendGrid

  default from: 'donotreply@itu.edu'

  def default_emails
    ['emstest@itu.edu', 'qreno@itu.edu', 'zpin@itu.edu', 'jamomathenge@gmail.com', 'vface@itu.edu', 'pgajanur@itu.edu']
  end

  def janzebar_data_import_admin_notifier(janzebar_data_import)
    @recipients = ["jamomathenge@gmail.com", "dkirai@itu.edu", "tevelyn@itu.edu", "jsara@itu.edu"]
    @subject    = "Janzebar Data Import :: Completed at #{janzebar_data_import.completed_at.to_s(:time_year)}"
    @import_url = admin_janzebar_data_import_url(janzebar_data_import)
    mail(to: @recipients, subject: @subject )
  end

end
