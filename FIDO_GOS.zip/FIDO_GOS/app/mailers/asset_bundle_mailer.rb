class AssetBundleMailer < ApplicationMailer
  def notify_user(bundle)
    @user     = bundle.user
    @title    = bundle.bindable.title
    @url      = bundle.bundle.url
    @filesize = bundle.bundle_file_size
    @filename = bundle.bundle_file_name

    mail(to: @user.email,
         subject: format('%s attachments bundle is ready', @title))
  end
end
