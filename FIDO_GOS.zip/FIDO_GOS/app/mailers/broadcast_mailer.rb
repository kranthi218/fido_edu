class BroadcastMailer < ApplicationMailer
  def send_message(broadcast, user)
    @broadcast = broadcast
    @user      = user

    mail(from: "#{broadcast.user.name} <donotreply@itu.edu>",
         to:      user.decorate.mail_to,
         subject: broadcast.title)
  end
end
