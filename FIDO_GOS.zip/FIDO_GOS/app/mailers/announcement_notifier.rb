class AnnouncementNotifier < ActionMailer::Base
  add_template_helper(MailerHelper)

  def send_announcement(announcement, user)
    @announcement = announcement
    creator = User.find @announcement.creator_id
    course_no = @announcement.announcable.course.course_no
    mail(
      from:    "#{creator.name} <donotreply@itu.edu>",
      to:      user.decorate.mail_to,
      subject: "#{course_no} | #{@announcement.title}"
    )
  end
end
