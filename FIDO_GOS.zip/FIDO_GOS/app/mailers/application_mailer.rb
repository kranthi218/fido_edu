class ApplicationMailer < ActionMailer::Base
  add_template_helper(MailerHelper)

  default from: 'donotreply@itu.edu'
  layout 'mailer'
end
