class UserDecorator < Draper::Decorator
  delegate_all
  decorates :user
  include Draper::LazyHelpers

  def access_allowed?(group, args = nil)
    group = group.to_s if group.is_a?(Symbol)
    case group
    when 'report'
      ReportPolicy.new(current_user).access?
    when 'admin'
      current_user.access.admin_access_allowed
    when 'support'
      current_user.is_admin?
    when 'faculty'
      FacultyWrapper.new(current_user).sections.any?
    when 'student'
      StudentWrapper.new(current_user).sections.any?
    when 'department'
      DepartmentPolicy.new(current_user, nil).access?
    when 'staff'
      current_user.access.staff_access_allowed?
    else
      false
    end
  end

  #-------------------------------------------------------------
  # This method is used to build the sidebar menu on the admin
  # dashboard. At this time it just builds links to the index pages.
  def admin_nav_links
    links = []

    current_user.access.admin_permissions.each do |permission|
      case permission
      when 'access_permission'
        links.push ['User Permissions', admin_permissions_path]
      when 'access_report'
        links.push ['Reports', reports_dashboard_path]
      when 'access_announcement'
        links.push ['Announcements', announcements_path]
      end
    end

    links.uniq
  end


  def generate_ta_assignment_path(permission, args=nil)
    link_to 'Add/Update Assignment',  new_assignment_path(args)
  end

  def generate_course_resource_path(permission, args=nil)
    new_course_resource_path(args)
  end

  def generate_permission_path(permission, args=nil)
    if permission.update_create?
      link_to 'Assign/Unassign', admin_permissions_path(args)
    else
      link_to 'View',  admin_permissions_path(args)
    end
  end

  def generate_section_path(permission, args=nil)
    if permission.update_create?
      link_to 'Update',  edit_section_path(args)
    else
      link_to 'View',  section_path(args)
    end
  end

  def generate_section_student_path(permission, args=nil)
    if permission.update_create?
      link_to 'Update',  edit_section_student_path(args)
    else
      link_to 'View',  section_student_path(args)
    end
  end

  def generate_report_path(permission, args=nil)
      link_to 'Update',  report_reports_path(args)
  end

  def generate_assignment_path(permission, args=nil)
    link_to 'Update',  edit_assignment_path(args)
  end

  def generate_announcement_path(permission, args=nil)
    link_to 'Update',  new_announcement_path(args)
  end

  def generate_gradebook_path(activity, role)
    if role == :student
      gradebook_student_section_path(activity.assignment.section)
    elsif role == :faculty
       faculty_section_gradebooks_path(activity.assignment.section_id)
    else
      authorization_exception_show_path
    end
  end

  def generate_assignment_path(activity, role)
    if role == :student
      student_assignment_path(activity.assignment)
    elsif role == :faculty
       faculty_section_gradebooks_path(activity.assignment.section_id)
    else
      authorization_exception_show_path
    end
  end

  def coursework_submitted_message(submission, role, kind)
    if role == :student
      'You turned in '
    else
       "#{submission.student.full_name} submitted #{kind} "
    end
  end

  def coursework_updated_message(submission, role)
    if role == :student
      'You updated '
    else
       "#{submission.student.full_name} updated submission "
    end
  end

  def parse_params(parameters, key)
    parameters.has_key?(key) ? parameters[key] : ''
  end

  def mail_to
    "#{full_name} <#{email}>"
  end
end
