class PloDecorator < Draper::Decorator
  delegate_all

  def link_title
    display_name
  end

  def link_details
    status
  end

  def display_name
    description
  end

  def status
    self.active? ? 'Active' : 'Retired'
  end

  def plo_as_table_row
    tooltip = "<span href='#' title='' data-toggle='popover' data-content=\"#{description}\" data-html=\"#{true}\">
      #{description.slice(0..60)}...</span>"
    "#{tooltip}".html_safe
  end
end
