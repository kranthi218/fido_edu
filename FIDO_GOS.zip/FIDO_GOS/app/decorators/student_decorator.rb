class StudentDecorator < Draper::Decorator
  delegate_all
  decorates :student

  def points_earned(section)
    if section.points_grading?
      points = coursework_points(section.id, object.id)
    elsif section.weighted_grading?
      points = grading_policy_points(section, object.id)
    else
      fail "Attempted to calculate student score for class that's not set-up"
    end

    points
  end

  # @todo This method makes too many calls to the database. Refactor.
  def grading_policy_points(section, object_id)
    points = []

    section.grading_policies.each do |g|
      p = StudentAssignmentGrade.student_score_by_grading_policy(object_id, g.id).sum(:score) || 0
      p += QuizScore.student_score_by_grading_policy(object.id, g.id).sum(:score) || 0
      p += DiscussionParticipant.student_score_by_grading_policy(object.id, g.id).sum(:score) || 0
      points.push(p)
    end

    points
  end

  def coursework_points(section_id, object_id)
    points = []

    [StudentAssignmentGrade, QuizScore, DiscussionParticipant].each do |coursework|
      p = coursework.scores_for_student_for_section(section_id, object_id)
        .sum(:score) || 0
      points.push(p)
    end

    points
  end
end
