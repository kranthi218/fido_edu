class PermissionDecorator < Draper::Decorator
  delegate_all

  def term?
    object.term_id?
  end

  def department?
    object.department_id?
  end

  def section?
    object.section_id?
  end

  def description
    if object.group_type.is_a?(Symbol)
      key = object.group_type
    else
      key = object.group_type.downcase.to_sym
    end

    Access::DESCRIPTIONS[key]
  end

  def type_title
    if object.group_type.is_a?(Symbol)
      key = object.group_type
    else
      key = object.group_type.downcase.to_sym
    end

    Access::TITLES[key]
  end

  def view_label
    format('View %s', type_title)
  end

  def update_create_label
    format('Edit %s', type_title)
  end

  def trash_label
    format('Delete %s', type_title)
  end
end
