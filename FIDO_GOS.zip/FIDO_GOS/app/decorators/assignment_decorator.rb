class AssignmentDecorator < Draper::Decorator
  delegate_all

  def breadcrumb_title
    "Assignment: #{object.title}"
  end

  def student_assignments
    object.student_assignments.sort_by do |sa| 
      sa.student.full_name.downcase
    end
  end
end
