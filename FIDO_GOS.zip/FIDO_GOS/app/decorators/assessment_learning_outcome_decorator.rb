class AssessmentLearningOutcomeDecorator < Draper::Decorator
  delegate_all

  # Define presentation-specific methods here. Helpers are accessed through
  # `helpers` (aka `h`). You can override attributes, for example:
  #
  #   def created_at
  #     helpers.content_tag :span, class: 'time' do
  #       object.created_at.strftime("%a %m/%d/%y")
  #     end
  #   end

  def outcome
    score ? Rubric::RUBRIC_SCORES[score-1] : 'No Assessment'
  end

  def title
    course_learning_outcome.try(:description)
  end

end
