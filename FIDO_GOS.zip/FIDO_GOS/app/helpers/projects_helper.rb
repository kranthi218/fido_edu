module ProjectsHelper
  def display_project_left_sidebar
    content_for :sidebar do
      render :partial => "projects/left_sidebar"
    end  
  end
end
