module SectionHelper
  def section_navigation_tab(link_text, link_to_options)
    link = link_to(link_text, link_to_options)

    if current_page?(link_to_options)
      content_tag(:li, class: 'active') { link }
    else
      content_tag(:li) { link }
    end
  end

  def setup_status_display(section)
    if section.setup_completed?
      "Complete <i class='icon icon-thumbs-up text-success'></i>".html_safe
    else
      "Incomplete <i class='icon icon-thumbs-down text-danger'></i>".html_safe
    end
  end

  def section_schedule_date(schedule)
    return format_date(schedule.start_date) if schedule.isSingleDaySchedule?
    format_date_range(schedule.start_date , schedule.end_date)
  end
end
