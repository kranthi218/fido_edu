# Helper methods for generating HTML5 video tags for use with video.js
# @see https://github.com/videojs/video.js/blob/v4.3.0/docs/guides/setup.md video.js setup
module VideoJsHelper

  DEFAULT_OPTIONS = {
    controls: true,
    preload: 'metadata',
    'data-setup' => { techOrder: %w(html5 flash) }.to_json,
    class: 'video-js vjs-default-skin vjs-big-play-centered',
    width: 560,
    height: 264
  }

  # @overload video(sources, html_options)
  #   Generate a HTML5 video tag with the provided video sources
  #   @param [Array<Paperclip::Attachment>] An splat of paperclip attachments to use as video sources
  #   @param [Hash] a hash of HTML options/attributes to be set on the generated video tag
  #
  # @example Generating a video tag with two sources
  #   video(video_webm_version, video_mp4_version) # =>
  #   # <video controls="controls" preload="metadata">
  #   #   <source src="/video.webm?1385576864" type="audio/webm">
  #   #   <source src="/oceans.mp4?1385576864" type="video/mp4">
  #   # </video>
  #
  # @example Generating a video tag with additional attributes
  #   video(video_file, class: "hi-def", id: "video-1") # =>
  #   # <video controls="controls" preload="metadata" class="hi-def" id="video-1">
  #   #   <source src="/oceans.mp4?1385576864" type="video/mp4">
  #   # </video>

  def video(*sources)
    html_options = sources.extract_options!

    # Default HTML options
    html_options = DEFAULT_OPTIONS.merge(html_options)

    video_source_tags = sources.map { |source|
      tag('source', src: source.url, type: source.content_type)
    }.join.html_safe

    content_tag(:video, html_options) { video_source_tags }
  end

  # Insert player for remote url file
  def video_remote(url, options = {})
    html_options = DEFAULT_OPTIONS.merge(options)
    content_tag(:video, html_options) do
      tag('source', src: url)
    end
  end

  # Parse youtube and vimeo video links to get insertable iframe
  def video_embed(url)
    if match = url.match(/(?:http:\/\/)?(?:www\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(.+)/)
      content_tag('iframe',
          src: "https://www.youtube.com/embed/#{match[1]}",
          frameborder: '0',
          width:  DEFAULT_OPTIONS[:width],
          height: DEFAULT_OPTIONS[:height],
          allowfullscreen: true) do
      end
    elsif match = url.match(/(?:http:\/\/)?(?:www\.)?(?:vimeo\.com)\/(.+)/)
      content_tag('iframe',
          src: "https://player.vimeo.com/video/#{match[1]}",
          frameborder: '0',
          width:  DEFAULT_OPTIONS[:width],
          height: DEFAULT_OPTIONS[:height],
          webkitallowfullscreen: true,
          mozallowfullscreen: true,
          allowfullscreen: true) do
      end
    else
      content_tag('a', href: url, target: '_blank') do
        'External link'
      end
    end.html_safe
  end

end
