module FacultyWidgetHelper

  def render_helper(type, data)
      case type
      when "course_modules"
        "<li>#{data.name}</li>"
      when "assignment"
        link = link_to("Edit/Delete", edit_faculty_section_assignment_path(data.section, data))
        "<li>#{data.group.name} #{data.group.title} </li>"
      when "books"
        "<li>#{data.title} #{data.author} #{data.publisher}</li>"
      when "course_resources"
        "<li>#{data.title}</li>"
      when "lessons"
        "<li>#{data.title} #{data.description}</li>"
      when "rubrics"
        "<li>#{data.title} #{data.active ? "active" : "draft"}</li>"
      end
    end

  end
