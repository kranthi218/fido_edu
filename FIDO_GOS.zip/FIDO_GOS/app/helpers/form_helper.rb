module FormHelper
  def options_from_collection_for_select_with_include_blank(collection, value_method, text_method, selected = nil, include_blank = true)
    options = options_from_collection_for_select(collection, value_method, text_method, selected)
    if include_blank
      options = "<option value=\"\">#{include_blank if include_blank.kind_of?(String)}</option>\n" + options
    end
    options
  end
end
