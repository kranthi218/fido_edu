module AssignmentsHelper
  
  def assignment_scores(assignment)
    scores = []
    score = assignment.points.to_i > 0 ? assignment.points.to_i : 10
    score_array = (0..score).to_a
    score_array.each do |score|
      scores << score.to_f/2
    end
    return scores.insert(0, '')
  end

  def score_errors(object_ids, object_id)
    object_ids.to_s.split(",").include?(object_id.to_s) ? "text-field-errors" : nil
  end
  
end
