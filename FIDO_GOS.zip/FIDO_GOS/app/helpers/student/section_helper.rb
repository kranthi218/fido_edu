module Student::SectionHelper

  def section_navigation_tab(link_text, link_to_options)
    link = link_to(link_text, link_to_options)

    if current_page?(link_to_options)
      content_tag(:li, class: 'active') { link }
    else
      content_tag(:li) { link }
    end
  end

end
