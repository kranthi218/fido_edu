module Student::CourseListHelper

  # The CourseData class is a simple object wrapper used
  # for conviencince when rendering individual course information
  # within the CourseListCell#show view template.
  class CourseData
    attr_reader :section

    attr_reader :credits
    attr_reader :grade
    attr_reader :name
    attr_reader :course_number
    attr_reader :room_numbers

    def initialize(section_student)
      @section       = section_student.section
      @student       = section_student.student
      @credits       = section.credits
      @grade         = student_grade(section_student)
      @name          = section.course.name
      @course_number = section.course.course_no
      @room_numbers  = collect_room_numbers(section)
    end

    def student_grade(section_student)
      return 'N/A' unless section_student.graded?
      section_student.grade_name
    end

    def collect_room_numbers(section)
      section.schedules.map(&:name).join(', ')
    end
  end

  def course_data
    ss = collect_section_students
    ss = ss.group_by { |sect_st| sect_st.term.name }

    populate_course_data(ss)
  end

  def terms
    @terms = (terms_by_start_date - [@term]).reverse
  end


  def collect_section_students
    SectionStudent.visible
                  .includes(section: [:term, schedules: :lecture_hall])
                  .where(student_id: @student.id, term_id: @term.id)
                  .order('sections.created_at desc')
  end

  def terms_by_start_date
    Term.joins(sections: :section_students)
        .where(section_students: { student_id: @student.id })
        .order(:starts_at)
        .active
        .distinct
  end

  def populate_course_data(grouped_sections)
    @course_data = {}

    grouped_sections.each do |term_name, sect_sts|
      @course_data[term_name] ||= []

      sect_sts.each do |sect_st|
        @course_data[term_name] << CourseData.new(sect_st)
      end
    end
  end
end
