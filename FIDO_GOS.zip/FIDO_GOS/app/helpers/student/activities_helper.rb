module Student::ActivitiesHelper
	ACTIVITY_ICONS = {
    'assignment' => {
      'update' =>  'pencil',
      'create' =>  'star'
    },
    'student_assignment_grade' => {
      'create' => 'mail-reply',
      'update' => 'fire'
    },
    'student_assignment' => {
      'create' => 'upload',
      'update' => 'fire'
    }
  }

  def activity_icons(activity)
    key = activity.key.split('.')

    if ACTIVITY_ICONS[key[0]].blank? || ACTIVITY_ICONS[key[0]][key[1]].blank?
      suffix = 'exclamation-circle'
    else ACTIVITY_ICONS[key[0]][key[1]].blank?
      suffix = ACTIVITY_ICONS[key[0]][key[1]]
    end

    format('icon-%s', suffix)
  end
end
