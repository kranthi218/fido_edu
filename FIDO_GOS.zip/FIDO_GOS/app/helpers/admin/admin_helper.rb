module Admin::AdminHelper

  # We disable options if they are not relevant to a particular permission
  def constraint_available(controls, opt)
    return false unless controls[:available_constraints]
    controls[:available_constraints].include?(opt)
  end

  def generate_label(controls, field)
    if controls[field] && required(controls[field])
      symbol_to_string(field) +  " is required."
    elsif controls[field]
      symbol_to_string(field) + " is optional."
    else
      symbol_to_string(field) +  " is not used."
    end
  end

  def symbol_to_string(strn)
    strn.id2name.gsub(/_id/, '').capitalize
  end

  def required(obj)
    obj == :required
  end

end
