module Reports
  module SectionSurveysHelper
    def calculate_percentage(status_count, enrolled_students)
      percentage = (status_count.fdiv(enrolled_students) * 100).round(1)
      format('%s (%s%%)', status_count, percentage)
    end

    def print_xls_format(results, options)
      html = ''
      options.values.each do |key|
        value = (results[key].present? ? results[key].to_s : '')
        html += "<Cell><Data ss:Type='String'>" + value + '</Data></Cell>'
      end
      html.html_safe
    end
  end
end
