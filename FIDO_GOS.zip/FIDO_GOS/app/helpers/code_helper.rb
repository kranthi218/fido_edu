# A helper for generating HTML for code blocks compatible with Twitter Bootstrap v3 and HighlightJS
module CodeHelper

  # Example output:
  #   code_block do
  #     puts 'This is the code'
  #     puts 'Wat' if 1 > 0 && 1 < 0
  #   # => "<pre>puts 'This is the code'&#x000A;'Wat' if 1 &gt 0 &amp;&amp; 1 &lt; 0</pre>"
  def code_block(options = {}, &block)
    html_options = {}.merge(options)
    text = capture(&block)
    html = escape_once(text)
    content_tag(:pre, text, html_options)
  end

end
