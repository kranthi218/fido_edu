module Manage::SectionHelper

  def admin_section_navigation_menu(section)
    render partial: "manage/shared/section_tabs", locals: {section: section}
  end

  def admin_section_navigation_tabs(link_text, link_to_options)
    link = link_to(link_text, link_to_options)

    if current_page?(link_to_options)
      content_tag(:li, class: 'active') { link }
    else
      content_tag(:li) { link }
    end
  end

end
