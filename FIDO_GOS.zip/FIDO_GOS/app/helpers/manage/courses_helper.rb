module Manage::CoursesHelper
end
