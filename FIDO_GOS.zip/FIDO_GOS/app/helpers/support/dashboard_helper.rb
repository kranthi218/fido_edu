module Support::DashboardHelper
  # We mark as active as long as it has the same controller as the current page
  def support_navigation_tab(link_text, link_to_options)
    link = link_to(link_text, link_to_options)
    numbers_in_path = request.path.partition(/\/\d/)[0] == link_to_options
    path_to_new_action = request.path == format('%s/new', link_to_options)

    if numbers_in_path || path_to_new_action
      content_tag(:li, class: 'active') { link }
    else
      content_tag(:li) { link }
    end
  end
end
