module Support
  # set of helper methods related to `Page` model
  module PagesHelper
    def page_breadcrumbs(main_page)
      breadcrumbs = [home_link] + ancestor_links(main_page)
      breadcrumbs << page_link(main_page, true)
      content_tag(:ol, class: 'breadcrumb') do
        breadcrumbs.each { |breadcrumb| concat breadcrumb }
      end
    end

    def ancestor_links(main_page)
      main_page.ancestors.map do |page|
        page_link page
      end
    end

    def page_link(page, active = false)
      css_classes = 'breadcrumb-item'
      css_classes += ' active' if active
      content_tag(:li, class: css_classes) do
        link_to(h(page.title), support_page_path(page))
      end
    end

    def home_link
      content_tag(:li, class: 'breadcrumb-item') do
        link_to('Home', support_pages_path)
      end
    end
  end
end
