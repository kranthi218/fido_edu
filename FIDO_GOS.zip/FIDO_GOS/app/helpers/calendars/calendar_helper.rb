module Calendars::CalendarHelper
  def event_class(item)
    diff = item.due_at.to_i - Time.zone.now.to_i
    'warning' if diff >= 1.day.to_i && diff <= 2.days.to_i
  end
end
