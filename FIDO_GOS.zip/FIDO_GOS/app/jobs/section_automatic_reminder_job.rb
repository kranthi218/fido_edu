# This job checks for coursterm ending period, quizz, assignment,
# discussion due date and send reminder to students
# based on reminder period set by faculty.
class SectionAutomaticReminderJob < ApplicationJob
  queue_as :reminder

  def perform
    sections = Section.joins(:reminder)
                      .where(reminders: { reminder_enabled: true })

    sections.each do |section|
      reminder_period = section.reminder_period
      quizzes = section.quizzes.where("DATE_SUB(DATE(ends_at), INTERVAL #{reminder_period} DAY) = ? ", Date.today)
      assignments = section.assignments.where("DATE_SUB(DATE(ends_at), INTERVAL #{reminder_period} DAY) = ? ", Date.today)
      discussions = section.discussions.where("DATE_SUB(DATE(ends_at), INTERVAL #{reminder_period} DAY) = ? ", Date.today)
      creater = section.decorate.display_faculty_user

      if quizzes.any?
        quizzes.find_each do |quiz|
          @announcement =
            Announcement.find_or_create_by(announcable_type: 'Quiz', announcable_id: quiz.id) do |announcement|
              announcement.title = quiz.title
              announcement.content = quiz.description
              announcement.published_at = quiz.ends_at - reminder_period.days
              announcement.creator_id = creater.id
            end
        end
      end

      if assignments.any?
        assignments.find_each do |assignment|
          @announcement = Announcement.find_or_create_by(announcable_type: 'Assignment', announcable_id: assignment.id) do |announcement|
            announcement.title = assignment.title
            announcement.content = assignment.description
            announcement.published_at = assignment.ends_at - reminder_period.days
            announcement.creator_id = creater.id
          end
        end
      end

      if discussions.any?
        discussions.find_each do |discussion|
          @announcement = Announcement.find_or_create_by(announcable_type: 'Discussion', announcable_id: discussion.id) do |announcement|
            announcement.title = discussion.title
            announcement.content = discussion.content
            announcement.published_at = discussion.ends_at - reminder_period.days
            announcement.creator_id = creater.id
          end
        end
      end

      if section.reminder.reminder_date_final_grading_period?
        Mail::SectionReminderNotifications.send_final_grading_period_reminder(section, creater.email).deliver
      end

      next unless section.section_reminder_due?
      recipients = section.mailing_list
      recipients.each do |user|
        Mail::SectionReminderNotifications.send_section_ending_reminder(section, user.email).deliver
      end
    end
  end
end
