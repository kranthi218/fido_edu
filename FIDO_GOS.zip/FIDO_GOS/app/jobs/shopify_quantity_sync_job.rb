# frozen_string_literal: true

require 'shopify_api'
class ShopifyQuantitySyncJob < ApplicationJob
  queue_as :sync

  def perform
    shop_url = "https://#{ENV['SHOPIFY_API_KEY']}:#{ENV['SHOPIFY_PASSWORD']}@" +
               + "#{ENV['SHOPIFY_SHOP_NAME']}.myshopify.com/admin"

    ShopifyAPI::Base.site = shop_url
    count = ShopifyAPI::Product.count
    page = 1
    # it is needed as it default returns only 50 products
    while count.positive?
      ShopifyAPI::Product.find(:all, params: { page: page }).each do |product|
        product.variants.each do |variant|
          ex_section = Ex::Section.find_by(shopify_product_id: product.id)

          next unless ex_section # @TODO notify

          variant.old_inventory_quantity = variant.inventory_quantity
          variant.inventory_quantity = ex_section.available_enrollments
          variant.save
        end
      end
      count -= 50
      page += 1
    end
  end
end
