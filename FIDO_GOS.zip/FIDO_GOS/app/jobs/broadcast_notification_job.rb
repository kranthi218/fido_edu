# There are two kinds of Broadcasts:
# 1. _Global_ are created by support user and should not have department_id set.
#    They have to be delivered to all students and faculty users of a current
#    Term and also all active staff users according to permissions table.
#
# 2. _Targeted_ are created by HOD they should have department_id set and might
#    be targeted to students, faculty or both.
#
class BroadcastNotificationJob < ApplicationJob
  queue_as :notifications

  def perform(broadcast_id)
    @broadcast = Broadcast.find(broadcast_id)
    department = @broadcast.department

    @broadcast.started!

    notify_group faculty_mailing_list(department) if @broadcast.visible_to_faculty

    notify_group students_mailing_list(department) if @broadcast.visible_to_students

    # Only send globals to staff
    notify_group(staff_mailing_list) unless department

    @broadcast.delivered!
  rescue StandardError
    @broadcast&.errored!
  end

  private

  # @param group [ActiveRecord::Relation] Users query
  def notify_group(group)
    group.find_each do |user|
      BroadcastMailer.send_message(@broadcast, user).deliver_later
    end
  end

  # @param department [Department] target Department
  # @param term [Term] target Term (optional)
  # @return [ActiveRecord::Relation] Users query
  def sections_condition(department, term = Term.current)
    condition = { term_id: term.id }
    condition[:department_id] = department.id if department
    condition
  end

  # @param department [Department] target Department
  # @return [ActiveRecord::Relation] Users query
  def faculty_mailing_list(department = nil)
    User.joins(faculty:  { section_faculty: :section })
        .where(sections: sections_condition(department))
        .distinct
  end

  # @param department [Department] target Department
  # @return [ActiveRecord::Relation] Users query
  def students_mailing_list(department = nil)
    User.joins(student:  { section_students: :section })
        .where(sections: sections_condition(department))
        .distinct
  end

  # @return [ActiveRecord::Relation] Users query
  def staff_mailing_list
    User.joins(:permissions)
        .where(permissions: { disabled: false })
        .distinct
  end
end
