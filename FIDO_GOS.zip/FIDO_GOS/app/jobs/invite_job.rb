# This worker used to deliver invitations to newbie students.
#
class InviteJob < ApplicationJob
  queue_as :invitations

  def perform(term_id)
    User
      .joins(student: %i[term_enrollments section_students])
      .where(term_enrollments: { term_id: term_id })
      .merge(SectionStudent.active_enrollments)
      .new_users
      .first_invite_users
      .uniq
      .each { |user| log_invite(user) }
      .each(&:invite!)
  end

  private

  def log_invite(user)
    logger.info(
      format(
        'Sending invitation to user: { id: %d, full_name: %s }',
        user.id,
        user.full_name
      )
    )
  end
end
