class AssetBundleCleanupJob < ApplicationJob
  queue_as :default

  def perform
    AssetBundle.where('created_at < ?', 2.weeks.ago).destroy_all

    true
  end
end
