# This worker creates survey's and associated question and options
# for all the sections belongs to current term.
class SurveyDataSetupJob < ApplicationJob
  queue_as :default

  def perform(section)
    term      = section.term
    term_name = term.display_name
    survey_name = format(
      '%s %s %s',
      term_name,
      section.course_and_section_no,
      section.course.name
    )
    survey = section.surveys.find_or_create_by(name: survey_name)
    question_and_options['questions'].each do |description|
      if description == 'Comments'
        text_answer_question(description, survey)
      else
        multiple_choice_question(description, survey)
      end
    end
  end

  private

  def question_and_options
    @question_and_options ||=
      YAML.load_file("#{Rails.root}/config/survey_data_setup.yml")
  end

  def text_answer_question(description, survey)
    survey.questions.find_or_create_by(
      category: 'Survey',
      question_type: 'text_answer',
      description: description,
      questionable: survey
    )
  end

  def multiple_choice_question(description, survey)
    question = survey.questions.find_or_initialize_by(
      category: 'Survey',
      question_type: 'multiple_choice',
      description: description,
      questionable: survey
    )

    question_and_options['options'].keys.each do |option|
      question.question_answers.find_or_initialize_by(choice: option)
    end

    question.save
  end
end
