class SectionFinalizeJob < JanzebarGradeJob
  queue_as :sync

  # @param section [Section] section to finalize
  def perform(section)
    grade_sync = GradeSync.new { |syncer| syncer.logger = grade_logger }

    grade_sync.sync_section!(section)
  end
end
