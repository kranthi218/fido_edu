# This worker is used to actualize coursewrok activities visibility
# related to CourseModule.
#
# Used after CourseModule created or updated.
#
# Following factor affects coursework visibility:
#   1. It's own visible flag (except lessons)
#   2. CourseModule visible flag
class CourseModuleVisibilityJob < ApplicationJob
  queue_as :visibility

  def perform(course_module_id)
    course_module = CourseModule.find course_module_id
    raise 'CourseModule is not exist' unless course_module

    course_module.assignments.find_each do |assignment|
      Activity.update_visible_for assignment, assignment.visible_to_students?
    end

    course_module.discussions.find_each do |discussion|
      Activity.update_visible_for discussion, discussion.visible_to_students?
    end

    course_module.lessons.find_each do |lesson|
      Activity.update_visible_for lesson, lesson.visible_to_students?
    end

    course_module.quizzes.find_each do |quiz|
      Activity.update_visible_for quiz, quiz.visible_to_students?
    end
  end
end
