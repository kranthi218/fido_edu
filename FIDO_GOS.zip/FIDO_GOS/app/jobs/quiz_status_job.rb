class QuizStatusJob < ApplicationJob
  queue_as :default

  def perform
    QuizScore.where(status: 'started')
             .where('UTC_TIMESTAMP() > ends_at')
             .find_each do |quiz_score|
               quiz_score.update_attributes(
                 close_at: Time.current,
                 status: 'abandoned',
                 graded: quiz_score.all_answers_graded?
               )
             end
  end
end
