class CourseworkVisibilityJob < ApplicationJob
  queue_as :visibility

  def perform
    term = Term.current

    CourseworkExtension::ALLOWED_CLASSES.values.each do |klass|
      klass
        .joins(:section)
        .where(sections: { term_id: term })
        .where(active: true, visible: false)
        .where("#{klass.table_name}.starts_at < ?", Time.current)
        .update_all(visible: true)
    end

    true
  end
end
