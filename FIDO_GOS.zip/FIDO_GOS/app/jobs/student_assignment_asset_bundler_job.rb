require 'zip'

class StudentAssignmentAssetBundlerJob < ActiveJob::Base
  queue_as :default
  sidekiq_options retry: false, backtrace: true

  def perform(assignment_id, user_id)
    assignment = Assignment.find(assignment_id)
    user       = User.find(user_id)

    reaper = StudentAssignmentAssetBundler.new(assignment)

    reaper.archive! do |archive|
      AssetBundle.create(bindable: assignment,
                         bundle:   archive.bundle,
                         user:     user)
    end
  end
end
