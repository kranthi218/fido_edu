# This worker is responsible for importing new data from Janzebar/Ex
#
# Overview of how the sync works:
#   1. Check when the last time we ran this job was via
#      the JanzebarBatchNumber model.
#   2. Check the Ex::EmsTransaction table for new transactions by collecting
#      all transactions with batch numbers greater than the last batch number
#      we know of
#   3. Split up Ex::EmsTransaction results by transaction type
#   4. Process each type of transaction
#        A. For each course transaction, look up the given course's information
#           from the Ex::EmsSection table. For each course, create or update a
#           corresponding Course record within this application.
#        B. For each person transaction, look up the corresponding Ex::Name
#           record. Using that name record, create or update a User model and
#           create or update relevant Ex::Name faculty and student associations
#           with the corresponding EMS User faculty and student associations
class JanzebarSynchronizationJob < ApplicationJob
  queue_as :sync

  attr_accessor :report_errors

  TERM_SYNC_START = 6.weeks
  STUDENT_SYNC_START = 5.weeks

  # @param terms [Array<Term>]
  # term_ids
  def perform(terms = nil)
    terms ||= Term.where('ends_at > ?', Time.zone.now)
                  .where('starts_at < ?', Time.zone.now + TERM_SYNC_START)

    sync_departments!

    terms.each do |term|
      Rails.logger.info("Syncing term: #{term.id}")

      ex_sections = Ex::Section.active.for_term(term)
      cancelled   = Ex::Section.cancelled.for_term(term)

      if term.starts_at - STUDENT_SYNC_START > Time.zone.now
        sync_without_sections!(term, ex_sections, cancelled)
      else
        sync_all!(term, ex_sections, cancelled)
      end
    end

    nil
  end

  private

  def sync_departments!
    ex_departments = Ex::Department.all

    dpt = DepartmentSync.new
    dpt.sync!(ex_departments)
  end

  def sync_without_sections!(term, ex_sections, cancelled)
    cs = CourseSync.new { |syncer| syncer.logger = Rails.logger }
    cs.sync!(ex_sections)

    us = UserSync.new { |syncer| syncer.logger = Rails.logger }
    us.student_sync!
    us.faculty_sync!(ex_sections)
    us.faculty_student_sync!(term)
    us.report_errors if us.errors?

    ss = SectionSync.new { |syncer| syncer.logger = Rails.logger }
    ss.sync!(term, ex_sections)
    ss.unsync!(term, cancelled)

    schs = SectionScheduleSync.new { |syncer| syncer.logger = Rails.logger }
    schs.sync!(term)
  end

  def sync_all!(term, ex_sections, cancelled)
    sync_without_sections!(term, ex_sections, cancelled)

    scs = StudentSectionSync.new { |syncer| syncer.logger = Rails.logger }
    scs.sync!(ex_sections)
  end
end
