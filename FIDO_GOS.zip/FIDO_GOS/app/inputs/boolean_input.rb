# Inherit and tweak SimpleForm::Inputs::BooleanInput
# so we can generate Bootstrap 3 style inline input labels
class BooleanInput < SimpleForm::Inputs::BooleanInput

  def input(wrapper_options = nil)
    merged_input_options = merge_wrapper_options(input_html_options, wrapper_options)
    if nested_boolean_style?
      template.content_tag(:div, class: 'checkbox') {
        build_check_box_without_hidden_field(merged_input_options) + inline_label
      }

    else
      build_check_box
    end
  end

  def label_input(wrapper_options)
    return input if options[:label] == false

    if nested_boolean_style?
      html  = build_hidden_field_for_checkbox
      html += @builder.label(label_target, label_html_options) {
        build_check_box_without_hidden_field(label_html_options) + label_text
      }

    else
      html = input + label
    end

    template.content_tag(:div, class: 'checkbox') { html }
  end

end
