require 'course_code'

# This class encapsulates the logic reqiured to import student enrollments from
# Janzebar/Ex into the EMS
class StudentSectionSync
  CREATED_MSG   = 'Created %s students from [%s]'.freeze
  UPDATED_MSG   = 'Updated %s students from [%s]'.freeze

  # Raised whenever we have an unexpected error that prevented a particular
  # enrollment in Ex from being associated with a user in the EMS
  class EnrollmentError < StandardError
    def message
      @message ||= <<-MSG.squish
        An error occurred while importing an
        Ex::StudentCourseHistory as a SectionStudent
      MSG
    end
  end

  # Raised when we find more than one matching user for a given
  # Ex::StudentCourseHistory
  class AmbiguousUserError < StandardError
    def message
      @message ||= <<-MSG.squish
        Unable to determine user when attempting to import an
        Ex::StudentCourseHistory as a SectionStudent
      MSG
    end
  end

  attr_writer :logger

  def initialize
    @parser = CourseCodeParser.new
    yield(self) if block_given?
  end

  # @param ex_sections [Array<Ex::Section>, ActiveRecord::Relation]
  #   A collection of Ex::Section records which we are to find and import
  #   enrollments for.
  def sync!(ex_sections)
    ex_sections.each do |ex_section|
      cc = @parser.parse ex_section.crs_cde.strip

      # Select the section with a matching section number
      sect = cc.sections(ex_section.ems_term.id)
               .where(section: cc.section).first

      resolve_enrollments!(sect, ex_section)
    end

    nil
  end

  private

  def logger
    @logger ||= Logger.new(STDOUT)
  end

  # Find matching user by StudentCourseHistory.
  # Report error if user is ambigious or rmpty.
  # @param sch [Ex::StudentCourseHistory]
  # @param section [Section] context EMS section
  # @return [User] matching EMS User
  def find_mathing_user(sch, section)
    eq_janzebar_id    = User.arel_table[:janzebar_id].eq(sch.id_num)
    eq_student_number = Student.arel_table[:student_number].eq(sch.id_num)

    # Don't just go with the first user found; report duplicates
    # and don't do anything until the duplicates are resolved
    users = User.joins(:student).where(eq_janzebar_id.or(eq_student_number))

    return users.first if users.count == 1

    if users.count > 1
      report_enrollment_error(AmbiguousUserError.new, section, sch)

    elsif users.empty?
      report_enrollment_error(EnrollmentError.new, section, sch)
    end

    nil
  end

  # Create new section student records for student course history records
  # from Ex that do not map to any section students within the EMS
  # @param section [Section] target EMS section
  # @param ex_section [Ex::Section] Ex Section
  def resolve_enrollments!(section, ex_section)
    created = []
    updated = []

    ex_section.ex_student_course_histories
              .group_by(&:id_num).each do |id_num, schs|

      # Ex may have multiple records for one student, we need the most recent.
      # Sort will call .to_key for each object. StudentCourseHistory employs
      # composite keys so .to_key should return array including stud_seq_num
      # field which will impact the results.
      sch = schs.sort.last

      sect_sts = section.section_students.by_student_numbers(id_num)

      # ETPO-988 and RO started using the waitlist feature in EX,
      # so students with that status are not actually enrolled
      # courtesy peter, so we should avoid any of W  or any invalid course_code
      # except mentioned in  Ex::StudentCourseHistory::VALID_TRANSACTION_STS

      next unless Ex::StudentCourseHistory::
         VALID_TRANSACTION_STS.include?(sch.transaction_sts&.upcase)

      next unless (user = find_mathing_user(sch, section))

      # No-op if student is already enrolled within this class
      if sect_sts.empty?
        created << enroll!(user, section, sch)
      else
        updated << update_section_student(sch, sect_sts.take)
      end
    end

    logger.info format(CREATED_MSG, created.size, section.course_and_section_no)
    logger.info format(UPDATED_MSG, updated.size, section.course_and_section_no)

    nil
  end

  # Notify Airbrake of problems when we fail to create an enrollment for a
  # section using the provided section and student_course_histories
  #
  # @param error [StandardError] an instance of any kind of StandardError,
  #   used to generate useful error messages when reporting to Airbrake
  # @param section [Section] the section for which we were unable to
  #   import an enrollment from Ex
  # @param sch [Ex::StudentCourseHistory] the Ex enrollment that could not be
  #   imported
  def report_enrollment_error(error, section, sch)
    sch_attrs = sch.attributes.slice('yr_cde', 'trm_cde', 'id_num', 'crs_cde')

    Airbrake.notify(error, parameters: { section_id: section.id,
                                         student_course_history: sch_attrs })

    nil
  end

  # Update student enrollment status
  # @param sch [Ex::StudentCourseHistory] Ex Course enrollment
  # @param sect_st [SectionStudent] EMS Section enrollment
  def update_section_student(sch, sect_st)
    sect_st.status = sch.ems_status

    # We are not going to sync grades normally.
    # The only exceptions are withdrawn or incomplete states.
    if sch.withdrawn?(sect_st) || sch.incomplete?
      sect_st.grade_id = Ex::Grade.ems_grade_id_for(sch.grade_cde)
    end

    sect_st.save
  end

  # Create a new SectionStudent record for the provided Section using
  # information from a StudentCourseHistory record from Ex.
  #
  # @note This method will created a TermEnrollment for the newly enrolled
  #   student if a term enrollment record does not exist for that student/term
  #   pair
  # @param user [User]
  # @param section [Section]
  # @param sch [Ex::StudentCourseHistory] Ex Course enrollment
  # @return a newly creted SectionStudent
  def enroll!(user, section, sch)
    te = TermEnrollment
         .where(term_id: section.term_id, student_id: user.student.id).first

    ActiveRecord::Base.transaction do
      te ||= create_term_enrollment!(section.term_id, user.student.id)
      create_section_student!(section, user.student, te, sch)
    end
  end

  # Create a new term enrollment for a student/term pair
  #
  # @param term_id [Integer]
  # @param student_id [Integer]
  # @return a newly created TermEnrollment
  def create_term_enrollment!(term_id, student_id)
    TermEnrollment.create! do |term_enrollment|
      term_enrollment.term_id    = term_id
      term_enrollment.student_id = student_id
      term_enrollment.status     = 'active'
    end
  end

  # Create a new SectionStudent with the provided information
  #
  # @param section [Section] a Section
  # @param student [Student] a Student
  # @param te [TermEnrollment] a TermEnrollment
  # @param sch [Ex::StudentCourseHistory] Ex Course enrollment
  # @return a newly created SectionStudent
  def create_section_student!(section, student, te, sch)
    SectionStudent.create! do |ss|
      ss.section_id         = section.id
      ss.student_id         = student.id
      ss.term_id            = te.term_id
      ss.term_enrollment_id = te.id
      ss.status             = sch.ems_status

      ss.grade_id = Ex::Grade.ems_grade_id_for(sch.grade_cde) if sch.withdrawn? || sch.incomplete?
    end
  end
end
