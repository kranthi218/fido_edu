class StudentGradebook
  attr_reader :student, :organizer

  def initialize(section, student)
    @student   = student
    @section   = section
    @organizer = SubmittedWorkOrganizer.new(@section, @student)
  end

  def available?
    true
    # @section.setup_completed?
  end

  def submissions
    @submissions ||= organizer.submissions.sort_by { |s| s.coursework.ends_at }
  end

  def coursework
    @coursework ||= begin
                      @section.assignments.visible_to_students +
                        @section.quizzes.visible_to_students +
                        @section.discussions.visible_to_students
                    end
  end

  def points_earned_to_date
    organizer.visible_points_earned_to_date
  end

  def points_to_date
    coursework.sum(&:points)
  end
end
