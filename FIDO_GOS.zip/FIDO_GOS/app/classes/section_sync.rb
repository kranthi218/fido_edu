require 'course_code'

# This class encapsulates the logic reqiured to import Ex::Section records
# from Ex as Section records in the EMS
class SectionSync
  attr_writer :logger

  CREATE_MESSAGE          = 'Created new section(course_id=%s) for section [%s]'.freeze
  UPDATE_MESSAGE          = 'Updated section(course_id=%s) for section [%s]: %s'.freeze
  DESTROY_MESSAGE         = 'Deleted section(course_id=%s) for section[%s]'.freeze
  FAIL_TO_CREATE_MESSAGE  = 'Unable to create section(course_id=%s) for section [%s]: %s'.freeze
  FAIL_TO_UPDATE_MESSAGE  = 'Unable to update section(course_id=%s) for section [%s]: %s'.freeze
  FAIL_TO_DESTROY_MESSAGE = 'Unable to destroy section(%s) course_id=%s for section [%s]: %s'.freeze
  FAIL_TO_ASSIGN_FACULTY  = 'Unable to assign faculty to section(id=%s) using user(janzebar_id=%s)'.freeze
  FAIL_TO_PARSE_CC        = 'Unable to parse course code for ex section: %s'.freeze
  NO_TERM_FOR_EX_SECTION  = 'Unable to find term for Janzebar/Ex section: %s %s'.freeze
  NO_SECTION_FOR_EX_SECTION = 'Unable to find section for Ex Section: %s %s'.freeze

  def initialize
    @parser = CourseCodeParser.new

    yield(self) if block_given?
  end

  # @param term [Term] an instance of a term
  # @param ex_sections [Array<Ex::Section>, ActiveRecord::Relation]
  #   A collection of Ex::Section records to import
  def sync!(term, ex_sections)
    ex_sections.map do |ex_section|
      section = find_or_build_section(term, ex_section)
      create_or_update_section(term, section, ex_section)
    end
  end

  def unsync!(term, ex_sections)
    ex_sections.map do |ex_section|
      section_find_by(term, ex_section)
    end.compact.map do |section|
      destroy_section(section)
    end
  end

  private

  def logger
    @logger ||= Logger.new(STDOUT)
  end

  # @param term [Term] A Course record
  # @param ex_section [Ex::Section] A section record from Ex
  # @return [Section] an instance of a Section
  def find_or_build_section(term, ex_section)
    cc = get_course_code(ex_section)

    return nil unless cc

    course = cc.courses.first

    cc.sections(term.id).find_or_initialize_by(section: cc.section) do |section|
      section.course_id = course.id
      section.section   = cc.section
    end
  end

  def section_find_by(term, ex_section)
    cc = get_course_code(ex_section)

    return nil unless cc

    course = cc.courses.first

    cc.sections(term.id).find_by!(section: cc.section)
  rescue ActiveRecord::RecordNotFound => e
    logger.info(
      format(NO_SECTION_FOR_EX_SECTION, course.try(:id), cc.section)
    )
    nil
  end

  def destroy_section(section)
    section.try(:destroy)
    logger.info format(
      DESTROY_MESSAGE,
      section.course_id,
      section.section
    )
  rescue ActiveRecord::DeleteRestrictionError => e
    logger.warn format(
      FAIL_TO_DESTROY_MESSAGE,
      section.id,
      section.try(:course_id),
      section.try(:section),
      e
    )

    section
  rescue
    logger.warn format(
      FAIL_TO_DESTROY_MESSAGE,
      section.id,
      section.try(:course_id),
      section.try(:section),
      e
    )
  end

  # @param [Section] section
  # @param [Ex::Section] ex_section
  def create_section(section, ex_section)
    if section.save
      SurveyDataSetupJob.perform_later section
      copy_signature_assigment_to_section section

      logger.info(format(CREATE_MESSAGE, section.course_id, section.section))
    else
      err = section.errors.full_messages.join(', ')
      logger.warn(
        format(FAIL_TO_CREATE_MESSAGE, section.course_id, ex_section.crs_cde.strip, err)
      )
    end

    section
  end

  def copy_signature_assigment_to_section(section)
    course_term = CourseTerm.where(course: section.course, term: section.term).first
    return unless course_term && course_term&.published?
    course_term.duplicate_signature_assignment_to_section(section)
  end

  # @param [Section] section
  # @param [Ex::Section] ex_section
  def update_section(section, ex_section)
    if section.save
      logger.info format(UPDATE_MESSAGE, section.course_id, section.section, section.changed)
    else
      err = section.errors.full_messages.join(', ')
      logger.warn format(FAIL_TO_UPDATE_MESSAGE, section.course_id, ex_section.crs_cde.strip, err)
    end

    section
  end

  # Take a new or existing Section and ensure it has all the data it needs
  # to be valid before finally persisting that record.
  # @param term [Term]
  # @param section [Section]
  # @param ex_section [Ex::Section]
  # @return [Section] a instance of Section
  def create_or_update_section(term, section, ex_section)
    # FIXME: Bypass to ensure that this section `ends_at` date doesn't change
    # after EX Sync (see ETPO-431 for further details)
    return section if section.id == 4597

    section.category = category_for_section(ex_section)
    section.term = term

    # Prior to December of 2014, dates in Ex were stored stored with a timezone
    # of PST/PDT even though the timestamps were in fact UTC times.
    #
    # After December 2014, Ex timestamps are properly tagged as UTC dates.
    #
    # See EMS-708 witin JIRA for details.
    if term.starts_at.year >= 2015
      starts_at = section_start_date(term, ex_section)
      ends_at   = section_end_date(term, ex_section)
    else
      starts_at = utc_as_local_to_local(ex_section.first_begin_dte)
      ends_at   = utc_as_local_to_local(ex_section.last_end_dte)
    end
    # moved credits to manage by section check ETPO-680
    if ex_section.credit_hrs && ex_section.credit_hrs > 0
      section.credits = ex_section.credit_hrs
    elsif ex_section.min_credit_hrs && ex_section.min_credit_hrs > 0
      section.credits = ex_section.min_credit_hrs
    elsif ex_section.max_credit_hrs && ex_section.max_credit_hrs >= 0
      section.credits = ex_section.max_credit_hrs
    end

    # Ensure we keep sections open from the beginning of the first day
    # up through the end of the last day.
    section.starts_at      = starts_at.beginning_of_day
    section.ends_at        = ends_at.end_of_day
    section.max_enrollment = ex_section.crs_capacity
    section.use_pass_fail  = ex_section.credit_type_cde == 'PF'

    # Associate section with the correct department
    section.department_id =
      ex_section.try(:ex_department).try(:ems_department).try(:id)

    section = if section.persisted?
                update_section(section, ex_section)
              else
                create_section(section, ex_section)
              end

    # Associate this section with the correct insturctor
    ex_faculty_id_nums = ex_section.ex_faculty.pluck(:id_num)

    faculty = Faculty.joins(:user).where(
      users: { janzebar_id: ex_faculty_id_nums }
    )
    section.faculty = faculty

    # Log any instances where we were unable to locate EMS users for a faculty
    # record within Ex
    ems_faculty_id_nums = faculty.map { |f| f.user.janzebar_id }

    ex_faculty_id_nums.each do |id_num|
      next if ems_faculty_id_nums.include?(id_num)

      logger.warn format(
        FAIL_TO_ASSIGN_FACULTY,
        section.id,
        id_num
      )
    end

    section
  end

  # Determine the Section#category attribute based on Ex::Section
  # attributes
  def category_for_section(ex_section)
    return 'Online' if ex_section.loc_cde == 'ONLIN'

    if ex_section.day_evening_sts == 'W'
      'Weekend'
    else
      'Regular'
    end
  end

  def get_course_code(ex_section)
    cc = @parser.parse(ex_section.crs_cde.strip)

    if cc.nil?
      logger.warn format(FAIL_TO_PARSE_CC, ex_section.crs_cde)
      nil
    else
      cc
    end
  end

  # For some strange reason, UTC times are stored in Ex and when we read them
  # back, we see those same times in the local timezone. This method takes
  # a UTC datetime object being treated as a local time and derives the correct
  # local time from the original UTC datetime values.
  #
  # Example:
  #   Ex::Section.last.first_begin_dte # => Fri, 13 Jun 2014 17:00:00 PDT -07:00
  #                 # This value SHOULD be: Sat, 14 Jun 2014 00:00:00 PDT -07:00
  #
  #  dt = DateTime.parse 'Fri, 13 Jun 2014 17:00:00 PDT -07:00'
  #  utc_as_local_to_local(dt)         # => Sat, 14 Jun 2014 00:00:00 PDT -07:00
  #
  # Note: Ideally we could configure out DB connection to Ex/Janzebar to return
  #       dates in UTC, but until we can figure that out this should work.
  def utc_as_local_to_local(datetime)
    t = datetime.utc
    DateTime.new(t.year, t.month, t.day, t.hour, t.min, t.sec, Time.zone.now.formatted_offset)
  end

  # this will set term start_date and end_date for all section except
  # online classes check ETPO-597 for more details

  def section_start_date(term, ex_section)
    if category_for_section(ex_section).eql?('Online')
      datetime_to_utc_date(ex_section.first_begin_dte)
    else
      term.starts_at
    end
  end

  def section_end_date(term, ex_section)
    if category_for_section(ex_section).eql?('Online')
      datetime_to_utc_date(ex_section.last_end_dte)
    else
      term.ends_at
    end
  end

  # Extract the UTC date for the provided date time.
  # @param [DateTime] datetime
  # @return [Date]
  def datetime_to_utc_date(datetime)
    datetime.utc.to_date
  end
end
