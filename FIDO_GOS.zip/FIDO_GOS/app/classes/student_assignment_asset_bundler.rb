require 'zip'

class StudentAssignmentAssetBundler
  attr_reader :title, :path, :logger

  def initialize(assignment, dir = nil)
    @assignment = assignment
    @tempdir    = dir || Dir.mktmpdir
    @title      = build_title
    @path       = format('%s/%s.zip', @tempdir, title)
    @logger     = Logger.new(File.join(Rails.root, 'log', 'asset_bundler.log'))
  end

  def archive!
    Zip::File.open(@path, Zip::File::CREATE) do |zf|
      @assignment.student_assignments.each do |student_assignment|
        student_number = student_assignment.student.student_number
        needs_suffix   = student_assignment.assets.count > 1

        student_assignment.assets.each_with_index do |asset, index|
          next unless asset.attachment.exists?
          suffix = (index + 1) if needs_suffix
          add_asset(zf, student_number, asset, suffix)
        end
      end
    end

    yield(self) if block_given?
  ensure
    implode!
  end

  def add_asset(zf, student_number, asset, suffix)
    adapter   = Paperclip.io_adapters.for(asset.attachment)
    extension = File.extname(adapter.original_filename)
    filename  = build_filename(student_number, extension, suffix)

    if File.exist?(adapter.path)
      zf.add(filename, adapter.path)
      zf.commit # Force commit in same context otherwise GC deletes tempfile
    else
      logger.warn format('Asset(%s): %s', asset.id, asset.attachment_file_name)
      logger.warn format('%s does not exist!', adapter.path)
    end
  end

  def build_filename(student_number, extension, suffix)
    chunks = [student_number, title]
    chunks << suffix
    chunks.compact.join('_') + extension
  end

  def bundle
    File.open(@path)
  end

  def implode!
    FileUtils.rm_rf(@tempdir)
  end

  private

  def build_title
    # Replace whitespace, slash or NULL with underscore to make it fs safe
    format('%s %s',
           @assignment.section.course_and_section_no,
           @assignment.title).gsub(%r{[\s\0\/]}, '_')
  end
end
