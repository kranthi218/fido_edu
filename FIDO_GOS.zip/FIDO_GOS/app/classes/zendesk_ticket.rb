# This class encapsulates the logic for validating the input's request for
# Zendesk ticket.
class ZendeskTicket
  include ActiveModel::Validations
  include ActiveModel::Conversion
  extend ActiveModel::Naming

  attr_accessor :name, :email, :body, :subject
  validates :name, presence: true
  validates :email, presence: true, format: {
    with: /\b[A-Z0-9._%a-z\-]+@(?:[A-Z0-9a-z\-]+\.)+[A-Za-z]{2,4}\z/
  }
  validates :subject, presence: true
  validates :body, presence: true, length: { maximum: 10_000 }

  def initialize(attributes = {})
    attributes.each do |name, value|
      send("#{name}=", value)
    end
  end

  def persisted?
    false
  end

  def to_hash
    {
      subject: @subject,
      comment:   { value: @body },
      requester: { email: @email, name: @name }
    }
  end
end
