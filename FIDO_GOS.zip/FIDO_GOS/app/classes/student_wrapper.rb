class StudentWrapper
  attr_reader :user, :student, :access

  def initialize(user_id)
    @user    = User.where(id: user_id).first
    @student = user.student
  end

  def id
    student.try(:id)
  end

  def of?(section)
    sections.include?(section)
  end

  def account_on_hold?
    @student.account_on_hold?
  end

  def deadlines_for_section(section)
    return [] unless student
    student.deadlines_for_section(section)
  end

  # This method gathers and combines users sections from
  def sections
    subqueries = []
    subqueries << Section.joins(:permissions).where(
      permissions: {
        user_id: user.id,
        group_type: 'access_section',
        view: true
      }
    ).to_sql

    if user.student
      subqueries << Section.joins(:section_students).where(
        section_students: {
          student_id: student.id,
          status: SectionStudent::ACTIVE_STATUSES
        }
      ).to_sql
    end

    query = format('(%s) AS sections', subqueries.join(' UNION '))

    Section.from(query).order('created_at desc').distinct
  end

  def section_ids
    sections.pluck(:id)
  end

  def section_students
    return nil unless @student
    @student.section_students
  end
end
