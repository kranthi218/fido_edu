class CourseworkTimeline
  # It exports all milestone data for section
  # backend logic

  STUDENT_COURSEWORK_MODEL_ASSOCIATIONS = %w[
    assignments
    quizzes
    discussions
    lessons
  ].freeze

  attr_reader :section, :milestones

  def initialize(section)
    @section = section
    @milestones = fetch_milestones
  end

  # it will create methods for all courseworks as defined in
  # STUDENT_COURSEWORK_MODEL_ASSOCIATIONS
  STUDENT_COURSEWORK_MODEL_ASSOCIATIONS.each do |coursework|
    define_method coursework do
      section.public_send(coursework.to_sym)
    end
  end

  # not sure if we need to add, not active courseworks or retrievability_scope
  def courseworks
    assignments.visible_to_students + quizzes.visible_to_students + discussions.visible_to_students + lessons.visible_to_students
  end

  # it will arrange all coursework by milestones
  def group_courseworks_by_milestones
    grouped_courseworks = Hash.new { |hsh, key| hsh[key] = [] }
    courseworks.each do |coursework|
      milestone = coursework_belongs_to_milestone(coursework)
      grouped_courseworks[milestone].push(coursework) if milestone
    end
    grouped_courseworks.sort_by { |milestone, _courseworks| milestone.date }
  end

  # here passing coursework ends_at and checking first milestone that falls
  # into range of that date
  def coursework_belongs_to_milestone(coursework)
    coursework_date = coursework.ends_at || coursework.starts_at
    milestones.find { |m| m.date >= coursework_date.beginning_of_day }
  end

  # Ensure last milestone with date equal to section's due date exists
  def fetch_milestones
    last_milestone = section.milestones.last

    if !last_milestone || last_milestone.date != section.ends_at
      section.milestones.build(date: section.ends_at, mandatory: true)
    end

    section.milestones
  end
end
