# This class will detect proper cloner class end perform cloning action.
# To be used with Assignment, Discussiom, Quiz, Lesson coursework types.
# Basic usage: Cloner::Coursework.new(section).perform(coursework)
class Cloner::Coursework
  attr_reader :section, :calculate_dates

  # @param section [Section] Section recepient
  def initialize(section, calculate_dates = true)
    @section = section
    @calculate_dates = calculate_dates
  end

  # @param coursework Object to clone
  def perform(coursework)
    cloner = class_for(coursework).new(section) do |config|
      config.src = coursework
      config.calculate_dates = calculate_dates
    end

    cloner.perform
  end

  protected

  def class_for(coursework)
    Cloner.const_get(coursework.class.name, false)
  end
end
