# This class uses the ends_at of the original coursework as an offset
# to guess what date it might be in the destination course.
class Cloner::TimeCalculator
  attr_reader :source, :destination

  # @param source      [Section] Source Section
  # @param destination [Section] Target Section
  def initialize(source, destination)
    @source = source
    @destination = destination
  end

  # @param date [DateTime] Original coursework date from source section
  # @return [Datetime] Date with simillar offset inside destination section
  def similar_to(date)
    return destination.starts_at if date.nil? || source.starts_at.nil?

    offset = (date - source.starts_at).to_i
    new_date = destination.starts_at + offset
    new_date > destination.ends_at ? destination.ends_at : new_date
  end
end
