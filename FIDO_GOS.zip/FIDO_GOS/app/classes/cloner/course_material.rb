# This class will detect proper cloner class end perform cloning action.
# To be used with Books and CourseResources course material types.
# Basic usage: Cloner::CourseMaterial.new(section).perform(course_material)
class Cloner::CourseMaterial
  attr_reader :section

  # @param section [Section] Section recepient
  def initialize(section)
    @section = section
  end

  # @param coursework Object to clone
  def perform(course_material)
    cloner = class_for(course_material).new(section) do |config|
      config.src = course_material
    end

    cloner.perform
  end

  protected

  def class_for(course_material)
    Cloner.const_get(course_material.class.name, false)
  end
end
