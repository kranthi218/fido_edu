# Base clone functionality. Abstract, should be inherited in customized for each
# particular coursework type.
class Cloner::Base
  using ConsoleColorsStringRefinement

  RESOURCE_SUCCESS = "[CLONE] #{'done'.green} %s(%s) -> Section(%s)".freeze
  RESOURCE_ERROR   = "[CLONE] #{'failed'.red} %s(%s) -> Section(%s): %s".freeze
  ASSET_SUCCESS    = "[CLONE] #{'done'.green} %s(%s) -> %s(%s)".freeze
  ASSET_ERROR      = "[CLONE] #{'failed'.red} %s(%s) -> %s(%s): %s".freeze

  attr_accessor :logger, :src, :dest, :section, :time_calc, :calculate_dates

  # @param section [Section] Section recipient
  def initialize(section)
    @section = section

    yield(self) if block_given?
  end

  # Should receive coursework and set @src
  def perform
    raise NotImplementedError, 'You must implement perform method first!'
  end

  def time_calc
    @time_calc ||= Cloner::TimeCalculator.new(src.section, section)
  end

  def requested_dates_calculation?
    calculate_dates
  end

  def perform_dates_calculation
    dest.active    = true
    dest.starts_at = time_calc.similar_to(src.starts_at)
    if src.respond_to?(:ends_at)
      dest.ends_at =
        time_calc.similar_to(src.ends_at)
    end
  end

  # This method will prepend title with a sequence number if item with same
  # title and scope is already exist
  # @param [Hash] options
  # @option options [String] :field title field name
  # @option options [Hash]   :scope uniqueness scope
  # @return [String] title
  def compute_title(options = {})
    field      = options.fetch(:field, 'title')
    conditions = options.fetch(:scope, {})
    name       = src.attributes[field]
    count      = if src.is_a?(::Book) || src.is_a?(::CourseResource)
                   conditions[:section_id] = section.id
                   src.class
                      .where("#{field} LIKE ?", "#{name}%")
                      .where(conditions)
                      .count
                 else
                   src.class.where(
                     id: Coursework.where(
                       courseworkable: section,
                       content_type: src.class.to_s
                     ).pluck(:content_id)
                   ).where("#{field} LIKE ?", "#{name}%").where(conditions).count
                 end
    return name if count.zero?

    format('%s [%d]', name, count)
  end

  # @param source      [Object] Original object attachments donor
  # @param destination [Object] Copy object attahcments recipient
  def clone_assets(source, destination)
    return true unless source.respond_to?(:assets)

    source.assets.map do |asset|
      new_asset = asset.dup
      new_asset.attachment = asset.attachment
      new_asset.attachable = destination
      new_asset.save(validate: false)

      logger.info format(ASSET_SUCCESS,
                         new_asset.class,
                         new_asset.id,
                         destination.class,
                         destination.id)

      true
    rescue StandardError => e
      logger.warn format(ASSET_ERROR,
                         asset.class,
                         asset.id,
                         destination.class,
                         destination.id,
                         e)

      false
    end.all?
  end

  # @param source      [Object] Original object links donor
  # @param destination [Object] Copy object links recipient
  def clone_links(source, destination)
    return true unless source.respond_to?(:links)

    source.links.each do |link|
      new_link = link.dup
      new_link.linkable = destination
      new_link.save(validate: false)
    end

    true
  end

  def logger
    @logger ||= Rails.logger
  end
end
