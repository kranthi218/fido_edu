# Cloner::Discussion implementation
class Cloner::Discussion < Cloner::Base
  def perform

    coursework = Coursework.create(courseworkable: section)    
    @dest = src.deep_clone do |_original, copy|
      copy.topic             = compute_title(field: 'topic')
      copy.starts_at         = nil
      copy.ends_at           = nil
      copy.active            = false
      copy.visible           = false
      copy.course_module_id  = nil
      copy.grading_policy_id = nil
    end

    perform_dates_calculation if requested_dates_calculation?

    result = dest.save(validate: false) &&
             clone_assets(src, dest) &&
             clone_links(src, dest)

    coursework.content = dest
    coursework.save

    logger.info format(RESOURCE_SUCCESS, dest.class, dest.id, section.id)

    result
  rescue StandardError => e
    logger.warn format(RESOURCE_ERROR, src.class, src.id, section.id, e)

    false
  end
end
