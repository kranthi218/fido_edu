# Singleton class used to generate sample data; this sample data is used
# for the purposes of app demos as well as manual and automated testing
# of the EMS
class TestData
  # Create a test course, complete with faculty and students
  def self.generate_section(term: Term.current, faculty: nil, students: nil)
    term ||= FactoryBot.create(:term, starts_at: Date.today, active: true)

    # Create a new faculty for this course if it has not already been provided
    unless faculty
      faculty_user = FactoryBot.create(:user, prefix: 'faculty')
      faculty = FactoryBot.create(:faculty, user: faculty_user)
    end

    # Create new students for this course if they were not already provided
    unless students
      student_users = FactoryBot.create_list(:user, 10, prefix: 'student')
      students = student_users.map do |user|
        FactoryBot.create(:student, user: user)
      end
    end

    section = FactoryBot.create(:section, term: term)
    section.faculty << faculty

    # Enroll each student into our newly created class
    students.each do |student|
      te = student.term_enrollments.where(term_id: term.id).first
      te ||= FactoryBot.create(:term_enrollment, student: student, term: term)

      SectionStudent.create! do |ss|
        ss.student_id         = student.id
        ss.section_id         = section.id
        ss.term_id            = term.id
        ss.term_enrollment_id = te.id
        ss.status             = 'enrolled'
      end
    end

    results = students.map { |s| user_data_as_hash(s.user, student: true) }
    results.unshift user_data_as_hash(faculty.user, faculty: true)
  end

  # Given a newly perissted user object, return a hash containing that user's
  # email, password, student flag, and faculty flag.
  def self.user_data_as_hash(user, student: false, faculty: false)
    {
      email: user.email,
      password: user.password,
      student: student,
      faculty: faculty
    }
  end
  private_class_method :user_data_as_hash
end
