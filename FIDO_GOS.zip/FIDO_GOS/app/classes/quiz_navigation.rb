# This class takes two arguments 'quiz_score' and 'current_question'
class QuizNavigation
  QUIZ_BUTTONS = %w[previous next final].freeze

  def initialize(quiz_score, current_question)
    @quiz_score = quiz_score
    @current_question = current_question
  end

  # It takes one arguments button_clicked
  # expected values for button_clciked be 'next' or 'previous'
  # @return [question] for ('next' or 'previous') [nil] for other values
  def next_or_previous_question(button_clicked)
    if button_clicked == QUIZ_BUTTONS[0] &&
       @current_question != @quiz_score.first_question
      previous_question
    elsif button_clicked == QUIZ_BUTTONS[1] &&
          @current_question != @quiz_score.last_question
      next_question
    end
  end

  # @return [question]
  def next_question
    @quiz_score.question_set.each_with_index do |question_id, index|
      return Question.find(@quiz_score.question_set[index + 1]) if question_id == @current_question
    end
  end

  # @return [question]
  def previous_question
    @quiz_score.question_set.each_with_index do |question_id, index|
      return Question.find(@quiz_score.question_set[index - 1]) if question_id == @current_question
    end
  end
end
