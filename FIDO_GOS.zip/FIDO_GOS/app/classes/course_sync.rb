# frozen_string_literal: true

require 'course_code'

# This class encapsulates the logic reqiured to import courses from a
# given academic year/term
class CourseSync
  attr_writer :logger
  attr_reader :invalid_course_codes

  COURSE_CREATE = 'Created course(id=%{id}) with name [%{name}]'
  COURSE_UPDATE = 'Updated course(id=%{id}) with name [%{name}]: %{delta}'

  # Raised when we try to sync a course with an invalid course code
  class InvalidCourseCodeError < StandardError
    attr_reader :course_code

    def initialize(course_code)
      @course_code = course_code
    end

    def message
      format('Failed to parse course code: "%s"', @course_code)
    end
  end

  # Import/update courses for a given year and term
  # @param year_code [String] a string containing a 4 digit year
  # @param term_code [String] a string containing a 2 character
  #   term code (FA, SP, or SU for fall, summer, and spring respectively)
  # @note When we talk about the year, we mean the academic year. In a normal
  #   calendar, the summer of 2014 is just that. However, academic calendars
  #   start in Fall and end the following summer, so the *academic* year for
  #   summer of 2014 is considered as the summer term for the year of 2013.
  def initialize
    @invalid_course_codes = []

    yield(self) if block_given?
  end

  # @param ex_sections [Array<Ex::Section>, ActiveRecord::Relation]
  #   A collection of Ex::Section records to import
  def sync!(ex_sections)
    process_courses ex_sections
    process_courses_from_yml

    return if @invalid_course_codes.none?
    logger.error invalid_course_code_error_message
  end

  # Query an instance of CourseCodeSync to see if any errors were generated
  # @return [Boolean] true if errors are present, otherwise false
  def errors?
    !@invalid_course_codes.empty?
  end

  private

  def logger
    @logger ||= Logger.new(STDOUT)
  end

  # Takes a Ex::Section record and builds a new Course record with it
  # @param section [Ex::Section] The Ex::Section we wish to import
  # @param parsed_course_code [Treetop::Runtime::SyntaxNode] The result of
  #   running {CourseCodeParser} on a valid Ex::Section#crs_code attribute
  # @return [Course] an unsaved Course instance
  # rubocop:disable MethodLength
  def build_course_from_ex_section(section, parsed_course_code)
    course_no = format(
      '%s %s',
      parsed_course_code.course_code.department_code.text_value,
      parsed_course_code.course_code.course_number.text_value
    )

    c = Course.where(course_no: course_no).first || Course.new

    c.course_no = course_no
    c.name = format(
      '%s%s',
      section.crs_title,
      section.crs_title_2
    ).gsub(/(Online)/i, '').delete('()').squeeze(' ').strip

    c.department_id = if section.ex_department.present?
                        section.ex_department.ems_department.try(:id)
                      end

    c.rubric_required =
      !Ex::Section::RUBRIC_NOT_REQUIRED_COURSE_CODES
      .include?(parsed_course_code.course_code.department_code.text_value)

    c.description = if section.course_text.present?
                      section.course_text
                    else
                      'Course description unavailable'
                    end

    c.imported = true

    c
  end
  # rubocop:enable MethodLength

  # Iterates over each passed Ex::Section and attempts to import it as a
  # Course into the EMS
  # @param ex_sections [Array<Ex::Section>, ActiveRecord::Relation] a
  #   collection of Ex::Section objects
  # rubocop:disable MethodLength
  def process_courses(ex_sections)
    ex_sections.each do |ex_section|
      stripped_course_code = ex_section.crs_cde.strip
      cc = CourseCodeParser.new.parse stripped_course_code
      raise InvalidCourseCodeError, stripped_course_code if cc.nil?
      course = build_course_from_ex_section(ex_section, cc)

      # Ensure we have a well formed course code and valid course data
      # before we attempt to import a course
      if course&.valid?
        if course.persisted?
          course.save

          logger.info format(
            COURSE_UPDATE,
            id: course.id, name: course.name.strip, delta: course.changes
          )

        else
          course.save
          logger.info format(
            COURSE_CREATE,
            id: course.id, name: course.name.strip
          )
        end

        next

      # We couldn't import; was the course code invalid?
      elsif cc.nil?
        error_message = "Malformed course code: '#{ex_section.crs_cde}'"

      # The course code was valid, but we did not have sufficient data
      # to create a new course
      else
        validation_errors = course.errors.full_messages.join(', ')
        error_message = "Invalid course code: #{validation_errors}"
      end

      # If we get to this point, we have for some reason failed to
      # import this Ex::Section
      full_message = format('[%s] %s', stripped_course_code, error_message)
      logger.warn full_message
      @invalid_course_codes << full_message
    end
  end

  # Force update of new courses to EMS(create course without depedant on section)
  # for that mention course code in yml file and sync will pick it
  # for more details https://ituems.atlassian.net/browse/ETPO-780

  def process_courses_from_yml
    courses_list.each do |course|
      cc = CourseCodeParser.new.parse course.strip
      raise InvalidCourseCodeError, course if cc.nil?
      ex_catalog = find_course_from_catalog(course)
      next unless ex_catalog
      course = build_course_from_ex_catalog(ex_catalog, cc)

      # Ensure we have a well formed course code and valid course data
      # before we attempt to import a course
      if course&.valid?
        if course.persisted?
          course.save

          logger.info format(
            COURSE_UPDATE,
            id: course.id, name: course.name.strip, delta: course.changes
          )

        else
          course.save
          logger.info format(
            COURSE_CREATE,
            id: course.id, name: course.name.strip
          )
        end

        next

      # We couldn't import; was the course code invalid?
      elsif cc.nil?
        error_message = "Malformed course code: '#{ex_section.crs_cde}'"

      # The course code was valid, but we did not have sufficient data
      # to create a new course
      else
        validation_errors = course.errors.full_messages.join(', ')
        error_message = "Invalid course code: #{validation_errors}"
      end

      # If we get to this point, we have for some reason failed to
      # import this Ex::Section
      full_message = format('[%s] %s', stripped_course_code, error_message)
      logger.warn full_message
      @invalid_course_codes << full_message
    end
  end

  def build_course_from_ex_catalog(catalog, parsed_course_code)
    course_no = format(
      '%s %s',
      parsed_course_code.course_code.department_code.text_value,
      parsed_course_code.course_code.course_number.text_value
    )

    c = Course.where(course_no: course_no).first || Course.new

    c.course_no = course_no
    c.name = format(
      '%s%s',
      catalog.crs_title,
      catalog.crs_title_2
    ).gsub(/(Online)/i, '').delete('()').squeeze(' ').strip

    c.department_id = if catalog.ex_department.present?
                        catalog.ex_department.ems_department.try(:id)
                      end

    c.rubric_required =
      !Ex::Section::RUBRIC_NOT_REQUIRED_COURSE_CODES
      .include?(parsed_course_code.course_code.department_code.text_value)

    c.description = 'Course description unavailable'
    c.imported = true
    c
  end
  # rubocop:enable MethodLength

  def courses_list
    YAML.load_file(
      "#{Rails.root}/config/force_courses_sync.yml"
    )['Courses']
  end

  def find_course_from_catalog(course)
    Ex::Catalog.where(course_condition(course)).last
  end

  def course_condition(course)
    format("crs_cde LIKE '%s'", course.squish.tr(' ', '%'))
  end

  def invalid_course_code_error_message
    error_message = "Unable to import the following course codes:\n"
    error_message << @invalid_course_codes
                     .map { |cc| format('  - %s', cc) }
                     .join("\n")
  end
end
