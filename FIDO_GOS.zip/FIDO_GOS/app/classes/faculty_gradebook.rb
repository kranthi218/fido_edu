class FacultyGradebook
  include ActionView::Helpers::NumberHelper
  alias_method :read_attribute_for_serialization, :send

  # Gradable student submission types
  #
  # Note that the order here is signification and should
  # match the order of the corresponding assignment types
  # defined within `Section::GRADABLE`
  STUDENT_SUBMISSION_MODELS = [
    StudentAssignment,
    QuizScore,
    DiscussionParticipant
  ]

  attr_reader :total_points
  attr_reader :headers
  attr_reader :points_to_date

  def initialize(section)
    @section = section
    @total_points = get_total_points
    @headers = get_headers
    @points_to_date = get_points_to_date
  end

  def get_headers
    h = %w(Id Name)

    if @section.points_grading?
      index = 0

      @total_points.each_with_index do |cw_points, index|
        h << Section::GRADABLE[index] if cw_points > 0
      end

      if @section.grading_closed_at.present?
        h << 'Total Points'
      else
        h << 'Points to Date'
      end

    elsif @section.weighted_grading?
      h += @section.grading_policies.map { |e| "#{e.name} (#{e.weight}%)" }

      if @section.grading_closed_at.present?
        h += ['Weighted Score']
      else
        h += ['Weighted Score to Date']
      end
    end

    h
  end

  # Here we calculate a the points a particular student has earned.
  def points_earned(student)
    return coursework_points(student.id) if @section.points_grading?
    return grading_policy_points(student.id) if @section.weighted_grading?
    0
  end

  def letter_grade(score, possible)
    possible.zero? ? 'N/A' : GradingScale.score_to_grade(score)
  end

  # Returns specified students results for all coursework types.
  # "result_type" specifies Assignment, Discussion, or Quiz.
  # Rows are normalized to a consistent format using NULL
  # for inapplicable fields.
  def get_student_results(student)
    @results = ActiveRecord::Base.connection.select_all(
      query_select_all_submitted_for_student(student.id)
    )
  end

  # Build an array of pairs of points scored by student
  # The last two entries are the totals so far, and the letter grade.
  def coursework_points(student_id)
    points = []
    earned = possible = 0

    STUDENT_SUBMISSION_MODELS.each.with_index do |coursework, i|
      category_max = points_to_date[i]
      student_scores = coursework
        .scores_for_student_for_section(@section.id, student_id)
        .sum(:score) || 0

      earned += student_scores
      possible += category_max
      if category_max > 0
        points.push format(
          '%s / %s',
          format_number(student_scores),
          format_number(category_max)
        )
      end
    end

    percentage = number_to_percentage(
      (earned.to_f / (possible.to_f.nonzero? || 1)) * 100,
      precision: 1,
      strip_insignificant_zeros: true
    )

    points.push format(
      '%s / %s (%s)',
      format_number(earned),
      format_number(possible),
      percentage
    )

    points
  end

  private

  def format_number(number)
    number_with_precision(number, precision: 2, strip_insignificant_zeros: true)
  end

  def get_total_points
    if @section.points_grading?
      points = Section::GRADABLE.map do |e|
        @section.send(e.downcase).sum('points') || 0
      end

    elsif @section.weighted_grading?
      totals = ActiveRecord::Base.connection.select_all(
        query_select_points_sql(@section.grading_policy_ids, @section.id)
      )

      calculate_points(totals)
    end
  end

  def get_points_to_date
    if @section.points_grading? || !@section.grading_method
      Section::GRADABLE.map do |e|
        @section.send(e.downcase).try(:current).try(:sum, :points) || 0
      end

    elsif @section.weighted_grading?
      totals = ActiveRecord::Base.connection.select_all(
        query_select_points_to_date_sql(@section.grading_policy_ids,
                                        @section.id)
      )

      calculate_points(totals)
    end
  end

  # @todo Reduce the number of database calls required for this method
  def grading_policy_points(student_id)
    points = []
    earned = 0

    @section.grading_policies.each.with_index do |grading_policy, i|
      current_points = points_to_date[i]
      p = 0

      p += StudentAssignment
        .student_score_by_grading_policy(student_id, grading_policy.id).sum(:score) || 0
      p += QuizScore
        .student_score_by_grading_policy(student_id, grading_policy.id).sum(:score) || 0
      p += DiscussionParticipant
        .student_score_by_grading_policy(student_id, grading_policy.id).sum(:score) || 0

      if current_points.nil? || current_points.zero?
        earned += 0
      else
        a = (p / current_points) * 100
        b = grading_policy.weight.to_f / 100
        earned += a * b
      end
      points.push format(
        '%s / %s',
        format_number(p),
        format_number(current_points)
      )
    end

    points.push number_to_percentage(
      earned, precision: 1, strip_insignificant_zeros: true
    )

    points
  end

  def calculate_points(totals)
    xpoints = {}

    totals.each do |score|
      grading_policy_id = score['grading_policy_id'].to_i

      xpoints[grading_policy_id] ||= 0
      xpoints[grading_policy_id] += score['points']
    end

    @section.grading_policies.map do |grading_policy|
      xpoints[grading_policy.id] || 0
    end
  end

  # For sections with weighted grading, select total possible points
  # by grading policy
  def query_select_points_sql(grading_policy_ids, section_id)
    <<-POINTS_QUERY.squish
      SELECT grading_policy_id, SUM(points) AS points FROM assignments, coursework
        WHERE grading_policy_id IN (#{grading_policy_ids.join(', ')})
          AND coursework.courseworkable_id = #{section_id}
          AND coursework.courseworkable_type = 'Section'
          AND coursework.content_type = 'Assignment'
          AND coursework.content_id = assignments.id
        GROUP BY grading_policy_id
      UNION ALL SELECT grading_policy_id, SUM(points) AS points FROM quizzes, coursework
        WHERE grading_policy_id IN (#{grading_policy_ids.join(', ')})
          AND coursework.courseworkable_id = #{section_id}
          AND coursework.courseworkable_type = 'Section'
          AND coursework.content_type = 'Quiz'
          AND coursework.content_id = quizzes.id
        GROUP BY grading_policy_id
      UNION ALL SELECT grading_policy_id, SUM(points) AS points FROM discussions, coursework
        WHERE grading_policy_id IN (#{grading_policy_ids.join(', ')})
          AND coursework.courseworkable_id = #{section_id}
          AND coursework.courseworkable_type = 'Section'
          AND coursework.content_type = 'Discussion'
          AND coursework.content_id = discussions.id
        GROUP BY grading_policy_id
    POINTS_QUERY
  end


  # Select the points for all categories of work for a section that
  # has a due date that has already passed
  def query_select_points_to_date_sql(grading_policy_ids, section_id)
    <<-POINTS_QUERY.squish
      SELECT grading_policy_id, SUM(points) AS points FROM assignments, coursework
        WHERE grading_policy_id IN (#{grading_policy_ids.join(', ')})
          AND coursework.courseworkable_id = #{section_id}
          AND coursework.courseworkable_type = 'Section'
          AND coursework.content_type = 'Assignment'
          AND coursework.content_id = assignments.id
          AND ends_at <= UTC_TIMESTAMP()
        GROUP BY grading_policy_id
      UNION ALL SELECT grading_policy_id, SUM(points) AS points FROM quizzes, coursework
        WHERE grading_policy_id IN (#{grading_policy_ids.join(', ')})
          AND coursework.courseworkable_id = #{section_id}
          AND coursework.courseworkable_type = 'Section'
          AND coursework.content_type = 'Quiz'
          AND coursework.content_id = quizzes.id
          AND ends_at <= UTC_TIMESTAMP()
        GROUP BY grading_policy_id
      UNION ALL SELECT grading_policy_id, SUM(points) AS points FROM discussions, coursework
        WHERE grading_policy_id IN (#{grading_policy_ids.join(', ')})
          AND coursework.courseworkable_id = #{section_id}
          AND coursework.courseworkable_type = 'Section'
          AND coursework.content_type = 'Discussion'
          AND coursework.content_id = discussions.id
          AND ends_at <= UTC_TIMESTAMP()
        GROUP BY grading_policy_id
    POINTS_QUERY
  end


  # select all a student's coursework for a course,
  # including coursework info and score info
  # intended to be using with some kind of select_finder,
  # like ActiveRecord::Base.connection.select_all(sql)
  def query_select_all_submitted_for_student(student_id)
    <<-STUDENT_QUERY.squish
      (
        SELECT
          'Discussion' as result_type,
          t1.id,
          t2.id as result_id,
          t1.topic,
          t2.score as work_id,
          t1.topic,
          t2.score,
          t2.feedback,
          t1.points,
          t1.soft_deadline,
          t1.ends_at as ends_at,
          t2.created_at as submit_date,
          NULL as hide_scores_on_submission,
          1 as published,
          t2.graded
        FROM discussions t1, discussion_participants t2, coursework t3
        WHERE
          t1.id = t3.content_id and
          t3.content_type = 'Discussion' and
          t3.courseworkable_type = 'Section' and
          t3.courseworkable_id = #{@section.id} and
          t2.student_id = #{student_id} and
          t1.id = t2.discussion_id and
          t1.active = true
      )
      UNION
      (
        SELECT
          'Quiz' as result_type,
          t1.id,
          t2.id as result_id,
          t1.title,
          t2.score as work_id,
          t1.title,
          t2.score,
          NULL as feedback,
          t1.points,
          t1.soft_deadline,
          t1.ends_at as ends_at,
          t2.submitted_at as submit_date,
          t1.hide_scores_on_submission,
          1 as published,
          1 as graded
        FROM quizzes t1, quiz_scores t2, coursework t3
        WHERE
          t1.id = t3.content_id and
          t3.content_type = 'Quiz' and
          t3.courseworkable_type = 'Section' and
          t3.courseworkable_id = #{@section.id} and
          t2.student_id = #{student_id} and
          t1.id = t2.quiz_id and
          t1.active = true
      )
      UNION
      (
        SELECT
          'Assignment' as result_type,
          t1.id,
          t2.id as result_id,
          t1.title,
          t2.score as work_id,
          t1.title,
          t2.score,
          t2.feedback,
          t1.points,
          t1.soft_deadline,
          t1.ends_at as ends_at,
          t2.created_at as submit_date,
          NULL as hide_scores_on_submission,
          t2.published,
          t2.graded
        FROM assignments t1, student_assignments t2, coursework t3
        WHERE
          t1.id = t3.content_id and
          t3.content_type = 'Assignment' and
          t3.courseworkable_type = 'Section' and
          t3.courseworkable_id = #{@section.id} and
          t2.student_id = #{student_id} and
          t1.id = t2.assignment_id and
          t1.active = true
      ) ORDER BY ends_at
    STUDENT_QUERY
  end
end
