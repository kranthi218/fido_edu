# it is used for all calculation for scholarship
class Scholarship
  def initialize(term = Term.current.id)
    @term = term
  end

  # this method is used for to count section gain number
  def count_clgain(section)
    grading_details = section.section_students.eager_load(:grade).group('grades.name').size
    wgain           = grading_details.merge(Grade::WGSUM) { |_k, a_value, b_value| (a_value * b_value).round(2) }.values.sum
    clgain = (Grade::SCALE - (wgain / section.student_count).round(2))
    zero_or_more(clgain)
  end

  def student_ranking_number(student_id)
    student_index_number = 0
    grading_details      = SectionStudent.student_term_grading(student_id, @term)
    grading_details.each do |key, value|
      class_gain_number = count_clgain(Section.find(value))
      zero_or_more(class_gain_number + (Grade::SGAIN[key] || 0))
      student_index_number += zero_or_more(class_gain_number + (Grade::SGAIN[key] || 0))
    end
    student_index_number.round(2)
  end

  private

  def zero_or_more(n)
    n > 0 ? n : 0
  end
end
