require 'time_diff'
# can clone assignments, course_resources, discussions, lessons & quizzes
# things_to_clone look like
#      "assignments" => {
#   "ids" => [
#     [0] "4352",
#     [1] "4365",
#     [2] "4376",
#     [3] "4378",
#     [4] ""
#   ]
#   etc.
# Course cloner clones coursework from one section to another. We try to set
# the date of the new course work intelligently, and things we can't guess at
# like what course_module to use, we erase. This results in coursework that is
# possibly in an invalid state (if they use a grading method), so we disable
# visibility. Validations will be done when visibility is enabled.
class Coursecloner
  def initialize(dest_section, source_section, things_to_clone, current_user)
    @dest_section = dest_section
    @source_section = source_section
    @things_to_clone = remove_empty_elements(things_to_clone)
    @current_user = current_user
  end

  def validations_fail
    if @current_user.faculty.section_ids.include?(@dest_section.id) && @current_user.faculty.section_ids.include?(@source_section.id)
      false
    else
      true
    end
  end

  # call this after new
  def clone_selected
    _results = []
    if validations_fail
      _results.push 'You are not faculty for one or more of the clases.'
    else
      @time_calculator = TimeCalculator.new(@dest_section.starts_at, @dest_section.ends_at, @source_section.starts_at, @source_section.ends_at)
      @things_to_clone.each do |clone_type, ids|
        case clone_type
        when 'assignments'
          _results.push clone_assignments ids
        when 'quizzes'
          _results.push clone_quizzes ids
        when 'discussions'
          _results.push clone_discussions ids
        when 'lessons'
          _results.push clone_lessons ids
        when 'course_resources'
          _results.push clone_course_resources ids
        end
      end
    end
    # Cloned items will be validated when faculty makes them visible
    @dest_section.save(validate: false)
    _results
  end

  def clone_course_resources(ids)
    total = 0
    if ids.present? && ids.count.positive?
      ids.each do |i|
        resource = i.blank? ? nil : CourseResource.find(i)
        new_resouce = resource.dup
        next unless new_resouce.present?
        clone_assets new_resouce, resource.assets
        @dest_section.course_resources << new_resouce
        total += 1
      end
    end
    "Cloned #{total} out of #{ids.present? ? ids.count : 0} course resources."
  end

  def clone_assignments(ids)
    total = 0
    if ids.present? && ids.count > 0
      ids.each do |i|
        a = i.blank? ? nil : Assignment.find(i)
        next unless a.present?
        _assignment = a.dup
        _assignment.starts_at = @time_calculator.similar_date(a.starts_at)
        _assignment.ends_at = @time_calculator.similar_date(a.ends_at)
        _assignment.visible = false
        _assignment.course_module_id = nil
        _assignment.grading_policy_id = nil
        clone_assets _assignment, a.assets
        # logger.debug "\r\nREBECCA #{__method__}  original date #{a.ends_at} calculated date #{_assignment.ends_at}"
        @dest_section.assignments << _assignment
        total += 1
      end
    end
    @dest_section.save(validate: false)
    "Cloned #{total} out of #{ids.present? ? ids.count : 0} assignments."
  end

  def clone_lessons(ids)
    total = 0
    if ids.present? && ids.count > 0
      ids.each do |i|
        a = i.blank? ? nil : Lesson.find(i)
        next unless a.present?
        lesson = a.dup
        lesson.starts_at = @time_calculator.similar_date(a.starts_at)
        lesson.course_module_id = nil
        lesson.coursework = a.coursework
        @dest_section.lessons << lesson
        clone_assets lesson, a.assets
        total += 1
      end
    end
    "Cloned #{total} out of #{ids.present? ? ids.count : 0} lessons."
  end

  def clone_discussions(ids)
    total = 0
    if ids.present? && ids.count > 0
      ids.each do |i|
        a = i.blank? ? nil : Discussion.find(i)
        next unless a.present?
        discussion = a.dup
        discussion.starts_at = @time_calculator.similar_date(a.starts_at)
        discussion.ends_at = @time_calculator.similar_date(a.ends_at)
        discussion.visible = false
        discussion.course_module_id = nil
        discussion.grading_policy_id = nil
        discussion.coursework = a.coursework
        @dest_section.discussions << discussion
        clone_assets discussion, a.assets
        total += 1
      end
    end
    "Cloned #{total} out of #{ids.present? ? ids.count : 0} discussions."
  end

  def clone_quizzes(ids)
    total = 0
    if ids.present? && ids.count > 0
      ids.each do |i|
        a = i.blank? ? nil : Quiz.find(i)
        next unless a.present? && a.questions.count > 0
        quiz = a.dup
        quiz.section = @dest_section
        quiz.starts_at = @time_calculator.similar_date(a.starts_at)
        quiz.ends_at = @time_calculator.similar_date(a.ends_at)
        quiz.visible = false
        quiz.course_module_id = nil
        quiz.grading_policy_id = nil
        quiz.coursework = a.coursework
        a.questions.each do |question_id|
          question = Question.find(question_id.id)
          new_question = question.dup
          question.question_answers.each do |qa_id|
            qa = QuestionAnswer.find(qa_id.id)
            new_qa = qa.dup
            new_question.question_answers << new_qa
          end
          quiz.questions << new_question
        end
        quiz.questions << new_question
        quiz.save(validate: false)
        total += 1
      end
    end
    "Cloned #{total} out of #{ids.present? ? ids.count : 0} Quizzes."
  end

  def clone_assets(attachable, collection)
    collection.each do |asset|
      new_asset = asset.dup
      new_asset.attachment = asset.attachment
      attachable.assets << new_asset
    rescue Errno::ENOENT
      Rails.logger.error "File is not exist: #{asset.attachment.path}"
    end
  end

  # This class uses the ends_at of the original coursework as an offset
  # to guess what date it might be in the destination course.
  class TimeCalculator
    def initialize(dest_start, dest_end, src_start, src_end)
      @dest_start = dest_start
      @dest_end = dest_end
      @src_start = src_start
      @src_end = src_end
    end

    def similar_date(dt)
      if dt.nil? || @src_start.nil?
        @src_start
      else
        diffs = Time.diff(@src_start, dt)
        @new_date = @dest_start + diffs[:day]
        @new_date > @dest_end ? @dest_end : @new_date
      end
    end
  end

  def remove_empty_elements(container)
    cleaned = {}
    container.each do |k, v|
      new_v = v.map { |_k, v| v.delete_if(&:blank?) }.flatten
      cleaned[k] = new_v if new_v.count > 0
    end
    cleaned
  end
end
