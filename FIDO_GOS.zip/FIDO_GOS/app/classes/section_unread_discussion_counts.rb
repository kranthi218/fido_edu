# Calculate unread comments for all discussions in a section
class SectionUnreadDiscussionCounts
  def initialize(section, user, role = :student)
    @section = section
    @user = user
    @role = role
  end

  def discussions_with_unread_count
    d_count = {}
    discussions.each do |discussion|
      reader = DiscussionCommentReader.new @user, discussion
      d_count[discussion] =
        discussion.unread_comments(@user, reader.read_discussion_comment_ids)
                  .count
    end
    d_count
  end

  def discussions
    case @role
    when :student
      @section.discussions.visible_to_students
    else
      @section.discussions
    end
  end
end
