class InstitutionalResearchReport
  class SignatureAssignment
    def self.generate_clo_report(term = Term.current)
      # generate average score for CLO across different course work for a student
      # Term, SectionName, StudentNumber, CLO1, Average Score. ClO1, AverageScore, CLO3, Average Score
      # Exporting Starting Spring 2014
      CSV.open("#{ENV['HOME']}/average_clo_scores_report-#{term.display_name.parameterize}.csv", 'wb') do |csv|
        csv << ['Term', 'Section', 'Student ID']
        SectionStudent.where(term: term).where(status: %w[enrolled graded]).find_each do |section_student|
          section = section_student.section
          student = section_student.student
          row = [
            section.term.display_name,
            section.display_name,
            student.student_number
          ]

          section.course_learning_outcomes.each do |clo|
            row << clo.description << AssessmentLearningOutcome.average_clo_score_for(student, section, clo)
          end
          csv << row
        end
      end
    end

    def self.generate_clo_report_per_section(term = Term.current)
      # courses = Course.where("course_no LIKE ? OR course_no LIKE ?", 'CSC%', 'SWE%')
      # sections = Section.where(term_id: 72, course: courses)
      sections = Section.where(term: term)
      CSV.open("#{ENV['HOME']}/average_clo_scores_per_section_report-#{term.display_name.parameterize}.csv", 'wb') do |csv|
        csv << %w[section_id course_and_section_no clo_id clo_description clo_average]
        sections.each do |section|
          section.course_learning_outcomes.each do |clo|
            alo_scores = AssessmentLearningOutcome.where(assessment: StudentAssignment.where(assignment: section.assignments), course_learning_outcome: clo).pluck(:score)
            alo_scores += AssessmentLearningOutcome.where(assessment: DiscussionParticipant.where(discussion: section.discussions), course_learning_outcome: clo).pluck(:score)
            alo_scores += AssessmentLearningOutcome.where(assessment: QuizScore.where(quiz: section.quizzes), course_learning_outcome: clo).pluck(:score)
            answer = alo_scores.empty? ? 'no grades' : alo_scores.inject(0) { |sum, x| sum + x } / alo_scores.size.to_f
            csv << [section.id, section.course_and_section_no, clo.id, clo.description, answer]
          end
        end
      end
    end

    def self.generate_clo_signature_assignment_report(term = Term.current)
      # generate average score for CLO across different course work for a student
      # Term, SectionName, StudentNumber, CLO1, Average Score. ClO1, AverageScore, CLO3, Average Score
      # Exporting Starting Spring 2014
      CSV.open("#{ENV['HOME']}/average_clo_signature_assignment_scores_report-#{term.display_name.parameterize}.csv", 'wb') do |csv|
        csv << ['Term', 'Section', 'Student ID']
        SectionStudent.where(term: term).where(status: %w[enrolled graded]).find_each do |section_student|
          section = section_student.section
          student = section_student.student
          row = [
            section.term.display_name,
            section.display_name,
            student.student_number
          ]
          next unless section.signature_assignment
          section.signature_assignment.course_learning_outcomes.each do |clo|
            row << clo.description << AssessmentLearningOutcome
                                      .average_clo_score_for_signature_assignment(
                                        student, section, clo
                                      )
          end
          csv << row
        end
      end
    end

    def self.generate_plo_report(term = Term.current)
      CSV.open("#{ENV['HOME']}/average_plo_scores_report-#{term.display_name.parameterize}.csv", 'wb') do |csv|
        csv << ['Program', 'Program Learning Outcome', 'Avg Score']
        ProgramTerm.where(term: term).each do |program_term|
          program_term.plos.each do |plo|
            csv << [
              program_term.name,
              plo.description,
              AssessmentLearningOutcome.average_plo_score_for(term, plo)
            ]
          end
        end
      end
    end

    def self.generate_ilo_report(term = Term.current)
      csv_name = "#{ENV['HOME']}/average_ilo_scores_report-#{term.display_name.parameterize}.csv"
      CSV.open(csv_name, 'wb') do |csv|
        csv << ['Institutional Learning Outcome', 'Avg Score']
        IloTerm.where(term: term).each do |ilo_term|
          csv << [
            ilo_term.ilo.description,
            AssessmentLearningOutcome.average_ilo_score_for(term, ilo_term.ilo)
          ]
        end
      end
    end

    def self.generate_section_data_report(terms)
      CSV.open("#{ENV['HOME']}/section_data_report.csv", 'wb') do |csv|
        csv << ['Term', 'Section', 'CLO Count', 'Signature Assignment Creation Date']
        terms.each do |term|
          term.sections.each do |section|
            csv << section_data_report_row(section)
          end
        end
      end
    end

    def self.section_data_report_row(section)
      [
        section.term.display_name,
        section.course_and_section_no,
        section.course_learning_outcomes.count,
        section.signature_assignment.try(:created_at).try(:strftime, '%a %m/%d/%y %I:%M %p')
      ]
    end
  end

  # this was some quick dirty work to get assignments and submissions
  # for MBA department
  class Assignment
    attr_reader :rows, :file_name
    def initialize(limit = 100, file_name)
      @limit = limit
      @file_name = file_name
    end

    def cpt
      student_assignments = StudentAssignment.joins(assignment: { section: %i[course term] })
                                             .where(courses: { course_no: ['INT 593P', 'INT 593F'] }).where("sections.section LIKE 'BA%'")
                                             .where(terms: { id: 68 })
      to_csv(student_assignments)
    end

    def signature
      student_assignments = StudentAssignment.joins(assignment: { section: %i[course term] })
                                             .where(courses: { course_no: ['FIN 534', 'MGT 503', 'MKT 551', 'MIS 527'] })
                                             .where(terms: { id: 68 })
      to_csv(student_assignments)
    end

    def to_csv(student_assignments)
      CSV.open(file_name, 'wb') do |csv|
        csv << ['Term', 'Student ID', 'Section Name', 'Section', 'Category', 'Assignment', 'SignatureAssignment', 'Score']
        student_assignments.find_each do |student_assignment|
          csv << [
            student_assignment.assignment.section.term.display_name,
            student_assignment.student.student_number,
            student_assignment.assignment.section.display_name,
            student_assignment.assignment.section.section,
            student_assignment.assignment.section.category,
            student_assignment.assignment.title,
            student_assignment.assignment.section.signature_assignment.blank? ? 'No' : 'Yes',
            student_assignment.score
          ]
        end
      end
    end
  end

  class Grade
    def self.compare_versions(term)
      CSV.open("#{ENV['HOME']}/grade_report-term-#{term.id}-comparison.csv", 'wb') do |csv|
        csv << ['Student', 'Section', 'Course', 'Section ID (EMS)',
                'Course ID (EMS)', 'Grade (EMS)', 'Student Name', 'Instructor Name(s)',
                'Grade (EX)', 'Equal?']
        ex_hash = prepare_ex_hash

        ems_csv(term).each do |element|
          csv << prepare_csv_row(element, ex_hash)
        end
      end
    end

    def self.prepare_csv_row(element, ex_hash)
      element << ex_hash["#{element[0]}-#{element[1]}"]
      element << (element.last == element[5])
    end

    def self.prepare_ex_hash
      # this file contains a header, and the values are:
      # student_number, CRS_CDE, grade
      # FIXME: it's currently assuming that this is the path
      arr = CSV.read("#{ENV['HOME']}/ex_grades.csv", 'r')
      arr.shift
      hsh = {}
      arr.each do |element|
        hsh["#{element[0]}-#{element[1].split.join(' ')}"] = element[2]
      end
      hsh
    end

    def self.ems_csv(term)
      # FIXME: it's currently assuming that this is the path
      arr = CSV.read("#{ENV['HOME']}/grade_report-term-#{term.id}.csv", 'r')
      arr.shift
      arr
    end

    def self.generate_term_report(term)
      CSV.open("#{ENV['HOME']}/grade_report-term-#{term.id}.csv", 'wb') do |csv|
        csv << ['Student', 'Section', 'Course', 'Section ID (EMS)',
                'Course ID (EMS)', 'Grade', 'Student Name', 'Instructor Name(s)']
        arr = section_student_data_array(term)
        arr.each { |row| csv << row }
      end
    end

    def self.section_student_data_array(term)
      arr = []
      Section.where(term: term).each do |section|
        section.section_students.each do |section_student|
          arr << section_student_data_row(section_student)
        end
      end
      arr
    end

    def self.section_student_data_row(section_student)
      [
        section_student.student.student_number,
        section_student.section.course_and_section_no,
        section_student.section.course_no,
        section_student.section.id,
        section_student.section.course_id,
        section_student.grade.try(:name),
        section_student.student.try(:user).try(:full_name),
        section_student.section.faculty.map(&:full_name).join(', ')
      ]
    end

    def self.generate_grade_distribution_report(term = Term.current)
      csv_name = "#{ENV['HOME']}/grade_distribution_report-#{term.display_name.parameterize}.csv"
      header_array = %w[Section Department Faculty]
      grades = ::Grade.order('high asc, low asc, name asc').all
      header_array += grades.pluck(:name)

      CSV.open(csv_name, 'wb') do |csv|
        csv << header_array
        sections = ::Section.where(term: term)

        sections.each do |section|
          section_students = ::SectionStudent.includes(:grade).where(
            term_id: section.term_id,
            section_id: section.id,
            status: %w[enrolled graded]
          )
          section_grades = section_students.group(:grade_id).count
          grade_counts = grades.map { |g| (section_grades[g.id] || 0) }
          response_array = [
            section.course_and_section_no,
            section.department.name,
            section.faculty.map(&:full_name).join('; ')
          ]
          response_array += grade_counts
          csv << response_array
        end
      end
    end
  end

  class Survey
    def self.responses(section, question_type = 'multiple_choice')
      responses = []
      section.surveys.each do |survey|
        survey.questions.each do |question|
          question.survey_responses.each do |survey_response|
            if question_type == 'multiple_choice' && question.question_type == question_type
              responses << QuestionAnswer.find(survey_response.response.to_i).choice.to_i
            elsif question_type == 'text_answer' && question.question_type == question_type
              responses << survey_response
            end
          end
        end
      end
      responses
    end

    def self.response_average(survey_responses)
      return 0.0 unless survey_responses.size.positive?
      (survey_responses.sum / survey_responses.size.to_f).to_s
    end

    def self.faculty_discussion_response_count(section)
      DiscussionComment.where(participatable_type: 'Faculty',
                              discussion: section.discussions).count
    end

    def self.coursework_feedback_count(section)
      StudentAssignment.where(assignment: section.assignments).where.not(feedback: nil).count +
        DiscussionParticipant.where(discussion: section.discussions).where.not(feedback: nil).count +
        QuizScore.where(quiz: section.quizzes).where.not(feedback: nil).count
    end

    def self.generate_average_survey_scores_report(term_ids = [])
      CSV.open("#{ENV['HOME']}/average_survey_scores_report.csv", 'wb') do |csv|
        csv << ['Section No.',
                'Section EMS ID',
                'Term',
                'Faculty',
                'Average Scores',
                'Answered Survey Questions',
                'Coursework Feedbacks',
                'Discussion Comment Responses',
                '# of Students']
        Section.where(term_id: term_ids).each do |section|
          next unless section.online?

          survey_responses = responses(section)

          csv << [
            section.course_and_section_no,
            section.id.to_s,
            section.term.display_name,
            section.faculty.map { |fa| fa.user.full_name }.join(' / '),
            response_average(survey_responses),
            survey_responses.size,
            coursework_feedback_count(section),
            faculty_discussion_response_count(section),
            section.students.count
          ]
        end
      end
    end

    def self.generate_survey_comments_report(term_ids = [])
      CSV.open("#{ENV['HOME']}/survey_comments_report.csv", 'wb') do |csv|
        csv << ['Section No.',
                'Section EMS ID',
                'Term',
                'Faculty',
                'Text Comment']
        Section.where(term_id: term_ids).each do |section|
          next unless section.online?

          survey_responses = responses(section, 'text_answer')
          survey_responses.each do |survey_response|
            csv << [
              section.course_and_section_no,
              section.id.to_s,
              section.term.display_name,
              section.faculty.map { |fa| fa.user.full_name }.join(' / '),
              survey_response.response.gsub(/\r\n?/, ' ')
            ]
          end
        end
      end
    end
  end
end
