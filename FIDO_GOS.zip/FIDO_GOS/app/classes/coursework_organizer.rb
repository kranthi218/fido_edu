# This class performs grunt work common to organizng coursework for display
class CourseworkOrganizer
  include ActionView::Helpers

  def initialize(section)
    @section = section

    @student_deadlines = StudentDeadline.for_section(@section)

    @org_strategy = if @section.points_grading? || !section.course_modules.empty?
                      section.course_modules.visible_to_students
                    else
                      section.grading_policies
                    end
    @jumbled_coursework = collect_coursework
  end

  def due_date(work, student)
    @student_deadlines.find do |deadline|
      (deadline.coursework == work) && (deadline.student == student)
    end.try(:ends_at) || work.ends_at
  end

  def type_label(thing_to_label)
    return 'Link' if @section.points_grading?
    return 'Lesson' if thing_to_label.is_a?(Lesson)

    grading_policy = @org_strategy.find do |policy|
      policy.id == thing_to_label.grading_policy_id
    end

    return grading_policy.name.singularize if grading_policy

    thing_to_label.class.to_s
  end

  def course_modules
    @org_strategy
  end

  def organization_strategy
    @org_strategy.first.class.name.to_s.titlecase
  end

  def present?
    !@jumbled_coursework.empty?
  end

  # Gathers the various elements of coursework students
  # are allowed to see right now, sort by date, and associate
  # with the correct assignment group.
  # For an example usage see student/sections/coursework.html.haml
  def for_visible_modules
    if @org_strategy.first.is_a?(CourseModule)
      organize_by_course_module
    else
      organize_by_grading_policy
    end
  end

  def collect_coursework(opts = {})
    coursework = @section.coursework
    coursework.map(&:content).select{ |c| c&.visible }&.sort_by(&:sortby_date)
  end

  def organize_by_grading_policy
    jumbled_coursework = @jumbled_coursework

    # find all type of course work for those modules, and sort by date
    coursework = {}

    # take date sorted coursework, and match it up with it's grading policy
    @org_strategy.each do |grp|
      partitioned = jumbled_coursework.partition do |c|
        c.grading_policy_id == grp.id if c.respond_to?(:grading_policy_id)
      end

      coursework[grp] = partitioned[0]
      jumbled_coursework = partitioned[1]

      break if jumbled_coursework.empty?
    end

    # Assignment groups are not required, so catch any work outside of one
    if jumbled_coursework.present?
      coursework[GradingPolicy.new(name: 'Ungrouped')] = jumbled_coursework
    end

    coursework
  end

  def organize_by_course_module
    jumbled_coursework = @jumbled_coursework
    coursework = {}

    # take date sorted coursework, and match it up with it's assignment group
    @org_strategy.each do |grp|
      partitioned = jumbled_coursework.partition do |c|
        c.course_module_id == grp.id
      end

      coursework[grp] = partitioned[0]
      jumbled_coursework = partitioned[1]

      break if jumbled_coursework.empty?
    end

    # Assignment groups are not required, so catch any work outside of one
    jumbled_coursework.reject! do |c|
      # remove invisibles
      c.course_module_id.present?
    end

    if jumbled_coursework.present?
      coursework[CourseModule.new(name: 'Ungrouped')] = jumbled_coursework
    end

    coursework
  end

  # This module gathers the various elements
  # of coursework irrespective of visibility
  def for_all_modules
    # find all type of course work for those modules, and sort by date
    jumbled_coursework = collect_coursework
    @coursework = {}

    # take date sorted coursework, and match it up with its assignment group
    @org_strategy.each do |grp|
      partitioned = jumbled_coursework.partition do |c|
        c.course_module_id == grp.id
      end

      @coursework[grp] = partitioned[0]
      jumbled_coursework = partitioned[1]

      break if jumbled_coursework.empty?
    end

    # Assignment groups are not required, so catch any work outside of one
    if jumbled_coursework.present?
      @coursework[CourseModule.new(name: 'Unsorted')] = jumbled_coursework
    end

    @coursework
  end

  def for_all_modules_without_lessons
    # find all type of course work for those modules, and sort by date
    jumbled_coursework = collect_coursework(include_lessons: false)
    @coursework = {}

    # take date sorted coursework, and match it up with its assignment group
    @org_strategy.each do |grp|
      partitioned = jumbled_coursework.partition do |c|
        c.course_module_id == grp.id
      end

      @coursework[grp] = partitioned[0]
      jumbled_coursework = partitioned[1]

      break if jumbled_coursework.empty?
    end

    # Assignment groups are not required, so catch any work outside of one
    if jumbled_coursework.present?
      @coursework[CourseModule.new(name: 'Unsorted')] = jumbled_coursework
    end

    @coursework
  end
end
