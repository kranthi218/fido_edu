class SubmissionCompiler
  def self.compile(dir_name, assignment_name, terms)
    root_dir = "#{ENV['HOME']}/#{dir_name}"
    terms.each do |term|
      compile_for_term(root_dir, assignment_name, term)
    end
    `cd ~;rm #{dir_name}.zip;zip -r #{dir_name}.zip #{dir_name} && rm -rf #{dir_name};cd -`
    puts "Zip file available at #{root_dir}.zip"
  end

  def self.compile_for_term(root_dir, assignment_name, term)
    term_dir = "#{root_dir}/#{term.id}-#{term.display_name.parameterize}"
    FileUtils.mkdir_p(term_dir)
    sections = Section.where(term: term)
    sections.each { |section| compile_for_section(term_dir, assignment_name, section) }
  end

  def self.compile_for_section(term_dir, assignment_name, section)
    coursework = Coursework.where(content: Assignment.where(title: assignment_name),
                                  courseworkable: section)
    section_dir = "#{term_dir}/#{section.id}-#{section.course_and_section_no.parameterize}"
    FileUtils.mkdir_p(section_dir) unless coursework.blank?
    coursework.each { |cw| compile_for_coursework(section_dir, cw) }
  end

  def self.compile_for_coursework(section_dir, coursework)
    coursework.content.student_assignments.each do |submission|
      save_submission_content(section_dir, submission)
      save_assets(section_dir, submission)
    end
  end

  def self.save_submission_content(section_dir, submission)
    return if submission.content.blank?
    open("#{file_prefix(section_dir, submission)}-assignment-content.pdf", 'wb') do |file|
      pdf = WickedPdf.new.pdf_from_string(submission.content)
      file << pdf
    end
  end

  def self.save_assets(section_dir, submission)
    submission.assets.each_with_index do |asset, i|
      save_asset(section_dir, submission, asset, i + 1)
    end
  end

  def self.save_asset(section_dir, submission, asset, position)
    open("#{section_dir}/#{submission.student.student_number}-#{submission.student.name.parameterize}-attachment-#{position}#{asset_extension(asset)}", 'wb') do |file|
      file << open(asset.url).read
    end
  rescue
    puts "#{asset.url} not found"
  end

  def self.file_prefix(section_dir, submission)
    "#{section_dir}/#{submission.student.student_number}-#{submission.student.name.parameterize}"
  end

  def self.asset_extension(asset)
    filename = asset.name
    extension = filename.split('.').last
    extension = ".#{extension}" unless extension.blank?
    extension
  end
end
