# This class was designed to prepare data for StudentRoster
class StudentRosterOrganizer
  attr_reader :section, :submissions, :coursework

  def initialize(section)
    @section     = section
    @coursework  = gather_coursework
    @submissions = gather_submissions
  end

  def student_submissions(student_id)
    submissions.select { |s| s.student_id == student_id }
  end

  def student_card(student_id)
    StudentCard.new(
      student_submissions(student_id),
      points_to_date
    )
  end

  def points_to_date
    @points_to_date ||=
      coursework.inject(0) do |sum, work|
        work.ends_at.try(:past?) ? sum + work.points : sum
      end
  end

  def student_ratio(student_id)
    "#{student_submissions(student_id).size} / #{coursework.size}"
  end

  private

  def gather_coursework
    section.assignments.active +
      section.discussions.active +
      section.quizzes.active
  end

  def gather_submissions
    collection =
      StudentAssignment.graded.includes(assignment: :section)
                       .where(assignment_id: section.assignments.active.gradable) +
      DiscussionParticipant.graded.includes(discussion: :section)
                           .where(discussion_id: section.discussions.active.gradable) +
      QuizScore.graded.includes(quiz: :section)
               .where(quiz_id: section.quizzes.active.gradable)

    collection.sort_by { |s| s.coursework.try(:ends_at) }
  end

  # Individual student card report
  class StudentCard
    # To use with serializer
    include ActionView::Helpers::NumberHelper
    alias read_attribute_for_serialization send

    attr_reader :student_submissions, :points_to_date

    def initialize(student_submissions, points_to_date)
      @student_submissions = student_submissions
      @points_to_date      = points_to_date
    end

    def results
      student_submissions.map do |submission|
        {
          title:  submission.coursework.title,
          points: submission.coursework.points,
          score:  submission.score,
          coursework_id:   submission.coursework.id,
          coursework_path: submission.coursework.class.table_name
        }
      end
    end

    def percentage
      return 0.0 if !points_to_date || points_to_date.zero?
      (points_earned_to_date * 100.0 / points_to_date).round(2)
    end

    def points_earned_to_date
      @points_earned_to_date ||=
        student_submissions.reduce(0) do |sum, work|
          work.graded? ? sum + work.score : sum
        end
    end
  end
end
