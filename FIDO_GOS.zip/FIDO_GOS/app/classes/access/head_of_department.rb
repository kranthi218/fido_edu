class Access::HeadOfDepartment < Access::AccessGroup




end
