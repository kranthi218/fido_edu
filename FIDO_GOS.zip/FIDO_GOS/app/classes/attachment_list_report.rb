class AttachmentListReport
  class Assignment
    def generate_report(assignment_ids = [])
      CSV.open("#{ENV['HOME']}/file_report.csv", 'wb') do |csv|
        csv << ['term_id', 'section', 'student name', 'attachment_url']
        ::Assignment.where(id: assignment_ids).map do |asn|
          asn.submissions.map do |sub|
            sub.assets.map do |ass|
              csv << csv_entry(asn, sub, ass)
            end
          end
        end
      end
    end

    def generate_file_list(assignment_ids = [])
      CSV.open("#{ENV['HOME']}/file_list.csv", 'wb') do |csv|
        ::Assignment.where(id: assignment_ids).map do |asn|
          asn.submissions.map do |sub|
            sub.assets.map do |ass|
              csv << [ass.attachment.url]
            end
          end
        end
      end
    end

    private

    def csv_entry(assignment, submission, asset)
      [
        assignment.section.term.id,
        assignment.section.course_and_section_no,
        assignment.section.term.id,
        submission.student.user.full_name,
        asset.attachment.url
      ]
    end
  end
end
