# Gather all students for a discussion, noting how many comments they have made
# in a format convenient for displaying in view
class DiscussionCommentCounter

  def initialize(discussion)
    @discussion = discussion
  end

  # Build a structure for conveniently displaying students along with their discussion participation counts.
  def students_and_comment_counts
    count = {}
    comments = @discussion.discussion_comments
    students.by_last_name.each do |student|
      count[student] = comments.select{|d| (d.participatable_type == 'Student' && d.participatable_id == student.id.to_s)}.size
    end
    count
  end

  # all students
  def students
    @discussion.section.students
  end

end
