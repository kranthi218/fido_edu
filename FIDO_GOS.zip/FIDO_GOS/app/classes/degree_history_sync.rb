class DegreeHistorySync
  attr_writer :logger
  STUDENT_RECORD_DOES_NOT_EXIST = 'Student record %s does not exist in EMS'.freeze

  def initialize
    yield(self) if block_given?
  end

  def sync!
    # We need to load this in batches..
    # looking for walk around
    batches = Ex::DegreeHistory.student_degree_histories

    batches.each do |ex_degree_history|
      user = User.find_by_janzebar_id(ex_degree_history.id_num)

      if user&.student
        create_or_update_degree_history(ex_degree_history, user.student)
      else
        logger.warn format(STUDENT_RECORD_DOES_NOT_EXIST, ex_degree_history.id_num)
      end
    end
  end

  def create_or_update_degree_history(ex_degree_history, student)
    concentration  = ex_degree_history.concentration.try(:strip)
    major          = ex_degree_history.major.try(:strip)
    degree_history = DegreeHistory.where(appid: ex_degree_history.appid).first

    degree_history ||= student.degree_histories.new

    degree_history.appid          = ex_degree_history.appid
    degree_history.major          = major
    degree_history.concentration  = concentration
    degree_history.active         = (ex_degree_history.active.try(:strip) == 'Y')
    degree_history.current_degree = (ex_degree_history.current_degree.try(:strip) == 'Y')
    degree_history.exit_reason    = ex_degree_history.exit_reason.try(:strip)
    degree_history.entry_date     = utc_as_local_to_local(ex_degree_history.entry_date) if ex_degree_history.entry_date
    degree_history.exit_date      = utc_as_local_to_local(ex_degree_history.exit_date) if ex_degree_history.exit_date
    degree_history.save
  end

  def utc_as_local_to_local(datetime)
    t = datetime.utc
    DateTime.new(t.year, t.month, t.day, t.hour, t.min, t.sec, Time.zone.now.formatted_offset)
  end

  private

  def logger
    @logger ||= Logger.new(STDOUT)
  end
end
