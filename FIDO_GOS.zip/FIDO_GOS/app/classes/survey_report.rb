class SurveyReport
  attr_reader :category,
              :section,
              :heading,
              :term

  def initialize(options = {})
    @surveys = surveys_for(options)
               .includes(section: %i[course department faculty])
               .includes(:survey_responses)

    @heading = heading_for(options, @surveys)
    @term = Term.find_by(id: options[:term_id]) || Term.recent

    if options[:survey_id].present?
      @section = @surveys.first.section
    elsif options[:section_id].present?
      @section = Section.find(options[:section_id])
    end

    @category = options[:category] if options[:category]
    @category = @section.category if @section

    @section_student_surveys =
      SectionStudentSurvey.joins(:section_student)
                          .where(survey: @surveys)
                          .where(section_students: { status: SectionStudent::ACTIVE_ENROLLMENTS })

    @config =
      YAML.load_file(Rails.root.join('config', 'survey_data_setup.yml'))
  end

  def data?
    @surveys.any? && @surveys.any? { |survey| survey.survey_responses.any? }
  end

  def faculty
    section.try(:faculty_names).try(:join, ', ')
  end

  def multiple_choice_questions
    questions
      .where(question_type: :multiple_choice)
      .group_by(&:description)
  end

  def comments
    questions
      .where(question_type: :text_answer)
      .group_by(&:description)
  end

  def completed
    @section_student_surveys.completed.count
  end

  def incomplete
    @section_student_surveys.incomplete.count
  end

  def rejected
    @section_student_surveys.rejected.count
  end

  def accessed
    completed + incomplete + rejected
  end

  def not_accessed
    student_count - accessed
  end

  def student_count
    @surveys.map { |survey| survey.section.student_count }.sum
  end

  def to_report(questions)
    with_answer_options(questions)
      .map { |k, v| [@config['options'][k.to_i], v] }
      .to_h
  end

  private

  def heading_for(options, surveys)
    if options[:survey_id].present? || options[:section_id].present?
      begin
        surveys.first.section.decorate.heading
      rescue StandardError
        ''
      end
    else
      begin
        surveys.first.section.department.name
      rescue StandardError
        ''
      end
    end
  end

  def surveys_for(options)
    if options[:survey_id].present?
      Survey.where(id: options[:survey_id])

    elsif options[:section_id].present?
      Survey.where(section_id: options[:section_id])

    else
      Survey.joins(:section)
            .where(sections: { department_id: options[:department_id] })
            .where(sections: { term_id:       options[:term_id] })
            .where(sections: { category:      options[:category].blank? ? Section::CATEGORY : options[:category] })
    end
  end

  def generate_report(question, report = {})
    survey_responses = question.survey_responses.group(:response).count
    question_choices = question.question_answers
                               .where(id: survey_responses.keys)

    question_choices.each do |question_choice|
      report[question_choice.choice.to_i] = survey_responses[question_choice.id.to_s]
    end
    report
  end

  def questions
    Question.where(questionable: @surveys.ids).descending
  end

  def with_answer_options(question)
    SurveyResponse.eager_load(question: :question_answers)
                  .where('question_answers.id = response and survey_responses.question_id IN (?)', question)
                  .group('question_answers.choice').count
  end
end
