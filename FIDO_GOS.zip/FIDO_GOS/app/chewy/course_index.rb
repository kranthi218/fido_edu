# frozen_string_literal: true

class CourseIndex < Chewy::Index
  settings analysis: {
    normalizer: {
      sort: {
        type: 'custom',
        token_filter: %w[trim],
        filter: %w[lowercase]
      }
    }
  }

  define_type Course.includes(:program) do
    field :name, type: 'text', analyzer: 'standard' do
      field :sort, type: 'keyword', normalizer: 'sort'
    end

    field :course_no, type: 'text', value: -> { course_no.downcase } do
      field :sort, type: 'keyword', normalizer: 'sort'
    end

    field :last_published_term, type: 'text' , value: -> { last_published_term&.id } do
      field :sort, type: 'keyword'
    end

    field :active, type: 'boolean' do
      field :sort, type: 'keyword'
    end

    field :program_id,    type: 'integer'
    field :department_id, type: 'integer'
    field :program_code, type: 'keyword',normalizer: 'sort', value: -> { program&.program_code } do
      field :sort, type: 'keyword', normalizer: 'sort'
    end

    field :clos_count, type: 'integer' do
      field :sort, type: 'keyword'
    end
  end
end
