# frozen_string_literal: true

class TermEnrollmentIndex < Chewy::Index
  settings analysis: {
    normalizer: {
      sort: {
        type: 'custom',
        token_filter: %w[trim],
        filter: %w[lowercase]
      }
    }
  }

  define_type TermEnrollment.includes(:section_students, student: [:user]) do
    field :status,         type: 'keyword'
    field :student_id,     type: 'keyword'
    field :term_id,        type: 'integer'

    field :ranking_number, type: 'float' do
      field :sort, type: 'keyword'
    end

    field :department_id, type: 'integer', value: -> { sections.map(&:department_id).uniq }

    field :student do
      field :user do
        field :janzebar_id, type: 'keyword' do
          field :sort, type: 'keyword'
        end
        field :full_name, type: 'text' do
          field :sort, type: 'keyword', normalizer: 'sort'
        end
        field :email, type: 'keyword' do
          field :sort, type: 'keyword', normalizer: 'sort'
        end
      end
    end
  end
end
