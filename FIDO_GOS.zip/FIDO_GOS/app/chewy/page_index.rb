class PageIndex < Chewy::Index
  settings analysis: {
    filter: {
      edge_ngram: {
        type: 'nGram',
        min_gram: 3,
        max_gram: 20
      }
    },
    analyzer: {
      title: {
        type: 'custom',
        tokenizer: 'standard',
        filter: %w(lowercase asciifolding edge_ngram)
      },
      sort: {
        type: 'custom',
        tokenizer: 'keyword',
        filter: %w(trim lowercase)
      },
      lowercase: {
        tokenizer: 'keyword',
        filter: %w(lowercase)
      }
    }
  }

  define_type Page.includes(:roles, :categories) do
    field :title, type: 'text', analyzer: 'title'
    field :content, type: 'text'
    field :categories,
          analyzer: 'lowercase',
          value: -> { categories.map(&:name) }
    field :roles, analyzer: 'lowercase', value: -> { roles.map(&:name) }
    field :active, type: 'boolean'
    field :parent_id, type: 'integer'
  end
end
