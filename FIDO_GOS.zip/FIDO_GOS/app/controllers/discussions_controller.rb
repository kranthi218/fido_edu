# This controller handles the viewing and submission
# of an individual Discussion.
class DiscussionsController < ApplicationController
  attribute_view_helpers %i[
    discussion comment new_comment
    unread_discussion_comments
    read_discussion_comment_ids unread_discussion_comment_ids
  ]

  before_action do
    @discussion = Discussion.includes(:discussion_comments, section: :faculty)
      .find(params[:id])

    @reader = DiscussionCommentReader.new(current_user, @discussion)
    @read_discussion_comment_ids = @reader.read_discussion_comment_ids
    @unread_discussion_comment_ids = unread_comments

    if params[:discussion_comment_id].present?
      @comment = @discussion.discussion_comments.find(params[:discussion_comment_id])
    end
    @faculty_users = @discussion.faculty_users
  end

  before_action :faculty_breadcrumbs, if: :faculty_of_discussion?
  before_action :student_breadcrumbs, if: :student_of_discussion?

  def show
    authorize @discussion

    @new_comment = build_discussion_comment
  end

  def update
    respond_to do |format|

      format.html do
        @new_comment = build_discussion_comment
        @new_comment.content = params[:discussion_comment][:content]

        authorize @new_comment

        if @new_comment.save
          redirect_to comment_discussion_path(@discussion, @new_comment),
                      notice: 'You have successfully posted a response'
        else
          render :show
        end
      end

      format.json do

        authorize @comment

        if @comment.update_attributes(discussion_params)
          render json: { success: true }
        else
          render json: { errors: @comment.errors.full_messages }, status: 422
        end
      end
    end
  end

  def delete
    authorize @comment

    subtree_ids = @comment.subtree_ids
    if @comment.destroy
      render json: { success: true, subtree_ids: subtree_ids }
    else
      render json: { errors: @comment.errors.full_messages }, status: 422
    end
  end

  def unread
    authorize @discussion
    add_breadcrumb 'Unread Comments'
    @unread_discussion_comments = @discussion.discussion_comments
      .where(id: @unread_discussion_comment_ids)
      .order('created_at desc')
  end

  def read_comment
    authorize @discussion

    @reader.read_comment! @comment
    @read_discussion_comment_ids = @reader.read_discussion_comment_ids

    respond_to do |format|
      format.html do
        redirect_to comment_discussion_path(@discussion, @comment)
      end

      format.js do
        html = render_to_string(
          partial: 'discussion_comment_reader_form',
          layout: false,
          locals: { discussion: @discussion, discussion_comment: @comment, read: true }
        )
        render json: { html: html, read: true }
      end
    end
  end

  def unread_comment
    authorize @discussion

    @reader.unread_comment! @comment
    @read_discussion_comment_ids = @reader.read_discussion_comment_ids

    respond_to do |format|
      format.html do
        redirect_to comment_discussion_path(@discussion, @comment)
      end

      format.js do
        html = render_to_string(
          partial: 'discussion_comment_reader_form',
          layout: false,
          locals: { discussion: @discussion, discussion_comment: @comment, read: false }
        )
        render json: { html: html, read: false }
      end
    end
  end

  protected

  # Return a relation containing all unread comments that were not
  # authored by the current user.
  # Moved method to the model, so it could be used in other places
  def unread_comments
    @discussion.unread_comments(current_user, @read_discussion_comment_ids)
  end

  # Returns true if the current user is a faculty
  # of the section of the loaded discussion.
  def faculty_of_discussion?
    @faculty ||= FacultyWrapper.new(current_user)
    @faculty_of_discussion ||= @faculty.of?(@discussion.section)
  end
  helper_method :faculty_of_discussion?

  # Returns true if the current user is student
  # of the section of the loaded discussion.
  def student_of_discussion?
    @student ||= StudentWrapper.new(current_user)
    @student_of_discussion ||= @student.of?(@discussion.section)
  end
  helper_method :student_of_discussion?

  # Determine if we're commenting on a discussion or on a topic
  # of a discussion and return the relevant discussion_comment association.
  def discussion_comment_association
    @comment.present? ? @comment.children : @discussion.visible_discussion_comments
  end

  # Determine the correct user role to use
  # when setting DiscussionComment#participatable.
  def participant
    student_of_discussion? ? current_user.student : current_user.faculty
  end

  # Build a new instance of a discussion comment for the currently loaded
  # discussion. This also sets the author as the current user and calculates
  # the correct assocation to use for the discussion's participatable type/id
  def build_discussion_comment
    discussion_comment_association.build do |dc|
      dc.user_id = current_user.id
      dc.discussion_id = discussion.id
      dc.participatable = participant
    end
  end

  def student_breadcrumbs
    return if faculty_of_discussion?
    add_breadcrumb 'Student Dashboard', :student_dashboard_path
    add_breadcrumb @discussion.section.course_and_section_no,
                   student_section_path(@discussion.section)
    add_breadcrumb 'Coursework',
                   coursework_student_section_path(@discussion.section)
    add_breadcrumb 'Discussions',
                   student_section_discussions_path(@discussion.section)
    add_breadcrumb @discussion.topic.truncate(18), :discussion_path
  end

  def faculty_breadcrumbs
    add_breadcrumb 'Faculty Dashboard', '/app/#/faculty'
    add_breadcrumb @discussion.section.course_and_section_no
    add_breadcrumb @discussion.decorate.breadcrumb_title, :discussion_path
  end

  private

  def discussion_params
    params.require(:discussion_comment).permit(:content)
  end
end
