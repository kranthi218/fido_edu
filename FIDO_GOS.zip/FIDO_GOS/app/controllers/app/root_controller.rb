# Controller for new EMS App
class App::RootController < ApplicationController
  layout false

  def index
  end
end
