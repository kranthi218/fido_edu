class StaticPagesController < ApplicationController
  def release_status
  end
end
