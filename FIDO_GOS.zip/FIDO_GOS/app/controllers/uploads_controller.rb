class UploadsController < ActionController::Base
  include MailerHelper

  def index
    @assets = current_user.assets.images.recent
  end

  def create
    assets = create_array(params[:file])
    render(json: json_hash(assets), status: :ok)
  end

  private

  def create_single(file)
    current_user.assets.create(attachment: file)
  end

  def create_array(files)
    files.map do |file|
      create_single file
    end
  end

  def json_hash(assets)
    {
      files: assets.map do |asset|
        {
          url: asset.url,
          id: asset.id.to_s,
          name: asset.attachment_file_name
        }
      end
    }
  end
end
