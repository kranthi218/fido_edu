class AccountConfirmationController < ApplicationController

  # require_no_user

  def index
    @confirmed_user = User.find_and_confirm params[:confirmation_code]

    if @confirmed_user.valid?
      flash[:notice] = t("authorization.account_confirmation.success")
      login_as @confirmed_user
      redirect_to root_url
    else
      flash[:error] = t("authorization.account_confirmation.failure")
      redirect_to new_account_url
    end
  end

  protected

  def login_as(user)
    UserSession.create user
  end
end
