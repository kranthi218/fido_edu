class Student::SurveysController < Student::StudentController
  before_action only: %i(show update reject_survey remind_later) do
    @section = Section.find(params[:section_id])
    apply_survey_breadcrumbs(@section)

    @survey = @section.surveys.find(params[:id])
    authorize @survey, :show?

    @sect_st_survey = find_or_initialize_sect_st_survey(
      @section,
      current_user.student.id,
      @survey.id
    )
    @status = survey_taken(@sect_st_survey)
  end

  def show
    if @status.present?
      render 'student/surveys/success'
      nil
    end
  end

  # update method accepts a hash containing a survey_id
  # and surevy_answers where the key to the answers is the
  # surevy_question_id.
  # @example Example input
  #   {
  #     "2222" => { "survey_answers" => "3333" }, for single choice answer
  #     "4444" => { "survey_answers" => ["5555", "6666"] } for mutiple_answer
  #   }
  #
  # 2222 is the id of a survey question that belongs to survey 1111,
  # and 3333 is the student response.
  def update
    # did to_h as from rails 5, it return parameter object and not hash
    responses = params[:survey] ? survey_params.to_h : {}
    complete = true
    responses.each do |k, v|
      # skip question if text_answer
      next if Question.find(k).question_type == 'text_answer'
      # check that all multiple choice questions have answers
      complete = false if v['survey_answers'].empty?
    end
    responses.reject! { |_k, v| v['survey_answers'].empty? }
    if @status.present?
      render 'student/surveys/success'
    elsif complete
      create_survey_response(@survey.id, responses) if responses.present?

      @sect_st_survey.update(
        survey_status: SectionStudentSurvey::SURVEY_COMPLETED
      )

      @status = t('controllers.student.surveys.survey_submitted')
      render 'student/surveys/success'
    else
      @error = 'Please answer all questions.'
      render :show
    end
  end

  # AJAX call
  def reject_survey
    unless @status.present?

      @sect_st_survey.update(
        survey_status: SectionStudentSurvey::SURVEY_REJECTED
      )

    end
    head :ok
  end

  # AJAX call
  def remind_later
    unless @status.present?
      @sect_st_survey.remind_later = Time.current + 1.day
      @sect_st_survey.save
    end
    head :ok
  end

  attr_reader :survey
  helper_method :survey

  private

  def apply_survey_breadcrumbs(section)
    add_breadcrumb 'Student Dashboard', :student_dashboard_path
    add_breadcrumb section.course_and_section_no, student_section_path(section)
    add_breadcrumb 'Survey'
  end

  def find_or_initialize_sect_st_survey(section, student_id, survey_id)
    sect_st = section.section_students.find_by(
      student_id: student_id
    )
    sect_st.section_student_surveys
           .find_or_initialize_by(survey_id: survey_id)
  end

  def create_survey_response(survey_id, responses)
    responses.each do |response|
      survey_response = SurveyResponse.new(
        survey_id: survey_id,
        question_id: response[0],
        response: response[1][:survey_answers]
      )
      survey_response.save
    end
  end

  def survey_taken(sect_st_survey)
    return unless sect_st_survey.survey_status ==
                  SectionStudentSurvey::SURVEY_COMPLETED

    t('controllers.student.surveys.survey_taken')
  end

  def survey_params
    # dirty hack, ut will work for now
    # we are passing dynamic keys to hash which is not good
    ##   {
    #     "2222" => { "survey_answers" => "3333" }, for single choice answer
    #     "4444" => { "survey_answers" => ["5555", "6666"] } for mutiple_answer
    #   }
    # we need to improve our data structure
    params.require(:survey).permit!
  end
end
