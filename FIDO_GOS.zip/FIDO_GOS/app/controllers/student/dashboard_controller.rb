# The Student Dashboard gives students a high-level overview
# of all activity and assignments within all of that student's
# courses.
class Student::DashboardController < Student::StudentController
  add_breadcrumb('Student Dashboard')

  before_action :find_term, only: [:show]
  before_action :find_surveys, only: [:show, :remind_later]

  attribute_view_helpers %w(
    activities
    announcements
    broadcasts
    section_students
    term
    calendar
  )

  def show
    @activities         = collect_activities_for_student
    @announcements      = collect_announcements_for_student
    @broadcasts         = Broadcast.current.recent
    @calendar           = Calendar.find_or_create_by(user_id: current_user)
    @hide_survey_modal  = @student.user.faculty.present? ||
        @section_surveys.select{|ss| ss.remind_later && ss.remind_later > Time.zone.now}.any?

  end

  def remind_later
    @section_surveys.each do |section_survey|
      section_survey.remind_later = Time.current + 15.minutes
      section_survey.save!
    end

    @section_surveys
  end

  private

  def find_term
    @term = if params[:term_id].present?
              Term.find(params[:term_id])
            elsif DefaultSetting['term.default_term_id']
              Term.find(DefaultSetting['term.default_term_id'])
            else
              Term.current
            end
  end

  def find_surveys
    @section_surveys = collect_section_surveys_for_student
  end

  def collect_activities_for_student
    Activity.collect_activities_for_user(
      @student
    ).limit(30)
  end

  def collect_announcements_for_student
    current_sections = @student.sections.where(
      term_id: [Term.current.id, Term.upcoming.last&.id])

    Announcement.where(
      announcable_type: 'Section',
      announcable_id: current_sections.pluck(:id)
    ).published.recent.limit(50)
  end

  def collect_section_surveys_for_student
    return [] unless @student && @student.section_students
    @student.section_students.where(status: SectionStudent::VISIBLE_STATUSES)
            .select { |ss| ss.section.surveys_open? }
            .map { |ss| ss.section_student_surveys.incomplete_rejected }
            .flatten.compact
  end
end
