class Student::StudentController < ApplicationController
  include VerifyRole

  layout 'student'

  before_action :authenticate_user!

  before_action do
    @student = StudentWrapper.new(current_user)

    authorize :student, :access?
  end

  protected

  def validate_coursework_availability(coursework)
    return unless coursework.upcoming?
    render 'student/shared/not_available', locals: { work: coursework }
  end

  def validate_student_account(term)
    return unless current_user.student.account_on_hold? && term != Term.current
    render 'student/shared/account_on_hold'
  end

  def apply_generic_coursework_breadcrumbs
    add_breadcrumb 'Student Dashboard', :student_dashboard_path
    add_breadcrumb @section.course_and_section_no,
                   student_section_path(@section)
    add_breadcrumb 'Coursework',
                   coursework_student_section_path(@section)
  end
end
