class Student::LessonsController < Student::StudentController
  before_action do
    authorize_and_load_section
    apply_generic_coursework_breadcrumbs
  end

  def index
    add_breadcrumb 'Lessons'

    @lessons =
    LessonPolicy::Scope.new(current_user, Lesson, @section).resolve
  end

  def show
    @lesson = @section.lessons.find(params[:id])
    validate_coursework_availability @lesson
    add_breadcrumb @lesson.title
    authorize @lesson
  end

  private

  attr_reader :lesson
  helper_method :lesson
end
