# The Student::AssignmentsController is responsible for allowing
# students to display assignments and submit assignment submissions.
class Student::AssignmentsController < Student::StudentController
  attribute_view_helper :assignment

  before_action do
    authorize_and_load_section
    apply_generic_coursework_breadcrumbs
  end

  before_action only: [:show, :submit] do
    @assignment = @section.assignments.find(params[:id])
    find_or_initialize_student_assignment
    validate_coursework_availability @assignment
    add_breadcrumb @assignment.title
  end

  def index
    add_breadcrumb 'Assignments'

    @assignments =
      AssignmentPolicy::Scope.new(current_user, Assignment, @section).resolve
  end

  def show
    authorize @assignment
  end

  def submit
    @student_assignment.assign_attributes(student_assignment_params)

    authorize @student_assignment

    if save
      action_str = publishing? ? 'published' : 'submitted'
      redirect_to coursework_student_section_path(@section),
                  notice: "#{@assignment.title} has been #{action_str}"
    else
      flash.now[:error] = 'Please correct your errors and try again'
      render :show
    end
  end

  private

  def save
    @student_assignment.submitted_at = Time.current

    return false unless @student_assignment.save

    @student_assignment.publish! if publishing?
    create_student_assignment_activity @student_assignment, @section

    true
  end

  def find_or_initialize_student_assignment
    @student_assignment = StudentAssignment.where(
      student_id: @student.id,
      assignment_id: @assignment.try(:id)
    ).first_or_initialize do |submission|
      submission.section    = @section
      submission.student_id = @student.id
      submission.assignment = @assignment
    end
  end

  def create_student_assignment_activity(student_assignment, section)
    section.faculty.each do |faculty|
      student_assignment.create_activity(
        :create, activity_params(faculty, section, student_assignment)
      )
    end
  end

  def activity_params(faculty, section, student_assignment)
    {
      owner: section,
      recipient: faculty,
      parameters: {
        title: student_assignment.assignment.title,
        section: section.course_and_section_no
      }
    }
  end

  def student_assignment_params
    params.require(:student_assignment).permit(:content, assets: [])
  end

  def publishing?
    params.keys.include? 'publish'
  end
end
