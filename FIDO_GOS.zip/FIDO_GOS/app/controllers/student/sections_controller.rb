# The Student::SectionsController manages the logic for all the pages
# displaying information about an individual section in the context
# of a student.
class Student::SectionsController < Student::StudentController
  layout 'student/sections'
  add_breadcrumb 'Student Dashboard', :student_dashboard_path

  before_action except: :index do
    authorize_and_load_section
  end

  before_action except: [:index, :show] do
    add_breadcrumb @section.course_and_section_no,
                   student_section_path
  end

  before_action only: :gradebook do
    validate_student_account @section.term
  end

  # student survey
  before_action only: [:activity_feed] do
    sect_st = SectionStudent.find_by(
      section_id: @section.id,
      student_id: current_user.student.try(:id))

    if sect_st.present? && @section.surveys_open? && section.surveys.any?
      @surveys = student_incomplete_surveys(sect_st.section_student_surveys)
    end
  end

  def index
    redirect_to student_dashboard_path
  end

  def show
    redirect_to action: :activity_feed
  end

  def activity_feed
    add_breadcrumb 'Activity Feed'
    @activities = Activity.for_user_or_section(@student, @section.id)
    @announcements = Announcement.where(
      announcable_type: 'Section', announcable_id: @section.id
    ).published.recent

    render layout: !pjax?
  end

  def coursework
    add_breadcrumb 'Coursework'
    # figure out which course modules are visible to the students
    @coursework = CourseworkOrganizer.new @section

    # Gather submitted work for the student
    @submitted_work = SubmittedWorkOrganizer.new @section, @student
    render layout: !pjax?
  end

  def syllabus
    add_breadcrumb 'Syllabus'

    @coursework_timeline =
      CourseworkTimeline.new(@section).group_courseworks_by_milestones

    respond_to do |format|
      format.html { render layout: !pjax? }
      format.pdf do
        if stale?(etag: @section, last_modified: @section.updated_at.utc,
                  public: true)

          render pdf: format('%s - Syllabus', @section.name),
                 template: 'shared/sections/syllabus',
                 layout: 'layouts/pdf.html.haml',
                 show_as_html: params[:html],
                 locals: { coursework_timeline: @coursework_timeline }
        end
      end
    end
  end

  def resources
    add_breadcrumb 'Course Resources'
    @course_resources = section.course_resources

    render layout: !pjax?
  end

  def lessons
    render layout: !pjax?
  end

  def discussions
    render layout: !pjax?
  end

  def gradebook
    add_breadcrumb 'Gradebook'

    @gradebook = StudentGradebook.new(@section, @student)

    render layout: !pjax?
  end

  def student_incomplete_surveys(sect_st_surveys)
    if sect_st_surveys.present?
      survey_ids = @section.surveys.pluck(:id)
      accessed_survey_ids = sect_st_surveys.accessed.pluck(:survey_id)
      survey_ids.reject! do |survey_id|
        accessed_survey_ids.include? survey_id
      end
      return @section.surveys.where(id: survey_ids)
    end
    # return all the surveys of section when sect_st_surveys are
    # not present
    @section.surveys
  end

  attribute_view_helpers %w(
    activities
    announcements
    section
    section_students
    sections
    term
  )
end
