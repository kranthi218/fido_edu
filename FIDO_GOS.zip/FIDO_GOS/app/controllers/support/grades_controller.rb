class Support::GradesController < Support::SupportController
  before_action do
    @sect_st = SectionStudent.find(params[:id])
    @sch     = Ex::StudentCourseHistory.where(
      id_num:  @sect_st.student.student_number.strip,
      trm_cde: @sect_st.term.janzebar_term,
      yr_cde:  @sect_st.term.janzebar_year,
      crs_cde: @sect_st.section.ex_course_code,
      transaction_sts: %w(C H)
    ).first

    if @sch.blank?
      redirect_to support_user_path(@sect_st.student.user),
                  notice: 'Grade cannot be updated. Student Course History does not exist.'
    end
  end

  def edit; end

  def update
    # Update EMS grade and disable the pushing of grade to Ex for now.
    # @gs = GradeSync.new
    @sect_st.assign_attributes(section_student_params)
    update_section_student_status(@sect_st)

    # if @gs.sync_user(@sect_st)

    if @sect_st.save
      redirect_to support_user_path(@sect_st.student.user),
                  notice: 'Grade has been successfully updated'

    else
      redirect_to edit_support_grade_path(@sect_st),
                  notice: 'Grade cannot be updated. Please try again.'
    end
  end

  private

  def update_section_student_status(sect_st)
    return if sect_st.status == 'faculty'

    sect_st.status = if sect_st.grade.present?
                       sect_st.grade.withdrawn? ? 'withdrawn' : 'graded'
                     else
                       'enrolled'
                     end
  end

  def section_student_params
    params.require(:section_student).permit(:grade_id, :feedback)
  end
end
