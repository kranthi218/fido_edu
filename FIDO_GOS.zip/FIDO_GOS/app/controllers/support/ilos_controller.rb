class Support::IlosController < Support::SupportController
  before_action :find_term, only: %i[index publish]

  def create
    @ilo = Ilo.new(ilo_params)
    if @ilo.save
      flash[:notice] = 'Ilo has been successfully added'
      redirect_to support_ilos_path
    else
      render :new
    end
  end

  def edit
    @ilo = Ilo.find(params[:id]).decorate
  end

  def index
    @ilos = if @term.ilos_published?
              Ilo.where(id: IloTerm.where(term: @term)
                 .pluck(:ilo_id)).active_recent_order
            else
              Ilo.active_recent_order
            end
  end

  def new
    @ilo = Ilo.new
  end

  def update
    @ilo = Ilo.find(params[:id])
    if @ilo.update_attributes(ilo_params)
      flash[:notice] = 'Ilo has been successfully updated'
      redirect_to support_ilos_path
    else
      render :edit
    end
  end

  def publish
    @term.publish_ilos!
    flash[:notice] = "Ilos successfully published for #{@term.display_name}"
    redirect_to support_ilos_path
  end

  private

  def ilo_params
    params.require(:ilo).permit(:description, :active)
  end

  def term_id
    term_params = params[:term]
    return if term_params.blank?
    term_params.permit(:id)['id']
  end

  def find_term
    @term = term_id ? Term.find(term_id) : Term.last
  end
end
