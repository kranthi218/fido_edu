# This is a special controller that lets our support staff investigate
# errors. Breaking the pattern of inheriting from the parent controller
# is intentional, as the destroy action is by definition done by a regular
# user.
class Support::SignInAsController < ApplicationController

  before_action only: [:create] do
    authorize(:support, :access?)
  end

  def create
    user = User.find(params[:id])
    session[:current_admin_user_id] = current_user.id #
    sign_in(user, bypass: true)
    redirect_to root_path, notice: "Successfully logged in as #{user.full_name}"
  end

  # current_admin_user? is defined on application controller, and simply checks
  # if an admin session is in process.
  def destroy
    if current_admin_user?
      @admin = current_admin_user
      sign_in(@admin)
      session[:current_admin_user_id] = nil
      redirect_to root_path, notice: "Successfully logged in as admin [#{@admin.full_name}]"
    else
      sign_out(current_user)
      redirect_to root_path, notice: "Something is going wrong, please log in again"
    end
  end
end
