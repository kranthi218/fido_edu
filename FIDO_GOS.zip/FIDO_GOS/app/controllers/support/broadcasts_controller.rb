class Support::BroadcastsController < Support::SupportController

  def new
    @broadcast = Broadcast.new
  end

  def create
    @broadcast = Broadcast.new broadcast_params.merge({creator_id: current_user.id})
    if @broadcast.save
      redirect_to support_broadcasts_path, notice: "Broadcast created."
    else
      render 'new', notice: 'An error occurred'
    end
  end

  def update
    @broadcast = Broadcast.find(params[:id])

    if @broadcast.update_attributes(broadcast_params.merge(creator_id: current_user.id))
      redirect_to support_broadcasts_path, notice: "Broadcast updated."
    else
      render 'edit', alert: 'An error occurred'
    end
  end

  def edit
    @broadcast = Broadcast.find(params[:id])
  end

  def index
    @broadcasts = Broadcast.recent
  end

  def show
    @broadcast = Broadcast.find(params[:id])
  end

  private

  def broadcast_params
     params.require(:broadcast).permit(:title, :content,:published_at)
  end
end
