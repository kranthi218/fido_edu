class Support::PageCategoriesController < Support::SupportController
  before_action :set_page_category, only: [:show, :edit, :update, :destroy]

  def index
    @page_categories = PageCategory.all
  end

  def show
    @pages = @page_category.pages.page(params[:page])
  end

  def new
    @page_category = PageCategory.new
  end

  def edit
  end

  def create
    @page_category = PageCategory.new(page_params)
    if @page_category.save
      redirect_to support_page_categories_path, notice: 'PageCategory was successfully created.'
    else
      render :new
    end
  end

  def update
    if @page_category.update(page_params)
      redirect_to support_page_categories_path, notice: 'PageCategory was successfully updated.'
    else
      render :edit
    end
  end

  def destroy
    @page_category.destroy
    redirect_to support_page_categories_path, notice: 'PageCategory was successfully destroyed.'
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_page_category
    @page_category = PageCategory.find(params[:id])
  end

  # Only allow a trusted parameter "white list" through.
  def page_params
    params.require(:page_category).permit(:title, :active)
  end
end
