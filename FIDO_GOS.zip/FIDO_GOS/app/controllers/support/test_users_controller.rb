class Support::TestUsersController < Support::SupportController
  add_breadcrumb 'Test Users', :support_test_users_path

  # An instance of `ActiveSupport::MessageVerifier` used to safely pass around
  # result data through multiple HTTP requests
  VERIFIER = ActiveSupport::MessageVerifier.new(
    Rails.application.secrets[:secret_key_base]
  )

  def index
  end

  def create
    @data, @encrypted_data = verify_or_generate_test_data!(data_params)

    respond_to do |format|
      format.html { render :index }
      format.js { render json: @data }
      format.csv do
        add_test_data_csv_response_headers(response)
        render text: array_of_hashes_as_csv(@data)
      end
    end
  end

  private

  def data_params
    params.fetch(:data, nil)
  end

  # The the filename of the response when downloading the response content
  # as a CSV
  #
  # @param [ActionDispatch::Response] resp the response object to modify
  # @return [ActionDispatch::Response] the modified response object
  def add_test_data_csv_response_headers(resp)
    resp.headers['Content-Disposition'] = format(
      'attachment; filename="%{filename}"',
      filename: format('test_users.%s.csv', Time.now.to_formatted_s(:number))
    )

    resp
  end

  # Given an array of hashes that all share the same set of keys,
  # generate a CSV string where the columns are named after the hash
  # keys and the values of each row correspnd with the values of each hash
  #
  # @param data [Array<Hash>] input data
  # @return [String] a CSV representation of the input data
  def array_of_hashes_as_csv(data)
    CSV.generate do |csv|
      csv << data.first.keys
      data.each { |hash| csv << hash.values }
    end
  end

  # Given a serialized method from `ActiveSupport::MessageVerifier`,
  # verify the encoded data or generate new test data if the encoded
  # message is empty or invalid
  #
  # @params data [String] an encrypted message generated
  #   by `ActiveSupport::MessageVerifier`
  # @return [Array<Hash, String>] Returns an array containing a hash of data
  #   and an encrypted string that may be passed to
  #   `ActiveSupport::MessageVerifier` to regenerate that data
  def verify_or_generate_test_data!(data)
    if data
      encrypted_data = data
      data = VERIFIER.verify(data)
    else
      data = TestData.generate_section
      encrypted_data = VERIFIER.generate(data)
    end

    [data, encrypted_data]
  end
end
