class Support::StudentcourseworksController < Support::SupportController
  before_action :student_details, only: [:sections, :search, :coursework_titles]

  COURSEWORK_TYPES = %w(Assignment Discussion Quiz)

  def index
  end

  #returns a json of student enrolled courses
  def sections
    section_list = enrolled_sections(@student, params[:term])
    if section_list.present?
      render json: section_list.map{|s| {id: s.id, name: "#{s.course_and_section_no} - #{s.name}"}}.as_json
    else
      render partial: "layouts/flash", locals: { flash: { error: "No sections found for the student id" } }
    end

  end

  # returns a json of coursework titles
  def coursework_titles
    section = Section.find_by_id(params[:section_id])
    if params[:coursework_type] == COURSEWORK_TYPES[0]
      coursework_titles = assignment_titles(section)
    elsif params[:coursework_type] == COURSEWORK_TYPES[1]
      coursework_titles = discussion_titles(section)
    elsif params[:coursework_type] == COURSEWORK_TYPES[2]
      coursework_titles = quiz_titles(section)
    end
      coursework_titles.present? ? (render json: coursework_titles) :
      (render partial: "layouts/flash", locals: { flash: { error: "No coursework available" } })
  end

  # returns a student coursework details
  def search
    if params[:coursework_type] == COURSEWORK_TYPES[0]
      @coursework_details = StudentAssignment.includes(:assets).where(student_id: @student.id,
                              assignment_id: params[:coursework_title])
      render layout: false, partial: 'support/studentcourseworks/student_assignments'

    elsif params[:coursework_type] == COURSEWORK_TYPES[1]
       @coursework_details = DiscussionComment.includes(:assets).where(user_id: @user.id,
                              discussion_id: params[:coursework_title])
       render layout: false, partial: 'support/studentcourseworks/student_discussions'

    elsif params[:coursework_type] == COURSEWORK_TYPES[2]
      @coursework_details = QuizScore.where(student_id: @student.id, quiz_id: params[:coursework_title])
      render layout: false, partial: 'support/studentcourseworks/student_quizzes'
    else
      render partial: 'layouts/flash',
             locals: { flash: { error: 'Please select Coursework Type' } }
    end
  end

  private

  def enrolled_sections(student, term_id)
    return nil unless student
    Section.where(term_id: term_id, id: SectionStudent.where(student: student).map(&:section_id))
  end

  def assignment_titles(section)
    # assignments =  Assignment.where(section_id: @section_id, visible: true)
    assignments = section&.assignments
    assignments.as_json(only: [:id, :title]) if assignments
  end

  def discussion_titles(section)
    # discussions = Discussion.where(section_id: section_id, visible: true) # section.discussions
    discussions = section&.discussions
    discussions.as_json(only: [:id, :topic]) if discussions
  end

  def quiz_titles(section)
    quizzes = section&.quizzes
    # quizzes =  Quiz.where(section_id: @section_id, visible: true)
    quizzes.as_json(only: [:id, :title]) if quizzes
  end

  def discussion_score
    @score =
      DiscussionParticipant.where(student_id: @student.id,
                                  discussion_id: params[:coursework_title])
                           .pluck(:score).first
  end

  def student_details
    @user = User.where(janzebar_id: params[:janzebar_id]).first
    if @user
      @student = @user.student
    else
      render partial: "layouts/flash", locals: { flash: { error: "No student found for janzebar id #{params[:janzebar_id]}" } }
    end
  end
end
