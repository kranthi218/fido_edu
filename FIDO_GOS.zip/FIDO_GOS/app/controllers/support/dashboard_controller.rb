class Support::DashboardController < Support::SupportController
  def show
    # Default dashboard pane
    redirect_to controller: 'support/users', action: :index
  end
end
