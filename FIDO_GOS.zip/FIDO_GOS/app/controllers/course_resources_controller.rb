class CourseResourcesController < ApplicationController

  def show
    @resource = CourseResource.find params[:id]
    render layout: false
  end

end
