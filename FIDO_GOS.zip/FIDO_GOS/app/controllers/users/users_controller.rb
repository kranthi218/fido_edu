class UsersController < ApplicationController

	def profile
	end

end

