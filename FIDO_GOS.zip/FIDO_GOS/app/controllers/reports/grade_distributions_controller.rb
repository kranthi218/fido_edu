class Reports::GradeDistributionsController < Reports::ReportsController
  CLO_LEVELS = ['Initial', 'Emerging', 'Developed', 'Highly Developed']

  layout 'reports/grade_distributions'

  add_breadcrumb 'Reporting Dashboard', :reports_dashboard_path
  add_breadcrumb 'Grade Distribution Report', :reports_grade_distributions_path

  before_action do
    authorize(:grade_distribution, :access?)
  end

  before_action only: :index do
    if report_params[:id]
      redirect_to reports_grade_distribution_path(report_params[:id])
    end
  end

  before_action except: :index do
    @section = Section.find params.require(:id)
    add_breadcrumb @section.course_and_section_no
  end

  def index
    if params[:department_id]
      sections = Section
        .joins(:course)
        .where(
          term_id: params[:term_id],
          courses: { department_id: params[:department_id] }
        )

      data = sections.each_with_object({}) do |section, h|
        h[section.id] = section.report_selection_label
        h
      end

      render json: data

    elsif params[:term_id]
      ids = Section
        .joins(:course)
        .where(term_id: params[:term_id])
        .pluck('courses.department_id')
        .uniq

      data = Department.where(id: ids).each_with_object({}) do |department, h|
        h[department.id] = department.display_name
        h
      end

      render json: data

    else
      newer_than_fall_2013 = Term.arel_table[:id].gt(59)

      @terms = Term.where(newer_than_fall_2013).order(id: :desc)
        .each_with_object({}) do |term, hash|
          hash[term.display_name] = term.id
          hash
        end

      @departments = Department.all
      @sections = []
    end
  end

  def show
    if params[:id]
      redirect_to clo_reports_grade_distribution_path(params[:id])

    else
      redirect_to reports_grade_distributions_path
    end
  end

  def clos
    add_breadcrumb 'CLOs', clo_reports_grade_distribution_path
    load_clos
  end

  def plo_to_clo_mappings
    add_breadcrumb 'PLO-CLO Mappings', plo_clo_reports_grade_distribution_path
    load_clos
    course_term = @section.course_term
    clo_course_terms = course_term.clo_course_terms
    @plo_clo_list = {}
    @plo_data = []
    CloCourseTermPloProgramTerm.where(clo_course_term: clo_course_terms).find_each do |rec|
      clo_id = rec.clo_course_term.course_learning_outcome_id
      plo_id = rec.plo_program_term.plo_id
      @plo_data << { plo_id: plo_id, clo_id: clo_id }
      @plo_clo_list[plo_id] ||= []
      @plo_clo_list[plo_id] << clo_id
    end

    @clo_combined_scores = {}

    # This method combines the grade levels for each clo
    @plo_clo_list.each do |plo, clos|
      @clo_combined_scores[plo] = []

      clos.each do |clo|
        clo_segment = { data: {}, name: format('CLO %s', clo) }

        CLO_LEVELS.each do |level|
          clo_segment[:data][level] = 0

          if @assessments[clo].present?
            clo_segment[:data][level] = @assessments[clo][level]
          end
        end

        @clo_combined_scores[plo] << clo_segment
      end
    end

    @plo_descriptions = @plo_data.each_with_object({}) do |result, h|
      h[result['plo_id']] = result['description']
      h
    end
  end

  def grade_distributions
    add_breadcrumb 'Grade Distribution', reports_grade_distribution_path

    section_students = SectionStudent.includes(:grade).where(
      term_id: @section.term_id,
      section_id: @section.id,
      status: %w(enrolled graded)
    )

    section_grades = section_students.group(:grade_id).count
    grades = Grade.order('high asc, low asc, name asc').all
    grade_counts = grades.map { |g| [g.name, (section_grades[g.id] || 0)] }

    @grade_distribution = {
      enrolled: section_students.count,
      by_grade: Hash[*grade_counts.flatten],
      ungraded: section_students.where(grade_id: nil).count
    }
  end

  private

  def report_params
    params.fetch(:report, {})
  end

  def load_clos
    clos = @section.course_learning_outcomes

    @clo_descriptions =
      clos.each_with_object({}) do |clo, h|
        h[clo.id] = clo.description
        h
      end

    @assessments = AssessmentLearningOutcome.where(
      course_learning_outcome_id: clos.map(&:id),
      assessment_type: %w[DiscussionParticipant QuizScore StudentAssignment]
    ).each_with_object({}) do |alo, h|
      h[alo.course_learning_outcome_id] ||= {
        CLO_LEVELS[0] => 0,
        CLO_LEVELS[1] => 0,
        CLO_LEVELS[2] => 0,
        CLO_LEVELS[3] => 0
      }

      h[alo.course_learning_outcome_id][CLO_LEVELS[alo.score - 1].to_s] += 1
      Rails.logger.info(h)
      h
    end
  end
end
