class Reports::DashboardsController < Reports::ReportsController
  add_breadcrumb 'Reporting Dashboard', :reports_dashboard_path

  def show
    @report_links = {
      'Grade Distribution Report' => :reports_grade_distributions,
      'Final Grade Progress Report' => :reports_final_grades_progress_index,
      'Section Evaluations' => :reports_section_surveys
    }
  end
end
