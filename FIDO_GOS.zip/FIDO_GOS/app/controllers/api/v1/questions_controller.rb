class Api::V1::QuestionsController < Api::V1::ApiController
  before_action :find_quiz
  before_action :find_question, only: %i(show update destroy)

  def index
    authorize @quiz, :show?

    render json: @quiz.questions
  end

  def show
    authorize @question

    render_question
  end

  def create
    @question = @quiz.questions.new(question_attributes)

    authorize @question

    render_question { @question.save }
  end

  def update
    authorize @question

    render_question { @question.update_attributes(question_attributes) }
  end

  def destroy
    authorize @question

    render_question { @question.destroy }
  end

  private

  def render_question
    if !block_given? || yield
      render json: @question
    else
      render json: @question.errors, status: :unprocessable_entity
    end
  end

  def find_question
    @question = @quiz.questions.find params[:id]
  end

  def find_quiz
    @quiz = Quiz.find params[:quiz_id]
  end

  def question_attributes
    params.require(:question).permit(
      :active,
      :category,
      :deleted_at,
      :description,
      :fraction_score,
      :points,
      :hours,
      :question_type,
      :quiz_id,
      :random_order,
      question_answers_attributes: [
        :id,
        :answer,
        :choice,
        :points,
        :question_type
      ]
    )
  end
end
