class Api::V1::IlosController < Api::V1::ApiController
  using CastToBooleanStringRefinement

  before_action :find_ilo, only: %i(show update destroy)

  def index
    render json: Ilo.send(index_scope)
  end

  def show
    render_ilo
  end

  def create
    @ilo = Ilo.new(ilo_attributes)

    authorize @ilo

    render_ilo { @ilo.save }
  end

  def update
    authorize @ilo

    render_ilo { @ilo.update_attributes(ilo_attributes) }
  end

  def destroy
    authorize @ilo

    render_ilo { @ilo.destroy }
  end

  private

  def index_scope
    include_inactive? ? 'all' : 'current'
  end

  def include_inactive?
    params.fetch(:include_inactive, '').to_boolean
  end

  def render_ilo
    if !block_given? || yield
      render json: @ilo
    else
      render json: @ilo.errors, status: :unprocessable_entity
    end
  end

  def find_ilo
    @ilo = Ilo.find(params[:id])
  end

  def ilo_attributes
    params.require(:ilo).permit(
      :active,
      :description
    )
  end
end
