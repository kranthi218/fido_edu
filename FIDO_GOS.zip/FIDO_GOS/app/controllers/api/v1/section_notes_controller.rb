class Api::V1::SectionNotesController < Api::V1::ApiController
  before_action :find_section_note, only: %i(update destroy)
  before_action :find_section

  def index
    authorize @section, :show?

    render json: @section.section_notes
  end

  def create
    @section_note = @section.section_notes.new(section_note_attributes)

    @section_note.user_id = current_user.id if current_user

    authorize @section_note

    render_section_note { @section_note.save }
  end

  def update
    authorize @section_note
    render_section_note do
      @section_note.update_attributes(section_note_attributes)
    end
  end

  def destroy
    authorize @section_note

    render_section_note { @section_note.destroy }
  end

  private

  def render_section_note
    if !block_given? || yield
      render json: @section_note
    else
      render json: @section_note.errors, status: :unprocessable_entity
    end
  end

  def find_section
    @section = Section.find(params[:section_id])
  end

  def find_section_note
    @section_note = SectionNote.find(params[:id])
  end

  def section_note_attributes
    params.require(:section_note).permit(:message)
  end
end
