class Api::V1::NotificationsController < Api::V1::ApiController
  before_action :find_section

  def index
    render json: @section.notifications
  end

  def create
    authorize @section, :mailing?

    @notification = Notification.new(notification_params)

    if @notification.save
      recipients.each do |user|
        RosterMailer.send_message(
          current_user.name,
          user.name,
          user.email,
          @section.course.course_no,
          @notification.subject,
          @notification.content
        ).deliver_later(queue: :notifications)
      end
      render json: @notification
    else
      render json: @notification.errors, status: :unprocessable_entity
    end
  end

  private

  def notification_params
    params.require(:notification).permit(
      :subject,
      :content,
      :notification_type,
      recipient_ids: []
    ).merge(
      sender_id: current_user.id,
      # @TODO make recipient_id optional or extract recepients to be many 2 many
      # relation between Notification and User
      recipient_id: current_user.id
    )
  end

  def recipients
    User.find(params.fetch(:recipient_ids, []))
  end

  def find_section
    @section = Section.find params[:section_id]
  end
end
