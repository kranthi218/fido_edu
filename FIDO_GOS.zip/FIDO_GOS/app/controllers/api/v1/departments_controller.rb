class Api::V1::DepartmentsController < Api::V1::ApiController
  def index
    render json: Department.visible
  end
end
