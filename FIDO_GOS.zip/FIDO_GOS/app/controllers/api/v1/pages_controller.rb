class Api::V1::PagesController < Api::V1::ApiController
  def index
    search_params[:query] || filter_params[:parent_id] ? search : root_pages
  end

  def main_key
    page = Page.tagged_with(show_params[:roles], on: :roles, any: true)
               .find_by_main_key(show_params[:main_key])

    render json: page
  end

  def show
    page = Page.tagged_with(show_params[:roles], on: :roles, any: true)
               .find(show_params[:id])

    render json: page
  end

  private

  def headers(pages)
    {
      'X-Total-Count' => pages.total_count.to_s,
      'X-Page-Number' => page_params.to_s,
      'X-Per-Page'    => per_page_params.to_s,
      'X-Page-Sort'   => sort_param,
      'X-Page-Order'  => order_param
    }
  end

  def root_pages
    pages = root_query
    response.headers.merge!(headers(pages))
    render json: pages
  end

  def search
    pages = search_query
    response.headers.merge!(headers(pages))
    render json: pages.objects
  end

  def root_query
    pages = Page.top_level

    pages = pages.tagged_with(role_param, on: :roles) unless role_param.blank?

    unless category_param.blank?
      pages = pages.tagged_with(category_param, on: :categories)
    end

    pages.page(params[:page])
         .per(per_page_params)
  end

  def search_query
    Page.custom_search(search_params[:query],
                       filter_params)
        .page(page_params)
        .per(per_page_params)
        .load
  end

  def search_params
    params.permit(
      :id, :query, :sort, :order,
      :page, :tags, :page_category_id,
      :parent_id, :per_page,
      roles: [], categories: []
    )
  end

  def filter_params
    param_hash = search_params.permit(
      :parent_id,
      roles: [],
      categories: []
    )

    param_hash[:active] = true

    param_hash
  end

  def role_param
    search_params[:roles] || []
  end

  def category_param
    search_params[:categories] || []
  end

  def page_params
    search_params[:page] || 1
  end

  def per_page_params
    search_params[:per_page] || 20
  end

  def sort_param
    search_params[:sort] || 'title'
  end

  def order_param
    search_params[:order] || 'asc'
  end

  def show_params
    params.permit(
      :main_key,
      :id,
      roles: []
    )
  end
end
