class Api::V1::CourseTermsController < Api::V1::ApiController
  before_action :find_term, only: :index
  before_action :find_course, only: :index
  before_action :find_course_term, only: :update

  def index
    render json: CourseTerm.for_course_and_term(@course, @term)
  end

  def update
    authorize @course_term

    render_course_term do
      @course_term.publish!
    end
  end

  private

  def find_term
    @term = Term.find_by(id: params[:term_id])
  end

  def find_course_term
    @course_term = CourseTerm.find_by(id: params[:id])
  end

  def find_course
    @course = Course.find_by(id: params[:course_id])
  end

  def update_attributes
    params.require(:course_term).permit(
      :published
    )
  end

  def render_course_term
    if !block_given? || yield
      render json: @course_term
    else
      render json: @course_term.errors, status: :unprocessable_entity
    end
  end
end
