class Api::V1::PermissionsController < Api::V1::ApiController
  before_action :find_user, only: :index

  def index
    authorize Permission

    render json: @user.permissions.includes(:term, :section)
  end

  private

  def find_user
    @user = User.find(params[:user_id])
  end
end
