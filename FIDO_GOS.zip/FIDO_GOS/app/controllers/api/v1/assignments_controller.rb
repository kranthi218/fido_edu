# Api::V1 endpoint for Assignments
#
class Api::V1::AssignmentsController < Api::V1::ApiController
  before_action :find_assignment, only: %i(bundle show update destroy course_module)
  before_action :find_parent

  def index
    authorize @parent, :show?

    render json: @parent.assignments
  end

  def show
    authorize @assignment

    render_assignment
  end

  def bundle
    authorize @assignment

    StudentAssignmentAssetBundlerJob.perform_later(@assignment.id,
                                                   current_user.id)
    head :created
  end

  def create
    @assignment = @parent.assignments.new(assignment_attributes)
    coursework = @parent.coursework.create(kind: :regular)
    @assignment.coursework = coursework
    authorize @assignment

    create_and_render_assignment { @assignment.save }
  end

  def update
    authorize @assignment
    render_assignment { @assignment.update_attributes(assignment_attributes) }
  end

  def destroy
    authorize @assignment

    render_assignment { @assignment.destroy }
  end

  def course_module
    authorize @assignment, :update?

    target_id = params.require(:course_module).fetch(:id)
    target    = @parent.course_modules.find_by(id: target_id)

    render_assignment do
      @assignment.update_attribute(:course_module_id, target.try(:id))
    end
  end

  private

  def render_assignment
    if !block_given? || yield
      render json: @assignment, include: '**'
    else
      render json: @assignment.errors, status: :unprocessable_entity
    end
  end

  def create_and_render_assignment
    if !block_given? || yield
      render json: @assignment, include: '**'
    else
      @assignment.coursework.destroy!
      render json: @assignment.errors, status: :unprocessable_entity
    end
  end

  def find_assignment
    @assignment = Assignment.includes(course_learning_outcomes:
      [rubrics: [:rubric_score_guides]]).find(params[:id])
  end

  def find_parent
    @parent = if params[:course_id]
                Course.find(params[:course_id])
              elsif params[:section_id]
                Section.find(params[:section_id])
              else
                @assignment.section || @assignment.course
              end
  end

  def assignment_attributes
    if params[:assignment].key?(:course_learning_outcome_ids)
      params[:assignment][:course_learning_outcome_ids] ||= []
    end

    params.require(:assignment).permit(
      :active,
      :course_module_id,
      :description,
      :ends_at,
      :grading_policy_id,
      :in_class,
      :points,
      :hours,
      :rubric_id,
      :soft_deadline,
      :starts_at,
      :title,
      :visible,
      asset_attributes: [],
      links_attributes: %i[id url],
      course_learning_outcome_ids: []
    )
  end
end
