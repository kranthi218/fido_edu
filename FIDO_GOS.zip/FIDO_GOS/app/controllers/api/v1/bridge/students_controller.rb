# This controller handles Students RESTful APIs
class Api::V1::Bridge::StudentsController < Api::V1::Bridge::ApiController
  before_action :find_resource, only: :show

  JSON_CLASSNAME = :student

  def show
    render json: @resource, serializer: ::Bridge::StudentSerializer
  end

  def index
    @resources = Student.bridge_exportable(params[:term_id])
      .includes(:section_students, :degree_histories, :user)
      .page(params[:page]).per(params[:per_page])
    render json: @resources, each_serializer: ::Bridge::StudentSerializer
  end
end
