# This controller handles StudentsCourse RESTful APIs
class Api::V1::Bridge::SectionStudentsController < Api::V1::Bridge::ApiController
  before_action :find_resource, only: :show
  before_action :find_parent,   only: :index

  JSON_CLASSNAME = :section_student

  def show
    render json: @resource, serializer: ::Bridge::SectionStudentSerializer
  end

  def index
    @resources = @parent.page(params[:page]).per(params[:per_page])
    render json: @resources, each_serializer: ::Bridge::SectionStudentSerializer
  end

  private

  def find_parent
    @parent = if params[:student_id]
                Student.find(params[:student_id]).section_students
              else
                SectionStudent.all
              end
  end
end
