# This controller provides educations with JSON format
class Api::V1::Bridge::DegreeHistoriesController < Api::V1::Bridge::ApiController
  before_action :find_resource, only: :show
  before_action :find_parent,   only: :index

  JSON_CLASSNAME = :degree_history

  def show
    render json: @resource, serializer: ::Bridge::DegreeHistorySerializer
  end

  def index
    @resources = @parent.page(params[:page]).per(params[:per_page])
    render json: @resources, each_serializer: ::Bridge::DegreeHistorySerializer
  end

  private

  def find_parent
    @parent = if params[:student_id]
                Student.find(params[:student_id]).degree_histories
              else
                DegreeHistory.all
              end
  end
end
