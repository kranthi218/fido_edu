class Api::V1::CourseMaterialsController < Api::V1::ApiController
  ALLOWED_TYPES = %w(Book CourseResource)

  before_action :find_section

  def index
    authorize @section, :show?

    course_materials = @section.books + @section.course_resources

    render json: course_materials
  end

  def import
    cloner = Cloner::CourseMaterial.new(@section)

    response = import_course_materials.map do |item|
      material = find_course_material(item[:type], item[:id])

      authorize material, :import?

      { id: material.id, type: item[:type], status: cloner.perform(material) }
    end

    render json: response.to_json
  end

  private

  def find_section
    @section = if params[:section_id]
                 Section.find(params[:section_id])
               else
                 fail ActiveRecord::RecordNotFound
               end
  end

  def find_course_material(type, id)
    type = type.camelize

    return unless ALLOWED_TYPES.include?(type)

    type.constantize.find(id)
  end

  def import_course_materials
    params.require(:import).permit(
      course_materials: [:id, :type]
    ).fetch(:course_materials, [])
  end
end
