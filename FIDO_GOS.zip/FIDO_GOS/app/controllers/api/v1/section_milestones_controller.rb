class Api::V1::SectionMilestonesController < Api::V1::ApiController
  before_action :find_milestone, only: %i(show update destroy)
  before_action :find_section

  def index
    authorize @section, :show?

    render json: @section.milestones
  end

  def show
    authorize @milestone

    render_milestone
  end

  def create
    @milestone = @section.milestones.new(milestone_attributes)

    authorize @milestone

    render_milestone { @milestone.save }
  end

  def update
    authorize @milestone

    render_milestone do
      @milestone.update_attributes(milestone_attributes)
    end
  end

  def destroy
    authorize @milestone

    render_milestone { @milestone.destroy }
  end

  def reset
    authorize @section, :edit?

    @section.milestones.delete_all
    head :ok
  end

  private

  def render_milestone
    if !block_given? || yield
      render json: @milestone
    else
      render json: @milestone.errors, status: :unprocessable_entity
    end
  end

  def find_section
    @section = Section.find(params[:section_id])
  end

  def find_milestone
    @milestone = SectionMilestone.find(params[:id])
  end

  def milestone_attributes
    params.require(:milestone).permit(:name, :date, :mandatory)
  end
end
