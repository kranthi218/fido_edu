class Api::V1::BroadcastsController < Api::V1::ApiController
  before_action :find_department, only: %i[index create]
  before_action :find_broadcast,  only: %i[show update destroy]

  def index
    @base = case role
            when 'hod'
              @department.broadcasts

            when 'faculty'
              Broadcast.by_department_or_global(department_ids)
                       .for_faculty
                       .current

            when 'student'
              Broadcast.by_department_or_global(department_ids)
                       .for_students
                       .current

            when 'support'
              Broadcast.all
            end

    render json: @base.recent
  end

  def show
    render_broadcast
  end

  def create
    @broadcast = Broadcast.new(
      broadcast_attributes.merge(
        department_id: @department.id,
        creator_id: current_user.id
      )
    )

    authorize @broadcast

    render_broadcast { @broadcast.save }
  end

  def update
    authorize @broadcast

    render_broadcast { @broadcast.update_attributes(broadcast_attributes) }
  end

  def destroy
    authorize @broadcast

    render_broadcast { @broadcast.destroy }
  end

  private

  def render_broadcast
    if !block_given? || yield
      render json: @broadcast
    else
      render json: @broadcast.errors, status: :unprocessable_entity
    end
  end

  def find_broadcast
    @broadcast = Broadcast.find(params[:id])
  end

  def find_department
    @department = Department.find_by(id: params[:department_id])
  end

  def department_ids
    Array.wrap(params[:department_id] || params[:department_ids])
  end

  def role
    params.fetch(:role, 'student').try(:downcase)
  end

  def broadcast_attributes
    params.require(:broadcast).permit(
      :title,
      :content,
      :published_at,
      :visible_to_students,
      :visible_to_faculty
    )
  end
end
