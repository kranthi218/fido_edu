class Api::V1::ProgramsController < Api::V1::ApiController
  before_action :find_department
  before_action :find_program, only: %i(show update destroy)

  def index
    programs = if @department
                 Program.where(department_id: @department).visible
               else
                 Program.visible
               end

    render json: programs
  end

  def show
    render_program
  end

  def create
    @program = @department.programs.new(program_attributes)

    authorize @program

    render_program { @program.save }
  end

  def update
    authorize @program

    render_program { @program.update_attributes(program_attributes) }
  end

  def destroy
    authorize @program

    render_program { @program.destroy }
  end

  private

  def render_program
    if !block_given? || yield
      render json: @program
    else
      render json: @program.errors, status: :unprocessable_entity
    end
  end

  def find_department
    @department = Department.find params[:department_id]
  end

  def find_program
    @program = @department.programs.find params[:id]
  end

  def program_attributes
    params.require(:program).permit(
      :mission_statement,
      :program_code,
      :status,
      :name
    )
  end
end
