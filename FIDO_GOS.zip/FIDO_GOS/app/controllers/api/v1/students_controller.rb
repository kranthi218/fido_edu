class Api::V1::StudentsController < Api::V1::ApiController
  before_action :find_section

  def index
    render json: @section.students.includes(:user)
  end

  def show
    render json: @section.students_with_inactive.find(params[:id])
  end

  private

  def find_section
    @section = Section.find(params[:section_id])

    authorize @section, :show?
  end
end
