class Api::V1::GradingScalesController < Api::V1::ApiController
  before_action :find_section

  def index
    render json: @section.grading_scales.grades_order
  end

  def update_all
    authorize @section, :update?

    @section.assign_attributes(grading_scales_attributes)

    if @section.save
      render json: @section.grading_scales
    else
      render json: @section.errors, status: :unprocessable_entity
    end
  end

  private

  def find_section
    @section = Section.find(params[:section_id])
  end

  def grading_scales_attributes
    params.require(:update_all).permit(
      grading_scales_attributes:
        [
          :id,
          :grade_id,
          :high,
          :low
        ]
    )
  end
end
