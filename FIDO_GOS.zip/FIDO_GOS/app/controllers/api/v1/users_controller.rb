# This controller handles Terms RESTful APIs
class Api::V1::UsersController < Api::V1::ApiController
  before_action :find_user, only: %i[show]

  has_search_params defaults: { sort: 'email' },
                    filters: %w[is_student is_faculty]

  def index
    authorize User

    users = User.custom_search(query_param, filter_params)
                .order(sorting_params)
                .page(page_param)
                .per(per_page_param)

    set_search_headers(users)

    render json: users.load(
      section: {
        scope: User.includes(
          :student,
          :faculty
        )
      }
    ).objects
  end

  def show
    authorize @user

    render_user
  end

  private

  def render_user
    if !block_given? || yield
      render json: @user
    else
      render json: @user.errors, status: :unprocessable_entity
    end
  end

  def find_user
    @user = User.find(params[:id])
  end
end
