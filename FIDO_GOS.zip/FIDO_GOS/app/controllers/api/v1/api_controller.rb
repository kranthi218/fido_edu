# Parent controller for Api:V1
class Api::V1::ApiController < ApplicationController
  include Search::Params

  protect_from_forgery prepend: true

  serialization_scope :view_context

  respond_to :json
  require 'app_responders'

  rescue_from ActiveRecord::DeleteRestrictionError, with: :prevent_modification
  rescue_from ActiveRecord::ReadOnlyRecord,         with: :prevent_modification

  protected

  def prevent_modification(exception)
    render json: { message: exception }, status: :method_not_allowed
  end

  def default_serializer_options
    { root: false }
  end
end
