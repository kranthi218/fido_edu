# Api::V1 endpoint for SignatureAssignments
#
class Api::V1::SignatureAssignmentsController < Api::V1::ApiController
  before_action :find_parent
  before_action :find_assignment, only: %i(show update destroy)

  def show
    authorize @assignment

    render_assignment
  end

  def create
    @assignment = @course.assignments.new(assignment_attributes)
    @deleted_coursework = @course.coursework.destroy_all

    coursework = @course.coursework.create(kind: :signature)
    logger.info coursework.inspect
    @assignment.coursework = coursework
    authorize @assignment

    create_and_render_assignment do 
      @assignment.save
      duplicate_assets(@assignment)
      @assignment
    end
  end

  def update
    authorize @assignment

    render_assignment { @assignment.update_attributes(assignment_attributes) }
  end

  def destroy
    authorize @assignment

    render_assignment { @assignment.destroy! }
  end

  private

  def create_and_render_assignment
    if !block_given? || yield
      render json: @assignment, include: '**'
    else
      logger.info @assignment.errors.full_messages.join(', ') if @assignment.errors.any?
      @assignment.coursework.destroy!
      @deleted_coursework.each(&:save)
      render json: @assignment.errors, status: :unprocessable_entity
    end
  end

  def render_assignment
    if !block_given? || yield
      render json: @assignment
    else
      render json: @assignment.errors, status: :unprocessable_entity
    end
  end

  def find_assignment
    @assignment = if @course_term
                    @course_term.signature_assignment || Assignment.new
                  else
                    @course.signature_assignment || @course.assignments.new
                  end
  end

  def find_parent
    if params[:course_term_id]
      @course_term = CourseTerm.find(params[:course_term_id])
    else
      @course = Course.find(params[:course_id])
    end
  end

  def duplicate_assets(sig_ass)
    if asset_attributes[:assets_attributes].present?
      asset_attributes[:assets_attributes].each do |asset_id|
        if new_asset = Asset.find_by_id(asset_id['id'])
          asset = new_asset.deep_dup
          asset.attachable_id = sig_ass.id
          asset.attachment = new_asset.attachment
          asset.save
        end
      end
    end
  end

  def assignment_attributes
    params.require(:signature_assignment).permit(
      :description,
      :grading_policy_id,
      :in_class,
      :points,
      :hours,
      :rubric_id,
      :title,
      :visible,
      :optional,
      assets_attributes: [],
      links_attributes: [:url],
      course_learning_outcome_ids: []
    )
  end

  def asset_attributes
    params.require(:signature_assignment).permit(assets_attributes: [:id])
  end
end
