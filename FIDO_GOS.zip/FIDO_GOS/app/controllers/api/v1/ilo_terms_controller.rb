class Api::V1::IloTermsController < Api::V1::ApiController
  before_action :find_term

  def index
    render json: IloTerm.for_term(@term)
  end

  private

  def find_term
    @term = Term.find params[:term_id]
  end
end
