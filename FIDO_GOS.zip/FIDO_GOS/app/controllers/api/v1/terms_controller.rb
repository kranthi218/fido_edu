# This controller handles Terms RESTful APIs
class Api::V1::TermsController < Api::V1::ApiController
  def index
    terms = TermPolicy::Scope.new(
      current_user,
      Term.recent,
      role_param
    ).resolve

    render json: terms
  end

  def previous
    render json: Term.current.previous
  end

  def current
    render json: Term.current
  end

  def next
    term = Term.current.next
    fail ActiveRecord::RecordNotFound unless term

    render json: term
  end

  private

  def role_param
    params.fetch(:role, :both).to_sym
  end
end
