# frozen_string_literal: true

class Api::V1::Shopify::ProductsController < Api::V1::ApiController
  skip_before_action :authenticate_user!
  before_action :authenticate


  def update_enrollment_count
    product_attributes[:line_items].each do |item|
      section = Ex::Rw::Section.find_by(shopify_product_id: item[:product_id])
      section.increment(:crs_enrollment, item[:quantity])
      section.increment(:current_reg_count, item[:quantity])
      section.save
    end
    head :ok
  end

  def populate_shopify_id
    # for now term is hard coded, when we have better specs, we will change it
    section = Ex::Rw::Section.where(yr_cde: '2017', trm_cde: 'FA')
                             .where(crs_cde_condition)
                             .take
    section&.update_attribute(:shopify_product_id, product_create_attributes[:id])
    head :ok
  end

  private

  def crs_cde_condition
    code_part = product_create_attributes[:title].split('-').first
    format("crs_cde LIKE '%s'", code_part.squish.tr(' ', '%'))
  end

  def product_attributes
    params.permit(line_items: %i[product_id quantity])
  end

  def product_create_attributes
    params.permit(:id, :title)
  end

  def authenticate
    authenticate_token || head(:unauthorized)
  end

  def authenticate_token
    verify_webhook(request.body.read,
                   request.headers['HTTP_X_SHOPIFY_HMAC_SHA256'])
  end

  def verify_webhook(data, hmac_header)
    digest = OpenSSL::Digest::Digest.new('sha256')

    calculated_hmac = Base64.encode64(
      OpenSSL::HMAC.digest(digest, ENV['SHOPIFY_SHARED_SECRET'], data)
    ).strip

    ActiveSupport::SecurityUtils.secure_compare(calculated_hmac, hmac_header)
  end
end
