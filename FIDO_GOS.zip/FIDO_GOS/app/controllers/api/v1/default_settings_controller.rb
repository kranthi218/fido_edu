# This controller handles Default Settings RESTful APIs
class Api::V1::DefaultSettingsController < Api::V1::ApiController
  def index
    @settings = DefaultSetting.get_all
    render json: @settings
  end
end
