class Api::V1::CoursesController < Api::V1::ApiController
  has_search_params filters: %i[ core
                                 active
                                 program_id
                                 department_id
                                 last_published_term
                                 program_code ]
  def index
    authorize Course

    courses = Course.custom_search(query_param, filter_params)
                    .order(sorting_params)
                    .page(page_param)
                    .per(per_page_param)

    set_search_headers(courses)

    render json: courses.load.objects
  end

  def show
    course = Course.find(params[:id])
    authorize course

    render json: course
  end
end
