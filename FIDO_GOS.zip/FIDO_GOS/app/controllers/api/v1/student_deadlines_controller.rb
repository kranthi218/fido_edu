class Api::V1::StudentDeadlinesController < Api::V1::ApiController
  before_action :find_coursework
  before_action :find_student_deadline, only: %i(show update)

  ALLOWED_COURSEWORK = %w(Assignment Discussion Quiz)

  def index
    render json: @coursework.student_deadlines
  end

  def show
    authorize @student_deadline
    render_student_deadline
  end

  def create
    @student_deadline = @coursework.student_deadlines
                                   .new(student_deadline_attributes)
    authorize @student_deadline
    render_student_deadline { @student_deadline.save }
  end

  def update
    @student_deadline = @coursework.student_deadlines.find(params[:id])
    authorize @student_deadline, :update?
    render_student_deadline do
      @student_deadline.update_attributes(student_deadline_attributes)
    end
  end

  private

  def render_student_deadline
    if !block_given? || yield
      render json: @student_deadline
    else
      render json: @student_deadline.errors, status: :unprocessable_entity
    end
  end

  def student_deadline_attributes
    params.require(:student_deadline).permit(
      :id,
      :student_id,
      :coursework_id,
      :coursework_type,
      :section_id,
      :ends_at
    )
  end

  def find_coursework
    if ALLOWED_COURSEWORK.include?(params[:coursework_type].try(:camelize))
      model       = params[:coursework_type].camelize.constantize
      @coursework = model.find params[:coursework_id]
    else
      head :forbidden
      false
    end
  end

  def find_student_deadline
    @student_deadline = @coursework.student_deadlines.find(params[:id])
  end
end
