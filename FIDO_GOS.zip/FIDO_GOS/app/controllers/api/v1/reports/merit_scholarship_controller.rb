class Api::V1::Reports::MeritScholarshipController < Api::V1::ApiController

  has_search_params defaults: { sort: 'ranking_number',
                                order: 'desc',
                                per_page: 25 },
                    filters: %i[department_id term_id]

  def index
    authorize :report

    @enrollments = TermEnrollment.custom_search(query_param, filter_params)
                                 .order(sorting_params)
                                 .page(page_param)
                                 .per(per_page_param)
                                 .load

    set_search_headers(@enrollments)

    render json: @enrollments.map(&:attributes)
  end
end
