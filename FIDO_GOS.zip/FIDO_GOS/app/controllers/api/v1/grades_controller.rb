class Api::V1::GradesController < Api::V1::ApiController
  using CastToBooleanStringRefinement

  def index
    section = Section.find_by_id(params[:section_id])

    grades_set = if section&.use_pass_fail
                   Grade::PASS_NOPASS
                 else
                   Grade::LETTER_GRADES
                 end

    grades_set += Grade::NON_GRADABLE if include_non_gradable?

    render json: Grade.collection(grades_set)
  end

  def include_non_gradable?
    params.fetch(:include_non_gradable, '').to_boolean
  end
end
