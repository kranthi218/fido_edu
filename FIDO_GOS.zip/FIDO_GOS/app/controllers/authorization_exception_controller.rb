class AuthorizationExceptionController < ApplicationController
  def show
  end
end
