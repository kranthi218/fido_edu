(function($) {
    $(document).ready(function() {
		var changed_count = 0;
		$(".student_assignment_grade_clo_scores_select").change(function(){
			$(this).parent().parent().addClass("gradebook_changed");
			//$(".gradebook_button").show();
			changed_count ++;
		});
		$(".student_assignment_grade_scores_text").change(function(){
			$(this).addClass("gradebook_changed");
			//$(".gradebook_button").show();
			changed_count ++;
		});
        $(".student_assignment_grade_feedback_text").change(function(){
          $(this).addClass("gradebook_changed");
          //$(".gradebook_button").show();
          changed_count ++;
        });


		$(".assignment_paginate .pagination a").click(function(){
			if (changed_count){
				var answer = confirm("Your have changed some places, do you want to save?");
				if (answer){
					$(".formtastic.student_assignment_grade").submit();
					return false;
				}
			}
		});

	});
})(jQuery);
