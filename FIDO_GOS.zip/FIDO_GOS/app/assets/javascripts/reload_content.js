require(['jquery'], function($) {
  $('#tab-loaded-content').load($('li.active a[data-toggle="tab"]').attr('href'));
});
