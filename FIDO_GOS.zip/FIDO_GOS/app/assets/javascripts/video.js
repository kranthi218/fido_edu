//= require video.js/dist/video.js
//= require videojs-flash/dist/videojs-flash.js

$(function() {

  if(typeof(console) !== "undefined") {
    console.log("video.js loaded and configured");
  }

  videojs.options.flash.swf = "/assets/videojs-swf/dist/video-js.swf";

  $(document).ready(function(){

    //Releasing iframe's src on close modal to stop playback
    $('.content').delegate('.close-video','click', function(){
      var $modal = $(this).closest('.modal');
      $modal.removeData('bs.modal');

      var $iframe = $modal.find('iframe');
      if($iframe !== undefined) {
        $iframe.prop('src','');
      };

      var video_id = $modal.find('.video-js').attr('id');
      if(video_id !== undefined) {
        videojs(video_id).dispose();
      };

    });
  });

});
