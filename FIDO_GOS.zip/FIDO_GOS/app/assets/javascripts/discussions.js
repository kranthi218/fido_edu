//= require urijs/src/URI
//= require redactor
//= require add_field

$(function() {

  if (typeof(console) !== 'undefined') {
    console.log('discussions javascript dependencies loaded');
  }

  // Full-size attachment images view in modal
  $(document).ready(function(){
    $('.discussion_comment .content img').on('click', function(){
      var $title = $(this).attr('alt');
      var $image = $(this).clone();
      $('.modal-body').empty();
      $('.modal-title').html($title);
      $image.removeAttr('style')
            .appendTo('.modal-body');

      $image.load(function(){
        var width = $image.width() + 70;
        $(".modal-dialog").css('width', width);
      });
      $('#discussion-modal').modal({ show: true });
    });
  });

  function highlight_discussion_comment($element) {
    var $otherComments = $('.discussion_comment');

    if (!$element.hasClass('highlight')) {
      $otherComments.removeClass('highlight');
      $element.addClass('highlight');
    }
  }

  // Scroll to the currently focused discussion comment and do a bit
  // of background color animation to draw the user's attention to it.
  function scroll_to_discussion_comment($element) {
    highlight_discussion_comment($element);
    $element.scroll_to_element();
  }

  function focus_current_discussion_comment() {
    // Discussion comment path is something like:
    // /discussions/DISCUSSION_ID/comment/DISCUSSION_COMMENT_ID/
    // /     0     /       1     /   2   /           3         /
    var discussion_comment_id = URI(document.location.href).segment(3),
        $discussion_comment = $('#discussion_comment_' + discussion_comment_id);

    if ($discussion_comment.length > 0) {
      scroll_to_discussion_comment($discussion_comment);
      highlight_discussion_comment($discussion_comment);
    }
  }

  function get_discussion_id() {
    return URI(document.location.href).segment(1);
  };

  function get_discussion_path() {
    return '/discussions/' + get_discussion_id();
  };

  function get_discussion_comment_id(element) {
    return $(element).closest('.discussion_comment')
                     .attr('id')
                     .split('_')
                     .pop();
  };

  function get_discussion_comment_path(element) {
    var discussion_id = get_discussion_id();
    var comment_id = get_discussion_comment_id(element);
    return '/discussions/' + discussion_id + '/comment/' + comment_id;
  };

  var backups = {};

  $(document).ready(function() {
    // Expand/collapse discussion comments
    $('.show-comments').on('click', function() {
      $('.discussion_comment .content').collapse('show');
    });

    $('.hide-comments').on('click', function() {
      $('.discussion_comment .content').collapse('hide');
    });

    $('.discussion_comments').tooltip({
      selector: '[data-toggle="tooltip"]',
      placement: 'auto',
      trigger: 'hover'
    });

    // Change the toggle icon when comments are shown/hidden
    $('[id^="discussion_comment_"]').on('shown.bs.collapse hidden.bs.collapse', function() {
      $(this).find('h4 i.icon').toggleClass('icon-toggle-up icon-toggle-down');
    });

    // If we're in the process of creating/updating a comment, scroll to the comment form;
    // otherwise just focus on the current discussion comment.
    if ($('body').attr('id') == 'discussions-update') {
      $('#new_discussion_comment').scroll_to_element();
    } else {
      focus_current_discussion_comment();
    }
  });

  // In place comment editor
  $(document).ready(function() {
    $('.edit-comment').on('click', function() {
      var element = $(this).closest('.media-body').find('.content');
      var comment_id = get_discussion_comment_id(element);

      // Backing up content and show redactor
      backups[comment_id] = element.html();

      // If the element is collapsed, ensure we show it before
      // we initialize the editor
      if(!element.hasClass('in')) {
        element.collapse('show');
      };

      element.addClass('redactor');
      element.parent().css('overflow','visible');
      $(this).addClass('hide');
      $(this).siblings('.cancel-comment').removeClass('hide');
      $(this).siblings('.update-comment').removeClass('hide');
      Redactor.bind(Redactor.discussion);
      return false;
    });

    $('.update-comment').on('click', function() {
      var element = $(this).closest('.media-body').find('.content');
      var comment_id = get_discussion_comment_id(element);
      var update_path = get_discussion_comment_path(element);
      var update_button = $(this);
      var request = $.ajax({
        url: update_path,
        type: 'PUT',
        dataType: 'json',
        data: {
          discussion_comment_id: comment_id,
          discussion_comment: { content: element.redactor('code.get') }
        }
      });

      request.done(function(data) {
        element.closest('.media-body').css('overflow','hidden');
        element.redactor('core.destroy');
        element.removeClass('redactor redactor-loaded');
        update_button.addClass('hide');
        update_button.siblings('.cancel-comment').addClass('hide');
        update_button.siblings('.edit-comment').removeClass('hide');
        alert('Post was succeesfully updated!');
      });

      request.fail(function(xhr) {
        alert($.parseJSON(xhr.responseText).errors);
      });

      return false;
    });

    $('.delete-comment').on('click', function() {
      if (confirm('Are you sure?')) {
        var element = $(this).closest('.media-body').find('.content');
        var comment_id = get_discussion_comment_id(element);
        var delete_path = get_discussion_comment_path(element);
        var request = $.ajax({
          url: delete_path,
          type: 'DELETE',
          dataType: 'json',
          data: { discussion_comment_id: comment_id }
        });

        request.done(function(data) {
          // Removing subtree comments (including self)
          $.each(data.subtree_ids, function(i, id) {
            $('#discussion_comment_' + id).remove();
          });

          // Redirecting if all comments has been deleted
          if ($('.discussion_comment').length === 0) {
            window.location = get_discussion_path();
          }
        });

        request.fail(function(xhr) {
          alert($.parseJSON(xhr.responseText).errors);
        });

      }

      return false;
    });

    $('.cancel-comment').on('click', function() {
      var element = $(this).closest('.media-body').find('.content');
      var comment_id = get_discussion_comment_id(element);

      element.closest('.media-body').css('overflow','hidden');
      element.redactor('core.destroy');
      element.removeClass('redactor redactor-loaded');
      element.html(backups[comment_id]);

      $(this).addClass('hide');
      $(this).siblings('.edit-comment').removeClass('hide');
      $(this).siblings('.update-comment').addClass('hide');

      return false;
    });
  });

  // Support remote form submission for reading/unreading discussion comments
  $(document).ready(function() {
    var $discussion_comments = $('.discussion_comments');

    $discussion_comments.delegate('.discussion_comment form', 'ajax:before', function(event, xhr, settings) {
      // Disable this comment's mark as read/unread button before starting an XHR request
      $(this).find('button').prop('disabled', true);
    });

    $discussion_comments.delegate('.discussion_comment form', 'ajax:success', function(event, data, status, xhr) {
      // Toggle 'read' CSS class in accordance with XHR response
      if (data.read) {
        $(this).parents('.discussion_comment')
          .addClass('read');

      } else {
        $(this).parents('.discussion_comment')
          .removeClass('read')
          .find('.content').collapse('show');
      }

      // Replace the current 'mark comment as read/unread' form
      // with new markup from a successful XHR request
      $(this).replaceWith(data.html);
    });

    $discussion_comments.delegate('.discussion_comment form', 'ajax:error', function(event, xhr, status, error) {
      // Log errors to console if console is available
      if (typeof console !== 'undefined') { console.log(status, error); }
    });

    $discussion_comments.delegate('.discussion_comment form', 'ajax:complete', function(event, xhr, status) {
      // In the event of failure, ensure the mark as read/unread button is re-enabled
      $(this).find('button').prop('disabled', false);
    });
  });

});
