//= require jquery/dist/jquery
//= require bootstrap-sass/assets/javascripts/bootstrap
//= require jquery-pjax/jquery.pjax
//= require jquery-ujs/src/rails
//= require scroll_to_element
//= require timeago/jquery.timeago

//= require_tree ./application

$(function() {
  if (typeof(console) !== 'undefined') {
    console.log('Application javascript dependencies loaded');
  }

  // Back to Top button
  $(window).scroll(function() {
    var y = $(this).scrollTop();
    if (y > 300) {
      $('#back-to-top').fadeIn(500);
    } else {
      $('#back-to-top').fadeOut(500);
    }
  });

  $('#back-to-top').on('click', function(event) {
    event.preventDefault();
    $('html, body').scroll_to_element();//('html, body') is for firefox support.
  });

  $(function() {
    $("a[rel~=popover], .has-popover").popover();
    $("a[rel~=tooltip], .has-tooltip").tooltip();
  });

  Notifier = {}

  Notifier.alert = function(text) {
    $('#alert .modal-body').html(text);
    $('#alert').modal('show');
  };

  Notifier.alert_forever = function(text) {
    $('#alert-forever .modal-body').html(text);
    $('#alert-forever').modal('show');
  }
});
