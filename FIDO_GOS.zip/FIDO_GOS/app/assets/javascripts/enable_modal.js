
require(['jquery'], function($) {

  $(function() {
    $('.ems-modal').modal({
  		show: false,
	})
    console.log("Modal enabled");
  });
});
