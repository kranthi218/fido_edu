/*

Documentation http://hilios.github.io/jQuery.countdown/documentation.html
css can be found in app/assets/stylesheets/countdown.css.
Make sure to included it in your page with
   = content_for :head do
     = stylesheet_link_tag "countdown"
*/

//= require jquery-datetimepicker/jquery.datetimepicker
//= require jquery-countdown/dist/jquery.countdown
"use strict";
$(function() {
  if(typeof window.EMS === 'undefined') window.EMS = {};
  var QuizTimer = EMS.QuizTimer = function () {
    this.initCountdown();
  };

  QuizTimer.prototype.initCountdown = function (){
  $('#quiz-timer').countdown(getElapsedTime())
    .on('update.countdown', function(event) {
      var format = '%H:%M:%S';
      $(this).html(event.strftime(format));
    })
    .on('finish.countdown', function(event) {
      var $form = $('#quiz_form');
      $('<input>').attr({type: 'hidden', name: 'button'})
                  .val('timeout')
                  .appendTo($form);
      $form.submit();
      console.log("form submitted")
    });
  };

  function getElapsedTime() {
    console.log("Calculate timelimit in milliseconds")
    var seconds = $('#timer').data('seconds');
    var milliseconds = parseInt(seconds, 10) * 1000;
    return new Date(milliseconds);
  };
  new QuizTimer();
});
