$(function() {

  if (typeof(console) !== 'undefined') {
    console.log('Student::Dashboard javascript dependencies loaded');
  }

  function activity_list_popover_content() {
    var $el = $(this);
  }

  $(document).ready(function() {
    $('[data-toggle~="tooltip"]').tooltip({
      placement: 'left'
    });

    $('[data-toggle~="calendar"]').on('click', function(event) {
      var $el = $(this),
          data = { calendar_item: {} },
          success_fn, fail_fn, always_fn, request;

      data.calendar_item.due_at = $el.attr('data-calendar.due-at');
      data.calendar_item.title = $el.attr('data-calendar.title');

      success_fn = function(data, status, xhr) {
        var $el = $(this),
            cal = $(data),
            oldCal = $('#' + cal.attr('id'));

        if($el.hasClass('btn-danger')) {
          $el.addClass('btn-default').removeClass('btn-danger');
        }

        oldCal.replaceWith(cal);
      };

      fail_fn = function(data, status, xhr) {
        var $el = $(this),
            errors = data.responseJSON.calendar.errors;

        $el.removeClass('btn-default').addClass('btn-danger');
        $el.attr('data-original-title', errors.items[0]);
        $el.tooltip('hide').tooltip('show');
      };

      always_fn = function() {
        $(this).removeClass('disabled');
      };

      // calendars#create
      request = $.ajax('/calendar/events', { type: 'post', data: data });
      request.success($.proxy(success_fn, this));
      request.fail($.proxy(fail_fn, this));
      request.always($.proxy(always_fn, this));

      // Disable the 'Add to calendar' button while the ajax request is in progress
      $el.addClass('disabled');

      event.preventDefault();
    });
  });

});
