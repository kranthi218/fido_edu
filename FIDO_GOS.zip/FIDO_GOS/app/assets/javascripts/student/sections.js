$(function() {
  // triggering survey modal popup
  $('#survey_modal').modal({backdrop: 'static'});
  $('#survey_modal').modal('show');

  if(typeof(console) !== "undefined") {
    console.log("Student::section javascript dependencies loaded");
  }

  $(document).ready(function () {
    if($('body').is('#sections-syllabus')) {
      $("a[data-toggle='tooltip']").tooltip({placement: 'right'});
    }
  });

  if ($.support.pjax) {
    var pjax_links     = '.sections-page .content section .nav li a'
      , pjax_container = '.sections-page .content section div[data-pjax-container]';

    $(document).pjax(pjax_links, pjax_container);
  }
});
