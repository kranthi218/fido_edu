//= require lodash/lodash

$(function() {
  function set_data(data, element_id, default_option) {
    $("#" + element_id)
      .empty()
      .append("<option value=''>" + default_option + "</option>")
      .append(
        _.map(data, function(name, id) { return '<option value=' + id + '>' + name + '</option>' } )
         .join()
      );
  };

  function update_sections() {
    $('#search_section_id').prop('selectedIndex',0);

    $.ajax({
      type: "GET",
      url: "/reports/section_surveys/sections",
      data: {
        term_id: $("#search_term_id").val(),
        department_id: $('#search_department_id').val()
      }
    })
      .done(function(data) {
        set_data(data, 'search_section_id', 'Select a Section')
      });
  };

  function update_surveys() {
    $('#search_survey_id').prop('selectedIndex',0);

    $.ajax({
      type: "GET",
      url: "/reports/section_surveys/surveys",
      data: { section_id: $('#search_section_id').val() }
    })
      .done(function(data) {
        set_data(data, 'search_survey_id', 'Select a Survey')
      });
  };

  $('#search_term_id').change(function () {
    $('#search_department_id').prop('selectedIndex', 0);
  });

  $('#search_department_id').change(update_sections);
  $('#search_section_id').change(update_surveys);

  update_sections();
  update_surveys();
});
