$(function() {
    console.log('reports/grade_distributions dependencies loaded');

   $('#search_term_id').on('change', function(e) {
      e.preventDefault();
      var request = $.ajax({
        url: $(this).closest('form').attr('action'),
        data: {term_id: $(this).val()},
        dataType: 'json',
        context: $('#report_id')
      });

      request.success(function(data, status, success) {
          select = document.getElementById('search_department_id');
          select.options.length = 0;
          select.options.add(new Option('', 'Select'));
          for (var name in data) {
            if (data.hasOwnProperty(name)) {
              select.options.add(new Option(data[name], name));
            }
          }
      });

    });

   $('#search_department_id').on('change', function(e) {
      console.log('The url to post to is ' + $(this).closest('form').attr('action'));
      console.log('We are requesting ' + $(this).val());
      console.log('This is ', $(this));
      e.preventDefault();

      $.ajax({
        url: $(this).closest('form').attr('action'),
        data: {
          term_id: $('#search_term_id').val(),
          department_id: $(this).val()
        },
        dataType: 'json',
        context: $('#report_id')
      }).success(function(data, status, success) {
          select = document.getElementById('report_id');
          select.options.length = 0;

          for (var name in data) {
            if (data.hasOwnProperty(name)) {
              select.options.add(new Option(data[name], name));
            }
          }
      });
    });
});
