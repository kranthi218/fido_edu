$(function() {

  console.log('spinner javascript dependencies loaded');

  deactivate_spinner = function(scroll_top) {
    // default value
    if (typeof scroll_top === 'undefined') scroll_top = true;
    // restore full color
    $(document.body).removeClass("dim");
    // deactivate the spinner
    $('a.has-spinner, button.has-spinner').removeClass("active");
    $('a.has-spinner, button.has-spinner').removeClass("disabled");
    // remove spinner container
    $('span.spinner').remove();

    // scroll to the top of the page
    if (scroll_top) {
      $("html, body").animate({ scrollTop: 0 }, 0);
    }
  };

  /* This spinner is used by the widgets, it's attached to body so that we can dynamically instanciate
       the buttons, and still get the spinners.

       This works on a and button only, as I couldn't insert html into an input
   */
  $(document.body).on('click', 'a.has-spinner, button.has-spinner', function() {
    if ( $( this ).find('span.spinner').first().length == 0 ) {
  	  $(this).prepend("<span class=\"spinner\"><i class=\"icon icon-spin icon-refresh\"></i></span>")
    };

    $(this).addClass('active');
    $(this).addClass('disabled');
    $(document.body).addClass("dim");

    /*
      '.body' removed, because it not works in some places,
        for example at course details
    */
    $(document).ajaxComplete(function() {
      deactivate_spinner();
    });

  })

  /*
    Deactivate spinner if confirm dialog cancel button pressed
  */
  $(document).on('confirm:complete', function(e, answer) {
    if (!answer) {
      deactivate_spinner(false);
    }
  });

  $('#alert').on('shown.bs.modal', function (e) {
    console.log('message triggered');
    setTimeout(function(){$('#alert').modal('hide')},800);
  })

});
