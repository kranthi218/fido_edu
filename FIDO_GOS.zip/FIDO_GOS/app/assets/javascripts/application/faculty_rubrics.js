(function($) {

	/* @TODO this needs to be abstracted */
	$('.plo_cslo_view').remove();
	$('.load_plo_cslos').on('click', function(event) {
		event.preventDefault();
		var ID = $(this).attr('id');
		$(this).hide();

		$.ajax({
			type: "GET",
			url: '/admin/plos/' + ID,
			dataType: "script",
			success: function(result, status) {} //do nothing on success
		});
	});

	$('a.hide_related_cslos').on('click', function(event) {
		event.preventDefault();
		var ploID = $(this).attr('id').replace(/\D+/, '');
		$("a#" + ploID).show();
		$(this).closest('div').remove();
	})

	$('textarea').hint();

	$('input[title!=""]').hint();

	// delete new criteria row
	$('.remove_criteria').on('click', function(event) {
		event.preventDefault();
		var parent_row = $(this).parent('td').parent('tr')
		if ($('table#rubrics').children('tbody').children('tr').length > 1) {
			parent_row.remove();
		} else {
			return false;
		}
	});

})
