// Scroll to a specified jQuery element
$(function(){
  $.fn.scroll_to_element = function () {
    $('html, body').animate({
      scrollTop: this.offset().top
    }, 500)
  };
})
