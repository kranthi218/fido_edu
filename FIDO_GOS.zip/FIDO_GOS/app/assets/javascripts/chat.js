//= require_tree ./chat

// Load chat
$(function() {
  var $chat_ui = $(".chat-ui-floating");

  if ($chat_ui.length > 0) {
    chatView = new ChatView(
      $chat_ui.data("section"),
      $chat_ui.data("user-data")
    );
  }
});
