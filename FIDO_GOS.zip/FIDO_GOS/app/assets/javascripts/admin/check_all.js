$(function() {

  $('.check-all').click(function(e) {
    if(this.checked) {
        // Iterate each checkbox
        $('td input:checkbox').each(function() {
            this.checked = true;
        });
    } else {
      $('td input:checkbox').each(function() {
            this.checked = false;
        });
    }
  });

});
