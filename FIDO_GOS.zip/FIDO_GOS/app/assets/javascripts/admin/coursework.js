$(function() {

  // When a new type of question is selected, display it's answer fields
  $(document.body).delegate('select#quiz_question_question_type', 'change', function(e) {

    $('#question_answers div.panel-collapse').addClass('collapse');
    $('#question_answers .add_fields').addClass('collapse');

    var type = $(this).val();
    if (type.length) {
      $('div#' + type).removeClass('collapse');

      // Disallow adding answers for true_false
      if (type !== 'true_false') {
        $('#question_answers .add_fields').removeClass('collapse');
      };

      console.log("we are displaying " + type)
    };
  });


  // Add additional answer fields to questions that allow it
  $(document.body).delegate('a.addTrigger', 'click', function(e) {
    e.preventDefault();

    var field_container = $(this).data('course');

    $('#originalField' + field_container + ' > div')
      .clone(false)
      .val('')
      .appendTo('span#addField' + field_container);
  });


  // Load CourseResource modal content
  $('#course_resources').delegate('button[data-target=#attachmentsModal]', 'click', function() {
    var $modal = $('#attachmentsModal');
    var content = $(this).next().find('.content').html();
    var title   = $(this).next().find('.title').html();
    $modal.find('.modal-body').html(content);
    $modal.find('.modal-title').html(title);
  });


  $(document.body).delegate('a.addAnswer','click', function(e) {
    e.preventDefault();
    var fieldToClone = $(this).data('origin');
    var destinationElement = $(this).data('destination');
    var newField = $(this).parent().siblings(fieldToClone).first().clone(false).val('')
    newField.removeClass('hide');
    newField.appendTo($(destinationElement));
  });

  // Remove non persisted question answer
  $(document.body).delegate('a.removeAnswer','click', function(e) {
    e.preventDefault();
    $(this).closest('div[id^=question_answer]').remove();
  });


  // Remove QuestionAnswer template fields from form before submit
  $(document.body).delegate('.simple_form.edit_quiz', 'submit', function() {
    $(this).find('.collapse').remove();
    $(this).find('#multi-select-opts.hide').remove();
    var question_type = $(this).find('#quiz_question_question_type option:selected').val()
    if ( question_type === 'true_false') {
      var value = $(this).find('select[name="quiz[question][question_answers_attributes][][answer]"]')
                         .find('option:selected').val();
      var input = $('<input>')
                    .attr('type', 'hidden')
                    .attr('name', 'quiz[question][question_answers_attributes][][choice]')
                    .val(value);
      $(this).append($(input));
    };
  });

});
