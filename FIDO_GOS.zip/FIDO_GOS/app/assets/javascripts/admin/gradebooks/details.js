$(function() {
  if (typeof(console) !== 'undefined') {
    console.log('faculty/gradebook/details javascript dependencies loaded');
  }

  $(document).ready(function() {
    $('.cts_details').on('click', function (event) {
      event.preventDefault();

      var $this = $(this),
          url = $this.attr('href'),
          request;

      request = $.get(url);

      request.success(function (data, status, xhr) {
        $('#myModal').find('.modal-body').html(data);
        $('#myModal').modal('show');
      });
    });

    $('#myModal').on('show.bs.modal', function () {
      $(this).find('.modal-dialog').css({
        width: '90%',
        height: 'auto', //probably not needed
        'max-height':'100%'
      });
    });

    $('.js-graded_student_assignment_download_button').on('click', function (event) {
      event.preventDefault();
      var $this = $(this);
      $("#"+$this.parent().parent().attr('id')+"_graded_assets").toggle();
    });

    $('.js-ungraded_student_assignment_download_button').on('click', function (event) {
      event.preventDefault();
      var $this = $(this);
      $("#"+$this.parent().parent().attr('id')+"_ungraded_assets").toggle();
    });
  });
});
