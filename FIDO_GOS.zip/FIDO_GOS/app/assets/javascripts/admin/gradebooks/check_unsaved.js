$(function() {
  $(window).bind ('beforeunload', function(e) {
    if ($('.danger').length > 0) {
      return "You have unsaved changes"
    }
  });
});
