$(function() {
  // "Finalize Grades" ajax response(success/error) will be redirect to modal popup
  $('#finalize_grades').on('ajax:success', function (event, data, status, xhr) {
    if(data.hasOwnProperty('notice'))
    {
      $("#final_grade_modal").modal();
      $("#myModalLabel").text("Success");
      $("div.modal-body").text(data['notice']);
    }
    if(data.hasOwnProperty('error'))
    {
      $("#final_grade_modal").modal();
      $("#myModalLabel").text("Failure");
      $("div.modal-body").text(data['error']);
    }
    });
  $('#finalize_grades').on('ajax:error', function (event,status, xhr) {
    $("#final_grade_modal").modal();
    $("#myModalLabel").text("Error");
    $("div.modal-body").text("error in processing the request");
  });
  // 'Go to Dashboard' button redirects to faculty dashboard
  $('#dashboard').click(function(){
    window.location.href = '/faculty';
  });
});