/*

Documentation http://xdsoft.net/jqplugins/datetimepicker
css can be found in app/assets/stylesheets/jquery.datetimepicker.css and will
need to be manually updated if the widget is updated. Make sure to included it in your page
with
#   = content_for :head do
#     = stylesheet_link_tag "jquery.datetimepicker"

*/

//= require jquery-datetimepicker/jquery.datetimepicker

$(function() {

  Calendar = {};

  Calendar.bind_datetime_picker = function() {
    console.log("datetime picker dependencies loaded");
    $('.datetime').datetimepicker({
      format:'D M j, Y g:i A',
      step: 5
    });
  }
  Calendar.bind_date_picker = function() {
    console.log("date picker dependencies loaded");
    $('.dateonly').datetimepicker({
      format:'D M j, Y',
      timepicker:false
    });
  }
  Calendar.bind_time_picker = function() {
    console.log("time picker dependencies loaded");
    $('.timeonly').datetimepicker({
      format: 'h:i A',
      datepicker:false
    });
  }

  Calendar.refresh = function () {
    Calendar.bind_datetime_picker();
    Calendar.bind_date_picker();
    Calendar.bind_time_picker();
  };

  Calendar.refresh();

  $(document.body).on('ajax:complete', '.datetime', function(e){
    Calendar.refresh();
  });

  $(document).ajaxComplete(function() {
    Calendar.refresh();
    console.log("reenabling both pickers on complete");
  });

});
