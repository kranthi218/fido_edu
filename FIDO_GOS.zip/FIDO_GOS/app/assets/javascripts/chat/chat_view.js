if(typeof(console) !== "undefined") {
  console.log("ChatView javascript loaded");
}

function ChatView(section_id, uuid) {
  var env = $(".js-chat").data("env");

  this.uuid             = uuid;
  this.userProfile      = this.getUserData(uuid);
  this.section_id       = section_id;
  this.channel          = "chat-v2-section-" + section_id;

  if (env != 'production') {
    this.channel = this.channel + '-' + env;
  }

  this.messageList      = $("#chat-messages .messages-list");
  this.facultylMsgList  = $("#chat-faculty-messages .messages-list");
  this.userList         = $("#chat-people .users-list");
  this.users            = [];
  this.users_data       = {};
  this.faculties        = [];
  this.students         = [];
  this.chat             = new Chat(this.userProfile.name, this.channel, uuid);
  this.chatAutocomplete = new ChatAutocomplete(this);

  this.messageList.empty();
  this.facultylMsgList.empty();
  this.userList.empty();
  this.addEventListeners();

  this.chat.connect();

  this.chat.history({
    channel: this.channel,
    callback: function (history) {
      this.loadMessages(history[0]);
      this.subscribeCallback();
    }.bind(this),
    error: this.subscribeCallback.bind(this)
  });

  this.chat.onBlock(function(data) {
    if (data.username == this.chat.userName) {
      var url = "//";
      url += window.location.host;
      url += "/chat/";
      url += this.section_id;
      url += "/ban/";
      url += data.user_faculty_id;

      $.ajax({
        type: "POST",
        url: url,
        data: "",
        success: function(data, textStatus, jqXHR) {
          window.location.href = window.location.href;
        }
      });
    }
  }.bind(this));
};

ChatView.prototype.addEventListeners = function() {
  var $messageForm     = $("#chat-messages .message-form")
    , $messageContent  = $messageForm.find(".message-input-field")
    , $showChatButton  = $(".chat-ui-floating-btn")
    , $closeChatButton = $(".chat-ui-floating .chat-close-btn");

  var showHideChat = function(event) {
    event.preventDefault();

    $showChatButton.toggleClass("hide");
    $closeChatButton.parent().parent().toggleClass("hide");

    var $messageContainer = this.messageList.get(0);
    $messageContainer.scrollTop = $messageContainer.scrollHeight;

    var $messageContainer = this.facultylMsgList.get(0);
    $messageContainer.scrollTop = $messageContainer.scrollHeight;

    if ($(".chat-ui-floating").is(":visible")) {
      this.chat.messageCounter(0);
      $(".chat-ui-floating-btn .message-alert")
        .hide()
        .text("0");

      setTimeout(function() {
        this.messageList.find(".unread").removeClass("unread");
      }.bind(this), 3000);
    }
  };

  $showChatButton.on("click", showHideChat.bind(this));
  $closeChatButton.on("click", showHideChat.bind(this));

  $messageForm.on("submit", function(event) {
    event.preventDefault();

    var message = $messageContent.val();

    if (message === "") {
      return
    }

    var that = this;

    this.chat.time(function (time) {
      that.chat.publish({
        channel: that.channel,
        message: {
          uuid: that.uuid,
          text: message,
          date: new Date(time / 10000)
        }
      });

      $messageContent.val("");
    });
  }.bind(this));

  $messageContent
    .on("keydown", function(event) {
      var keyCode = (event.keyCode || event.charCode);

      if (keyCode !== 13 && keyCode !== 38 && keyCode !== 40) {
        return true;
      } else {
        event.preventDefault();
      }

      if (this.chatAutocomplete.active === false && keyCode === 13) {
        $messageForm.trigger("submit");
        return false;
      }
    }.bind(this))
    .on("keyup", function(event) {
      var keyCode = (event.keyCode || event.charCode);

      if (keyCode === 13 && keyCode === 38 && keyCode === 40) {
        event.preventDefault();
        return false;
      }

      this.chatAutocomplete.run($messageContent.get(0));
    }.bind(this));

  window.addEventListener("beforeunload", function(event) {
    this.chat.unsubscribe({
      channel: this.channel
    });
  }.bind(this));
};

ChatView.prototype.loadMessages = function(messages) {
  $.each(messages, function (index, message) {
    this.messageHandler(message);
  }.bind(this));
};

ChatView.prototype.messageHandler = function(message) {
  var $messageContainer    = this.messageList.get(0)
    , $facultyMsgContainer = this.facultylMsgList.get(0)
    , $messageEl           = null
    , user                 = this.getUserData(message.uuid);

  // Prevent HTML/script injection
  message.text = $("<div>").text(message.text).html();

  this._findMentions(message);

  if (user.name == this.chat.userName) {
    $messageEl = this._messageUserHighlightHTML(message, user);
  } else {
    $messageEl = this._messageHTML(message, user);
  }

  this.messageList
    .append($messageEl)
    .find(".message-datetime").timeago();

  if (user.type == "faculty") {
    this.facultylMsgList
      .append($messageEl.clone())
      .find(".message-datetime").timeago();
  }

  $messageContainer.scrollTop    = $messageContainer.scrollHeight;
  $facultyMsgContainer.scrollTop = $facultyMsgContainer.scrollHeight;

  this.incrementCouter();
};

ChatView.prototype.incrementCouter = function() {
  if (!$(".chat-ui-floating").is(":visible")) {
    this.chat.messageCounter(this.chat.counter + 1);

    $(".chat-ui-floating-btn .message-alert")
      .show()
      .text(this.chat.messageCounter());
  }
};

ChatView.prototype._findMentions = function(message) {
  var message_text = message.text;

  for (var i = 0; i < this.users.length; i++) {
    var username  = this.users[i]
      , regExp    = new RegExp("(@"+ username + ")", "g")
      , css_class = "user-mention";

    if (username == this.chat.userName) {
      css_class = "user-mention-me";
    }

    message_text = message_text.replace(regExp, '<span class="'+ css_class +'">$1</span>');
  }

  message.has_mentions = (message_text !== message.text);
  message.text = message_text
};

ChatView.prototype._messageHTML = function(message, user, css_class) {
  if (typeof css_class !== "string") {
    css_class = "";
  }

  if (!$(".chat-ui-floating").is(":visible")) {
    css_class += " unread";
  }

  if (message.has_mentions) {
    css_class += " message-highlight-mention";
  }

  return $(
    "<div class='message "+ css_class +"'>"
    + "  <div class='author'>"
    + "    <div class='user'>"
    + "      <div class='userpic'>"
    + "        <div class='usericon'>"
    + "          <img src='"+ user.avatar_url +"' class='img-circle img-thumbnail'>"
    + "        </div>"
    + "      </div>"
    + "      <div class='user-data'>"
    + "        <div class='user-name'>"+ user.name +"</div>"
    + "      </div>"
    + "    </div>"
    + "  </div>"
    + "  <div class='message-text'>"+ message.text +"</div>"
    + "  <div class='message-datetime' title='"+ message.date +"'>"+ message.date +"</div>"
    + "</div>"
  );
};

ChatView.prototype._messageUserHighlightHTML = function(message, user) {
  return this._messageHTML(message, user, "message-highlight message-highlight-my");
};

ChatView.prototype.getUserData = function(uuid) {
  var user_data = JSON.parse(
    decodeURIComponent(
      escape(
        window.atob(uuid)
      )
    )
  );

  if (user_data.avatar_url === "anonymous_avatar.png") {
    user_data.avatar_url = "/assets/anonymous_avatar.png";
  }

  return user_data;
};

ChatView.prototype.presenceCallback = function (message, env, channel) {
  var current_user = this.getUserData(message.uuid);

  if (message.action == "join") {
    this.users.push(current_user.name);
    this.users_data[current_user.name] = current_user;

    if (current_user.type == "faculty") {
      this.faculties.push(current_user.name);
    } else {
      this.students.push(current_user.name);
    }
  } else {
    this.users.splice(this.users.indexOf(current_user.name), 1);
    this.users_data[current_user.name] = null;

    if (current_user.type == "faculty") {
      this.faculties.splice(this.faculties.indexOf(current_user.name), 1);
    } else {
      this.students.splice(this.students.indexOf(current_user.name), 1);
    }
  }

  this.users     = this.users.sort();
  this.faculties = this.faculties.sort();
  this.students  = this.students.sort();

  this.userList.empty();

  var ban_link = "";
  if (this.userProfiletype == "faculty") {
    ban_link += "  <div class='user-options'>";
    ban_link += "    <button class='user-action-btn user-action-ban'>";
    ban_link += "      <i class='icon icon-fa icon-ban'></i>";
    ban_link += "    </button>";
    ban_link += "  </div>";
  }

  for (var i = 0; i < this.faculties.length; i++) {
    var user      = this.users_data[this.faculties[i]];
    var css_class = (user.name == this.userProfile.name) ? "user-current" : "";
    var $userEl   = $(
      "<li class='user user-online "+ css_class +"' data-username='"+ user.name +"'>"
      + "  <div class='userpic'>"
      + "    <div class='user-icon'>"
      + "      <img src='"+ user.avatar_url +"' class='img-circle img-thumbnail'>"
      + "    </div>"
      + "  </div>"
      + "  <div class='user-data'>"
      + "    <div class='user-name'>"+ user.name +"</div>"
      + "  </div>"
      + ban_link
      + "</li>"
    );

    this.userList.append($userEl);
  }

  for (var i = 0; i < this.students.length; i++) {
    var user      = this.users_data[this.students[i]];
    var css_class = (user.name == this.userProfile.name) ? "user-current" : "";
    var $userEl   = $(
      "<li class='user "+ css_class +"' data-username='"+ user.name +"'>"
      + "  <div class='userpic'>"
      + "    <div class='user-icon'>"
      + "      <img src='"+ user.avatar_url +"' class='img-circle img-thumbnail'>"
      + "    </div>"
      + "  </div>"
      + "  <div class='user-data'>"
      + "    <div class='user-name'>"+ user.name +"</div>"
      + "  </div>"
      + ban_link
      + "</li>"
    );

    this.userList.append($userEl);
  }
};

ChatView.prototype.subscribeCallback = function () {
  this.chat.subscribe({
    channel: this.channel,
    heartbeat: 30,
    message: this.messageHandler.bind(this),
    presence: this.presenceCallback.bind(this)
  });
};
