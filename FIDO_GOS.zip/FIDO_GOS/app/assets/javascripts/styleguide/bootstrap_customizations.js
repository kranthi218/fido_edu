//= require highlightjs/highlight.pack
//= require datetime_calendar

if(typeof(console) !== "undefined") {
  console.log("Styleguide javascript dependencies loaded");
}

var unindent = function(content) {
  var indent = content.match(/^(\s+)/);

  if (indent) {
    content = content.replace(new RegExp('^' + indent[1], 'gm'), '');
  }

  return content;
};

$(document).ready(function () {
  // Highlight code snippets using highlightjs
  $(".panel.panel-example").each(function(index, el) {
    var $el = $(el),
        $body = $el.find(".panel-body"),
        highlighted;

    highlighted = hljs.highlight("xml", unindent($body.html())).value;

    highlighted = $.map(highlighted.split("\n"), function (element, index) {
      return unindent(element);
    }).join("\n");

    $el.append("<pre class='language-xml'>" + highlighted + "</pre>");
  });
});
