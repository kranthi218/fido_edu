# This class stores data related to books.
class Book < ApplicationRecord
  extend Enumerize
  include SectionExtension

  belongs_to :section, touch: true

  validates :title, :author, :publisher, :isbn, :edition, presence: true
  validates :title, uniqueness: { scope: [:section_id, :author, :publisher] }
  validates :publication_date, allow_blank: true,
                               format: { with: /(19|20)\d{2}/i },
                               numericality: {
                                 only_integer: true,
                                 greater_than_or_equal_to: 1900,
                                 less_than_or_equal_to:
                                 Date.today.year
                               }

  scope :recent, -> { order('created_at desc') }

  enumerize :copy_format, in: { hardback: 1,
                                softback: 2,
                                other:    3,
                                e_copy:   4 }

  def full_title
    "#{title} -#{author}, #{publisher} #{edition}, #{isbn}"
  end

  HUMANIZED_ATTRIBUTES = {
    publication_date: 'Publication Year'
  }

  def self.human_attribute_name(attr, options = {})
    HUMANIZED_ATTRIBUTES[attr.to_sym] || super
  end
end
