# Announcements are a messages targeted
# to users related to a specific Section.
#
# Example: A teacher giving a specific class additional
# information about a particualr assignment.
class Announcement < ApplicationRecord
  include AssetsExtension
  include LinksExtension

  AGE_CUTOFF = 5.days

  # Email delivery status
  enum status: %i[pending started delivered errored]

  belongs_to :user, foreign_key: 'creator_id'
  belongs_to :announcable, polymorphic: true

  validates :title, presence: true
  validates :content, presence: true
  validates :announcable, associated: true, presence: true
  validates :title, presence: true, uniqueness: { scope: :announcable_id }

  validates_date :published_at,
                 on_or_after: :left_published_at_border,
                 on_or_before: :right_published_at_border

  accepts_nested_attributes_for :assets,
                                allow_destroy: true,
                                reject_if: :blank_attachment?

  scope(:for_section, lambda do |section|
    where(announcable_type: 'Section', announcable_id: section)
  end)

  scope :published, -> { where(arel_table[:published_at].lteq(Time.zone.now)) }
  scope :recent, -> { order('created_at desc') }

  # constant inheritance doesn't work for scopes since they are defined
  # at load time(?). So self will only ever point to the parent class
  def self.current
    where(arel_table[:published_at].gteq(self::AGE_CUTOFF.ago))
  end

  def readonly?
    return true if delivered? && !status_changed?
    super
  end

  alias readonly readonly?

  private

  def left_published_at_border
    announcable.starts_at - 2.weeks
  end

  def right_published_at_border
    announcable.ends_at + Section::FINAL_GRADING_PERIOD_DURATION
  end

  def blank_attachment?(assets_attributes)
    assets_attributes['attachment'].blank?
  end
end
