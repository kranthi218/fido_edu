# Asset is a polymorphic class that handles file attachments
# associated with arbitrary models.
#
# As of the writing of this comment, assets are used for:
#
#   * File uploads for section assignments
#   * File uploads for student assignment submissions
#   * File uploads for any Redactor rich text editor field
#
# This list is not comprehensive, but should outline the general
# use-cases of an Asset
class Asset < ApplicationRecord
  acts_as_paranoid
  belongs_to :attachable,
             polymorphic: true,
             touch: true

  belongs_to :creator, class_name: 'User'

  # Note: Unfortunately, the Paperclip::Attachment class does not
  # have visibility into private methods. We're using #send to reference
  # a private metohd in Asset to avoid exposing logic specific to the Asset
  # model in a public method/interface.
  has_attached_file :attachment,
                    styles: -> (a) { a.instance.send(:image_style_for, a) }

  validates_attachment :attachment,
    size: { less_than: 200.megabytes },
    content_type: {
      message: I18n.t('activerecord.errors.messages.invalid_content_type'),
      content_type: [
        /\Aimage\/.*\Z/,
        /\Aapplication\/.*\Z/,
        /\Atext\/.*\Z/,
        /\Aaudio\/.*\Z/
      ]
    }

  scope :images, -> { where("attachment_content_type LIKE 'image/%'") }
  scope :recent, -> { order('created_at desc') }

  def name
    attachment_file_name
  end

  def url
    attachment.url
  end

  def image?
    attachment_content_type.index('image/')
  end

  def readonly?
    return true if attachable.readonly?
    super
  end

  private

  def image_content_type?(content_type)
    content_type.starts_with?('image/')
  end

  def image_style_for(attachment)
    if image_content_type?(attachment.content_type)
      { thumb: '100x100>' }
    else
      {}
    end
  end
end
