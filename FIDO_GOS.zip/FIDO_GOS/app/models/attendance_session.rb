class AttendanceSession < ApplicationRecord
  belongs_to :section
#  belongs_to :instructor
  belongs_to :faculty

  has_many :attendance_records, dependent: :destroy
  has_many :students, through: :attendance_records

  validates :title, :date, :section_id, :instructor_id, :presence => true
  validates :title, :uniqueness => {:scope => :section_id}

  validate :date_should_in_between_section_dates
  validate :should_not_in_same_date_with_others

  accepts_nested_attributes_for :attendance_records, :allow_destroy => true, :reject_if => proc { |attrs| attrs['attendance'].blank? }
  scope :for_section, lambda { |id| where("section_id = ?", id) }

  def update_attendance_records(attendance_records)
    if attendance_records.present?
      attendance_records.each_pair do |key, value|
        attendance_record            = AttendanceRecord.find_by_student_id_and_attendance_session_id(key, self.id) || AttendanceRecord.new
        attendance_record.student_id = key
        attendance_record.attendance = value[:attendance]
        attendance_record.attendance_session = self
        attendance_record.save!
      end
    else
      true
    end
  end

  def date_should_in_between_section_dates
    unless self.date >= self.section.starts_at and self.date <= self.section.ends_at
      errors.add(:date, "should be between section's start date and end date")
    end
  end

  def should_not_in_same_date_with_others
    self.section.attendance_sessions.each do |attendance_session|
      if attendance_session.date == self.date
        errors.add(:date, "date conflict with Attendance Session: #{attendance_session.title}")
        break
      end
    end
  end

  def self.for_section(section)
    scoped(:joins => :section, :conditions => ["attendance_sessions.section_id = ?", section])
  end

  def self.present
    scoped(:include => :attendance_records, :conditions => ["attendance_records.attendance IN (?)", [AttendanceRecord::ATTENDANCE_TYPE_PRESENT, AttendanceRecord::ATTENDANCE_TYPE_EXCUSED]])
  end

  def self.absent
    scoped(:joins => :attendance_records, :conditions => ["attendance_records.attendance IN (?)", [AttendanceRecord::ATTENDANCE_TYPE_UNEXCUSED, AttendanceRecord::ATTENDANCE_TYPE_UNVERIFIED]])
  end

end
