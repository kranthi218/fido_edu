class Course < ApplicationModel
  include Search::Course

  attr_accessor :imported, :clean_up

  has_paper_trail

  belongs_to :program
  belongs_to :department
  has_many :sections, dependent: :destroy

  has_many :course_learning_outcomes

  has_many :coursework, as: :courseworkable
  has_many :assignments,
           through:     :coursework,
           source:      :content,
           source_type: 'Assignment',
           dependent:   :destroy

  has_many :course_terms, dependent: :destroy
  after_create :generate_course_terms

  validates :name, presence: true
  validates :description, presence: true
  validates :course_no, presence: true, uniqueness: true

  before_destroy :validates_removable

  scope :current, -> { where(publish: true) }

  def signature_assignment
    coursework.where(kind: :signature).first&.content
  end

  def configured?
    signature_assignment&.id && clos_count >= 3 ? true : false
  end

  def last_published_term
    latest = course_terms.published.first
    return nil unless latest
    latest&.term
  end

  def display_name
    format('%s - %s', course_no, name)
  end

  def clean_up?
    clean_up.present?
  end

  def link_title
    name.to_s
  end

  def link_details
    description.to_s
  end

  def current_sections
    sections.where(year: current_year, term_id: current_term)
  end

  def upcoming_sections
    sections.where(year: upcoming_year, term_id: upcoming_term)
  end

  def in_season?
    current_sections.present?
  end

  def core_for?(program)
    program&.core_courses&.include?(self)
  end

  def elective_for?(program)
    program&.elective_courses&.include?(self)
  end

  def core_for_student?(student)
    core_for?(student.program)
  end

  def elective_for_student?(student)
    elective_for?(student.program)
  end

  private

  def validates_removable
    students = sections.map(&:students).flatten.uniq
    return if students.none?

    errors.add(:base, :students_still_enrolled, count: students.size)
    false
  end

  def generate_course_terms
    return unless Term.current&.id
    Term.where('id >= ?', Term.current.id).each do |term|
      CourseTerm.where(course: self, term: term).first_or_create!
    end
  end
end
