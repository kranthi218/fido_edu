# This little class allows us to treat an arbitrary field like a class. It just returns the
  # display name for the tab.
  class CourseDetail
    def tab_title
      "Course Details"
    end
  end