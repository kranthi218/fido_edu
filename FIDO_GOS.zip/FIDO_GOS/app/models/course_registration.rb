class CourseRegistration < ApplicationRecord
  include AASM
  include GpaCalculator

  acts_as_paranoid
  validates :student_id, :term_id, presence: true

  belongs_to :student
  belongs_to :term
  belongs_to :major
  belongs_to :degree_history
  belongs_to :degree

  has_many :section_students, -> { order('id ASC') }, dependent: :destroy

  scope :for_term, ->(term) { where('term_id = ?', term) }
  scope :via_admin, -> { where('administrator_id is NOT NULL') }

  aasm column: :status do
    state :active, initial: true
    state :graduated
    state :transferred
    state :cancelled

    event :graduate do
      transitions to: :graduated, from: %i[transferred active]
    end
  end

  def self.active_registrations
    scoped(include: :section_students, conditions: ['section_students.status IN (?)', %w[enrolled paid]])
  end

  def self.ordered
    scoped(order: 'course_registrations.term_id ASC')
  end

  def self.admin
    # hack..
    user ||= User.find_by_email('sjavid@itu.edu')
  end

  def display_name
    term.name
  end

  def active_enrollments
    section_students.active
  end

  def previous_enrollments
    active_enrollments.select { |e| e.paid? || e.enrolled? }
  end

  def enrollments_in_term
    if student.present?
      student.course_registrations.for_term(term).collect(&:active_enrollments).flatten
    else
      []
    end
  end

  def total_units
    enrollments_in_term.inject(0) { |acc, ce| acc += ce.units }
  end

  module CollectionMethods
    def section_students
      map(&:section_students).flatten
    end

    def previous_enrollments
      map(&:previous_enrollments).flatten
    end
  end

  def current?
    term.current?
  end
end
