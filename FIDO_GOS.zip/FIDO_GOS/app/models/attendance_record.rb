class AttendanceRecord < ApplicationRecord
  ATTENDANCE_TYPE_PRESENT       = 'Present'.freeze
  ATTENDANCE_TYPE_EXCUSED       = 'Excused'.freeze
  ATTENDANCE_TYPE_UNEXCUSED     = 'Unexcused'.freeze
  ATTENDANCE_TYPE_UNVERIFIED    = 'Unverified'.freeze

  ATTENDANCE_TYPES = [
    ATTENDANCE_TYPE_PRESENT,
    ATTENDANCE_TYPE_EXCUSED,
    ATTENDANCE_TYPE_UNEXCUSED,
    ATTENDANCE_TYPE_UNVERIFIED
  ].freeze

  belongs_to :student
  belongs_to :attendance_session
  validates :attendance, on: :create, presence: { message: "can't be blank" }

  class << self
    ATTENDANCE_TYPES.each do |attendance_type|
      method = attendance_type.gsub(/[^a-z0-9]+/i, '_').downcase
      define_method(method) do
        where(attendance: attendance_type)
      end
    end
  end
end
