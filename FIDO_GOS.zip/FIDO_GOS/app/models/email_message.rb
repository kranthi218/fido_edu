class EmailMessage < ApplicationRecord
end
