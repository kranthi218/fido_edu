class CourseResource < ApplicationRecord
  include AssetsExtension
  include SectionExtension

  CATEGORY = [
    %w[Attachments attachments],
    %w[Documents documents],
    %w[URL url],
    %w[Text text],
    %w[Video video]
  ].freeze

  belongs_to :section, touch: true

  validates :title, presence: true, uniqueness: { scope: :section_id }
  validates :content, presence: true
  validates :url,
            allow_nil: true,
            allow_blank: true,
            format: {
              with: URI.regexp(%w[http https]),
              message: 'URL must start with http or https'
            }

  accepts_nested_attributes_for :assets,
                                allow_destroy: true,
                                reject_if: (proc do |attrs|
                                  attrs['attachment'].blank?
                                end)

  has_attached_file :attachment
  do_not_validate_attachment_file_type :attachment

  scope :recent, -> { order('created_at desc') }

  Paperclip.interpolates :normalized_file_name do |attachment, _style|
    attachment.instance.normalized_file_name
  end

  def normalized_file_name
    "#{id}-#{title.gsub(/[^a-zA-Z0-9_\.]/, '_')}"
  end

  def attachment_url
    Rails.env.production? ? attachment.expiring_url : attachment.url
  end

  def remote_video_file?
    category == 'video' && url.present? &&
      MIME::Types.type_for(url).map(&:media_type).include?('video')
  end
end
