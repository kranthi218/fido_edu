class AcademicStatus < ApplicationRecord
  has_many :students
  validates :name, :presence => true, :uniqueness => true
  #
  # class << self
  #   AcademicStatus.all.map(&:key).each do |status|
  #     status_method =status.gsub(/[^a-z0-9]+/i, '_').downcase
  #     define_method(status_method) do
  #       scoped(:conditions => {:key => status}).first
  #     end
  #   end
  # end

end
