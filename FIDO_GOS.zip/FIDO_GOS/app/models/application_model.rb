class ApplicationModel < ApplicationRecord
  self.abstract_class = true

  def current_year
    Term.current.starts_at.try(:year)
  end

  def current_term
    Term.current.current_term
  end

  class << self
    def current_year
      Term.current.try(:starts_at).try(:year)
    end

    def current_term
      Term.current.try(:current_term)
    end

    def upcoming_term
      Term.upcoming_term.try(:current_term)
    end

    def upcoming_year
      Term.upcoming_term.try(:starts_at).try(:year)
    end
  end
end
