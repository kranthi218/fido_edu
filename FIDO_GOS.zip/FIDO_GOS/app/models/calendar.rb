# A `Calendar` is a collection of {CalendarItem}
# instances belonging to a particular user.
class Calendar < ApplicationRecord
  belongs_to :user
  has_many :items, class_name: 'CalendarItem', inverse_of: :calendar

  validates :user_id, presence: true, uniqueness: true
end
