# This class adds some application specific methods and searches to the Activities table
# which is managed by PublicActivity gem.

class Activity < PublicActivity::Activity
  belongs_to :trackable, polymorphic: true

  superclass.class_eval do
    scope :visible, -> { where(visible: true) }
  end

  class << self
    def for_user_or_section(user, section_id)
      PublicActivity::Activity.visible
        .includes(:trackable)
        .where("(recipient_type = 'Section' AND recipient_id = ?) OR (recipient_type = ? AND recipient_id = ?)",
               section_id, user.class.name, user.id)
        .order('updated_at DESC, created_at DESC')
    end

    def for_section(user, section_id)
      PublicActivity::Activity.visible
        .includes(:trackable)
        .where("(recipient_type = 'Section' AND recipient_id = ?)", section_id)
        .order('updated_at DESC, created_at DESC')
    end

    def for_user_for_section(user, section_id)
      PublicActivity::Activity.visible
        .includes(:trackable)
        .where("(recipient_type = 'Section' AND recipient_id = ?) AND (recipient_type = ? AND recipient_id = ?)",
               section_id, user.class.name, user.id)
        .order('updated_at DESC, created_at DESC')
    end

    # User here needs to be either a Student or Faculty, not a User
    def collect_activities_for_user(user)
      PublicActivity::Activity.visible
        .preload(:trackable)
        .order('updated_at DESC, created_at DESC')
        .where("(recipient_type = 'Section' AND recipient_id IN (?)) OR (recipient_type = ? AND recipient_id = ?)", user.section_ids, user.class.name, user.id)
    end
  end

  def self.update_visible_for(trackable, new_value)
    trackable.activities.where('visible <> ?', new_value)
      .update_all(visible: new_value, updated_at: Time.current)
  end
end
