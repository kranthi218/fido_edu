class Coursework < ApplicationRecord
  belongs_to :courseworkable, polymorphic: true
  belongs_to :content,        polymorphic: true
  delegate :assignment, to: :content, allow_nil: true
  delegate :discussion, to: :content, allow_nil: true
  delegate :quiz, to: :content, allow_nil: true
  delegate :lesson, to: :content, allow_nil: true
  belongs_to :section, foreign_key: :courseworkable_id
  belongs_to :course, foreign_key: :courseworkable_id
  belongs_to :course_term, foreign_key: :courseworkable_id

  enum kind: { regular: 0, signature: 1, mandatory: 2 }

  def self.retrievable
    where(kind: 'regular')
  end

  def self.active
    active_content_class_query(Assignment) +
      active_content_class_query(Discussion) +
      active_content_class_query(Quiz) +
      active_content_class_query(Lesson)
  end

  def self.active_content_class_query(content_class)
    joins("INNER JOIN #{content_class.to_s.underscore.pluralize} ON"\
      " #{content_class.to_s.underscore.pluralize}.id = coursework.content_id"\
      " AND coursework.content_type = '#{content_class}'").where(
        content_class.to_s.underscore.pluralize => { active: true }
      )
  end
end
