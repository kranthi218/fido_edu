class AdvisorGroup < ApplicationRecord
  has_many :advisors
end
