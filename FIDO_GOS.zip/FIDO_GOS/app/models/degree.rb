class Degree < ApplicationRecord
  has_many :majors

  def level
    case sevis_edu_level
    when '04'
      :undergraduate
    when '05'
      :graduate
    end
  end

end
