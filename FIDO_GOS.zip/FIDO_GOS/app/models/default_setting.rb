# This class stores the initial values for all settings that must have a
# default value. As soon as the data is changed in the database, this value
# will be outdated.
#
# For more info, please visit:
# https://github.com/huacnlee/rails-settings-cached
class DefaultSetting < RailsSettings::Base
end
