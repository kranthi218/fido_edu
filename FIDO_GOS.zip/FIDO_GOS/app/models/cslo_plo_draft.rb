class CsloPloDraft < ApplicationRecord
  belongs_to :plo
  belongs_to :section, foreign_key: 'course_id'

  def self.for_course(session_id)
    scoped(conditions: { session_token: session_id }).collect(&:plo)
  end

  def self.drafts_for_current_session(session_id)
    scoped(conditions: { session_token: session_id })
  end
end
