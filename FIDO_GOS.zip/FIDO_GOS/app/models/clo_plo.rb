class CloPlo < ApplicationRecord
  belongs_to :course_learning_outcome, inverse_of: :clo_plos
  belongs_to :plo

  validates :plo_id, presence: true
  validates :course_learning_outcome, presence: true

  alias_attribute :clo_id, :course_learning_outcome_id
end
