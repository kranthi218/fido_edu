class CloCourseTerm < ApplicationRecord
  belongs_to :course_learning_outcome
  belongs_to :course_term
  has_many   :clo_course_term_plo_program_terms, dependent: :destroy
  has_many   :plo_program_terms, through: :clo_course_term_plo_program_terms
  has_many   :plos, through: :plo_program_terms

  delegate   :course_id,
             :description,
             :rubrics,
             :position,
             :updated_at,
             to: :course_learning_outcome
end
