# A DiscussionParticipant:
#   * created the first time a student participates in a discussion
#   * there is only one per student/dscussion
#   * indicates whether a student has been graded, what the grade was,
#     and any faculty feedback.
class DiscussionParticipant < ApplicationRecord
  include PublicActivity::Model
  include ScoreExtension

  alias_attribute :submitted_at, :created_at

  tracked owner: ->(controller, _model) { controller.try(:current_user) }

  belongs_to :student
  belongs_to :discussion
  has_many   :discussion_comments,
             ->(object) { where(discussion_id: object.discussion_id) },
             primary_key: :student_id,
             foreign_key: :participatable_id

  validates :student_id,
            presence: true,
            uniqueness: {
              scope: %i[discussion_id student_id],
              message: 'Student is already participating in the discussion'
            }
  validates :discussion_id, presence: true
  validates :score, numericality: {
    allow_nil: true,
    greater_than_or_equal_to: 0,
    less_than_or_equal_to: ->(dp) { dp.discussion.points }
  }

  scope :only_students, (lambda do
    join_section_students.where(
      section_students: { status: %w[enrolled graded] }
    )
  end)

  scope :ungraded, -> { where(graded: false) }
  scope :graded,   -> { where(graded: true)  }

  def self.student_score_by_grading_policy(student_id, grading_policy_id)
    joins(:discussion).where(
      student_id: student_id,
      discussions: { grading_policy_id: grading_policy_id }
    )
  end

  def self.scores_for_student_for_section(section_id, student_id)
    joins(discussion: :coursework).where(
      student_id: student_id,
      discussions: { active: true, coursework: { courseworkable_id: section_id, courseworkable_type: 'Section' } }
    )
  end

  def self.submissions_for_student_for_section(section_id, student_id)
    includes(discussion: :coursework).where(
      student_id: student_id,
      discussions: { active: true, coursework: { courseworkable_id: section_id, courseworkable_type: 'Section' } }
    )
  end

  def self.join_section_students
    dp_arel = arel_table
    cs_arel = SectionStudent.arel_table

    join_expression = dp_arel.join(cs_arel, Arel::Nodes::OuterJoin).on(
      dp_arel[:section_id].eq(cs_arel[:section_id]).and(
        cs_arel[:student_id].eq(dp_arel[:student_id])
      )
    )

    joins(join_expression.join_sources)
  end

  def grade_clos(clo_scores = {})
    raise ArgumentError, 'clo_scores must be a enumerable' unless clo_scores.respond_to? :each_pair

    clo_scores.each_pair do |clo, score|
      next if score.blank?
      create_or_update_alo(clo, score)
    end
  end
end
