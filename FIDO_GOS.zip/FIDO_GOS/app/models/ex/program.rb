class Ex::Program < Ex::Base
  self.table_name = 'PROGRAM_DEF'
  self.primary_key = nil
end
