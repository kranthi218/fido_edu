# Ex::SectionPerson represents an individuals relationship with a given
# Ex::Section.
#
# @note Be aweare that SectionPerson includes records for both the
#   students and the instructors for a given course.
class Ex::SectionPerson < Ex::Base
  self.table_name = 'EMS_SECTION_PERSON'
  self.primary_key = nil

  # The `transaction_sts` Ex database column may contain any
  # of the values defined in this constant (possibly more).
  # These status codes have special meanings as also defined by this constant.
  #
  # @note The 'dc' or 'delete_course' status indicates that only
  #   Ex administrators can view or modify that record.
  TRANSACTION_STATUS_MAP = {
    c: 'current',
    d: 'dropped',
    dc: 'delete_course',
    h: 'history',
    i: 'incomplete',
    p: 'preregistered',
    r: 'reserved',
    w: 'waitlisted'
  }

  # Given an instance of {Term}, find the number of
  # currently enrolled users for all sections in that term.
  #
  # @param [Term] An instance of a {Term} model
  def self.section_enrollment_counts(term)
    select('crs_cde, count(crs_cde) as student_count')
      .where(
        yr_cde: term.janzebar_year,
        trm_cde: term.janzebar_term,
        transaction_sts: 'C'
      )
      .group('crs_cde')
      .count
  end

  # Human readable transaction status derived from Ex transaction status codes
  def transaction_status
    @transaction_status ||=
      TRANSACTION_STATUS_MAP[transaction_sts.downcase.to_sym]
  end
end
