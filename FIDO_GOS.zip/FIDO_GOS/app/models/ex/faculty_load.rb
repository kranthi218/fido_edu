# An Ex::FacultyLoad record is a mapping of Ex::Section records to the
# Ex::Faculty assigned to those sections.
class Ex::FacultyLoad < Ex::Base
  self.table_name = 'faculty_load_table'
  self.primary_keys = %w(yr_cde trm_cde crs_cde)

  belongs_to :ex_section,
             class_name: 'Ex::Section',
             foreign_key: %w(yr_cde trm_cde crs_cde)
  belongs_to :ex_faculty,
             class_name: 'Ex::Faculty',
             foreign_key: 'instrctr_id_num',
             primary_key: 'id_num'
end
