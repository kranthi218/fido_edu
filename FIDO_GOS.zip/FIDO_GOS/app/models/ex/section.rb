# Ex representation of what we refer to as a Section in the EMS
# For implementation @see Ex::Rw:Section
class Ex::Section < Ex::Rw::Section
  after_initialize :readonly!
end
