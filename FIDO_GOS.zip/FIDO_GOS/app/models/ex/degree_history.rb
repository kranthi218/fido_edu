# The Ex::DegreeHistory class represents the Janzebar/Ex degree history information
class Ex::DegreeHistory < Ex::Base
  self.table_name  = 'DEGREE_HISTORY'
  self.primary_key = 'id_num'

  belongs_to :ex_student, class_name: "Ex::Student", foreign_key: "id_num"

  #current active in a particular academic year
  #these students are yet to graduate
  #we only import student records from 2011 moving forward
  def self.student_degree_histories
    find_by_sql <<-sql.strip_heredoc
     SELECT DISTINCT DH.ID_NUM AS id_num, SCH.YR_CDE AS year,
     MND.MAJOR_MINOR_DESC AS major ,CD.CONC_DESC AS concentration,
     DH.ENTRY_DTE AS entry_date, DH.DTE_DEGR_CONFERRED AS exit_date,
     DH.APPID AS appid, DH.EXIT_REASON AS exit_reason, DH.ACTIVE AS active,
     DH.CUR_DEGREE AS current_degree
     FROM DEGREE_HISTORY DH
     LEFT JOIN STUDENT_CRS_HIST SCH ON DH.ID_NUM = SCH.ID_NUM
     LEFT JOIN MAJOR_MINOR_DEF MND ON DH.MAJOR_1 = MND.MAJOR_CDE
     LEFT JOIN CONCENTRATION_DEF CD ON DH.CONCENTRATION_1 = CD.CONC_CDE

     ORDER BY SCH.YR_CDE
    sql
  end
end
