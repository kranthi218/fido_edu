# Ex's representation of what we simply refer to as a Department within
# the EMS
class Ex::Department < Ex::Base
  self.table_name = 'DEPARTMENT'
  self.primary_key = 'appid'

  def dept_cde
    read_attribute(:dept_cde).to_s.strip
  end

  def dept_desc
    read_attribute(:dept_desc).to_s.strip
  end

  def ems_department
    dept = ::Department.where(number: dept_cde).first
  end

  def ex_catalogs
    if dept_cde == 'EE'
      return Ex::Catalog.where('instit_div_cde=? OR instit_div_cde=?', 'EE', 'CE')
    else
      return Ex::Catalog.where(instit_div_cde: dept_cde)
    end
  end
end
