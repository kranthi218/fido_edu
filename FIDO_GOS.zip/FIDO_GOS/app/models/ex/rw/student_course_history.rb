# Ex::SectionPerson represents an individuals relationship with a given
# Ex::Section.
class Ex::Rw::StudentCourseHistory < Ex::Rw
  self.table_name = 'student_crs_hist'
  self.primary_keys = :id_num, :yr_cde, :trm_cde, :stud_seq_num

  TEST_USER_ID_NUM = 83_427

  belongs_to :ex_name,
             class_name: 'Ex::Name',
             foreign_key: 'id_num'

  belongs_to :ex_grade,
             class_name: 'Ex::Grade',
             foreign_key: %i[
               grade_cde
               grade_scale_cde
               credit_type_cde
             ]

  belongs_to :ex_section,
             class_name: 'Ex::Section',
             foreign_key: %w[yr_cde trm_cde crs_cde],
             primary_key: %w[yr_cde trm_cde crs_cde]

  scope(:active_courses, lambda do
    where(transaction_sts: %w[C H])
    .where('grade_cde IS NULL OR grade_cde NOT IN (?)',
           Ex::Grade::WITHDRAWN_GRADE_CODES)
  end)

  scope(:visible_courses, lambda do
    where(transaction_sts: %w[C H])
    .where('grade_cde IS NULL OR grade_cde NOT IN (?)',
           Ex::Grade::WITHDRAWN_GRADE_HIDDEN)
  end)

  scope(:withdrawn, lambda do
    where(transaction_sts: 'H',
          grade_cde: Ex::Grade::WITHDRAWN_GRADE_CODES)
  end)

  scope :dropped,          -> { where(transaction_sts: 'D') }
  scope :ignore_test_user, -> { where.not(id_num: TEST_USER_ID_NUM) }

  default_scope { ignore_test_user }

  # Self methods
  def self.ems_term(trm_cde, yr_cde)
    name = Term::JANZEBAR_TERM.key(trm_cde.to_s.upcase)
    year = (trm_cde == 'FA' ? yr_cde.to_i : yr_cde.to_i + 1)
    Term.for_year(year).where(name: name).first
  end

  def self.find_by_section_student(sect_st)
    active_courses.find_by(
      trm_cde: sect_st.term.janzebar_term,
      yr_cde:  sect_st.term.janzebar_year,
      crs_cde: sect_st.section.ex_course_code,
      id_num:  sect_st.student.student_number.to_i
    )
  end

  def ems_status
    case transaction_sts.strip
    when 'D' then 'dropped'
    when 'C' then 'enrolled'
    when 'H'
      return 'withdrawn'  if withdrawn?
      return 'incomplete' if incomplete?
      return 'graded'     if graded?
    end
  end

  def graded?
    ex_grade.present? && !ex_grade.withdrawn? && !ex_grade.incomplete?
  end

  def withdrawn?(sect_st = nil)
    return true  if ex_grade.present? && ex_grade.withdrawn?
    return false if sect_st && sect_st.grade_id.present?

    # @see ETPO-592 W_and_WH_table.png
    transaction_sts&.strip == 'H' && grade_cde&.strip == 'F'
  end

  def incomplete?
    ex_grade.present? && ex_grade.incomplete?
  end
end
