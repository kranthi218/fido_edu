# Note: This table for this model is NOT normalized. The data contained
# in the `column_x` columns will change depending on the `trans_type` column.
#
# Normalized columns (these do not change based on trans_type):
#   - seq_num: <Integer> unique, primary, auto-incrementing row id
#   - trans_type: <String> may be one of 'PRS', 'CRS', 'CRP'
#       PRS => Person
#       CRS => Course
#       CRP => Unknown
#   - action: <String> may be one of 'A', 'U', or 'D'
#       A => Add
#       U => Update
#       D => Delete
#   - batch_number: <Integer> auto-incrementing non-unique id
#     The batch number represents a grouping of records that
#     were updated or changed during a single transaction within
#     Janzebar/Ex.
#
# Denormalized columns (trans_type = PRS):
#   - column_1: <String> ID_NUM - a string containing a user's student number
#   - column_2: <String> EMAIL_ADDRESS - the user's email address
#   - column_3: <String> EMS_ROLE - a 3 character string representing
#               the user's role within the EMS
#   - column_4: <String> LAST_NAME - a 30 character, whitespace padded
#               family name for a user
#   - column_5: <String> FIRST_NAME - a 15 character, whitespace padded
#               given name for a user
#   - column_6: <String> MIDDLE_NAME - a 15 character, whitespace padded
#               middle name for a user
#   - column_7: <String> DEGR_CDE - a 5 character degree code
#   - column_8: <String> MAJOR_1 - a 5 character major code
#   - column_9: <String> CUR_STUD_DIV - a 2 character code representing
#               the user's study division (ie: masters, docterate, etc)
#   - column_10: Unused, blank or null
#
# Denormalized columns (trans_type = CRS):
#   - column_1: <String> YR_CDE - a 4 character string representing a year
#   - column_2: <String> TRM_CDE - a 3 character string representing
#               a term season
#   - column_3: <String> CRS_CDE - up to a 30 characters representation of
#               a course code
#   - column_4: <String> SHORT_CRS_TITLE_1 - a 15 character, whitespace padded
#               short course title
#   - column_5: <String> SHORT_CRS_TITLE_2 - a 15 character, whitespace padded
#               short course title
#   - column_6: <String> CRS_TITLE - a 35 character, whitespace padded
#               course title
#   - column_7: <String> CRS_TITLE_2 - a 35 character, whitespace padded
#               course title
#   - column_8: <String> CREDIT_HRS - a string representation of a floating
#               point number representing the number of credit hours for a
#               designated course
#   - column_9: <String> FIRST_BEGIN_DTE - The start date of a given course.
#               Note: Date is in the ISO-8601 basic format (YYYYMMDD)
#   - column_10: <String> LAST_END_DTE - The end date of a given course.
#                Note: Date is in the ISO-8601 basic format (YYYYMMDD)
class Ex::EmsTransaction < Ex::Base
  self.table_name = 'EMS_TRANSACTION'
  self.primary_key = 'SEQ_NUM'
end
