class Ex::Grade < Ex::Base
  self.table_name   = 'grade_table'
  self.primary_keys = :grade_cde, :grade_scale_cde, :credit_type_cde

  WITHDRAWN_GRADE_CODES = %w(UW W WH).freeze
  WITHDRAWN_GRADE_HIDDEN = %(WH).freeze
  INCOMPLETE_GRADE = 'I'.freeze

  def withdrawn?
    WITHDRAWN_GRADE_CODES.include?(grade_cde.strip)
  end

  def incomplete?
    INCOMPLETE_GRADE == grade_cde.strip
  end

  # @param grade_cde [String] Ex grade code
  # @return [Integer] EMS Grade id
  def self.ems_grade_id_for(grade_cde)
    return if grade_cde.blank?
    ::Grade.find_by!(name: grade_cde.strip).try(:id)
  end
end
