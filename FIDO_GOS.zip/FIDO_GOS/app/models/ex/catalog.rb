# Represents the equivilant of a EMS Course record within Ex
class Ex::Catalog < Ex::Base
  self.table_name = 'CATALOG_MASTER'
  self.primary_key = 'appid'
  # TODO: after clarification about internship department
  EX_DEPARTMENTS = { 'CE' => 'EE', 'CF' => 'CFL' }

  has_many :ex_sections,
           class_name: 'Ex::Section',
           primary_key: 'instit_div_cde',
           foreign_key: 'institut_div_cde'

  def instit_div_cde
    read_attribute(:instit_div_cde).to_s.strip
  end

  def ex_department
    if EX_DEPARTMENTS.keys.include?(instit_div_cde)
      ::Ex::Department.where(dept_cde: EX_DEPARTMENTS[instit_div_cde]).last
    else
      ::Ex::Department.where(dept_cde: instit_div_cde).last
    end
  end
end
